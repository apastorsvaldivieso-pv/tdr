---
name: tdr-s3-dashboard
description: Stage 3 of the TDR Capital origination demo on Moody's data. Turns the S1 and S2 outputs into a published dashboard (Overview with a traffic-light company screen, Company, News and events, Sources) by writing a short synthesis file of sourced facts and running the bundled build script on the approved template, then checks it. Use on /tdr-s3 or when Alvaro asks to build or refresh the dashboard from the evidence.
---

# TDR S3: synthesis, dashboard, check

Inputs: `tdr-s1-output.json` and `tdr-s2-output.json` (with their `.md` twins), from the working folder, the conversation, or pasted. If either JSON is missing, ask for it before doing anything else. Do not pull data yourself except to fill a gap Alvaro names.
Output: a published HTML dashboard (artifact) plus a short check log.

Setup: copy everything in `files/`, next to this SKILL.md, into the working folder: `build_dashboard.py`, `tdr-dashboard-template.html` (the approved page as a template), `tdr_eval.py`, `tdr-golden.json`, and the three examples `tdr-s1-output.example.json`, `tdr-s2-output.example.json`, `tdr-s3-synthesis.example.json` (the 7 Oct 2026 v3 run).

How the page is made: the template holds the approved layout, styles and chart code, and one data block. `build_dashboard.py` fills that block from the three JSON files and nothing else. It also works out the arrows and lights: each applies a fixed rule from the synthesis file to one published figure in S2, so nobody sets a direction or a colour by hand. Never edit the HTML by hand. If something on the page is wrong, fix the input file and rebuild.

Run Steps 11 to 14 in one go, with one stop after the data audit (Step 12), because what gets shown is Alvaro's call.

## Why the page looks the way it does (client feedback, 7 Oct 2026)

The audience are experts on these companies. The page demonstrates Moody's data; it does not offer a view the room can disagree with. So:
- No verdict on any company: no Winner, Neutral, Pressured, "best placed", "losing out" or "our read". The build and the eval fail on that wording.
- Instead, four indicators per company on published metrics that every name has. Two are arrows with no colour, because direction is a fact: revenue growth (two full years) and margin change on the prior year. Two are traffic lights with a stated threshold, because a level needs one: EBITDA margin and leverage (debt/EBITDA). Each shows its figure, period, basis, rule and source. Market share and like-for-like sales were considered and dropped: Moody's data holds them for one or two names only, and a light that is grey for most of the screen says nothing. The market figure Moody's does have (UK hospitality like-for-like sales, NIQ RSM) sits above the table as context.
- Every figure carries its basis ("As reported" or "Moody's-adjusted") and its period ("FY Dec-25", "LTM Mar-26").
- News is a plain statement of fact, two-sided where the source is. No positive or negative tags.
- The starting question sits at the top with QSR spelled out, and every research source is labelled as macro research, sector research or a credit opinion on a rated issuer.
- No bubble chart and no illustrative sensitivity: a calculated number that no source states invites the question "where is that from?".

## Rules

1. Only figures that appear in the S1 and S2 outputs go on the page. No new research, no estimates, no memory.
2. Source and date on every figure and every synthesis line. Mark "calculated" and "inference" where they apply.
3. No ratings column. Ratings, outlooks and thresholds appear only inside the credit opinion section and financing text.
4. Projections only where a source states them (Moody's forecasts, company guidance).
5. No Stonegate, Leon, supermarket or Burger King UK content anywhere, including in notes.
6. Plain English, no em dashes, no verdict wording, no dramatic verbs.

## Step 11. Synthesis: write `tdr-s3-synthesis.json`

Copy the field names of `tdr-s3-synthesis.example.json` exactly. From the S1 and S2 outputs only:

1. `companies`: one entry per S2 company, keyed by its `id`: `deal` (the live deal signal with source and date, or "None found"; a share suspension or a results date is not a deal signal), `changed` (up to three facts from the last 90 days, each with source and date, written as statements, with both sides where an announcement has both) and `latest` {text, src} (the latest development in one factual sentence, both sides where the source has both; it is the last column of the screen). No `read` and no `why`: the build stops if they are there.
2. `deal_signals`: live sale processes, stake sales and disposals reported in the sources, each {company, short (a few words for the KPI card), text, source}.
3. `refinancing`: refinancings or maturities inside 12 months, same fields.
4. `upcoming`: dated events (maturities, refinancings, site openings, cost programmes, results dates) sorted by date, each {when, what, src}. Do not source anything to an excluded publisher.
5. `month`: five items for the "This month" panel, each {co, t, s}; source in `s`.
6. `ticker`: five to seven one-line facts with source and short date.
7. `lights`: the rules, copied from the example unless Alvaro changes them. Arrows: revenue growth up if revenue rose 1% or more, flat within 1% either way, down if it fell 1% or more; margin change up if the margin rose 0.5 pts or more, flat within 0.5 pts, down if it fell 0.5 pts or more. Lights: EBITDA margin green 15% or more, amber 5% to 15%, red below 5%; leverage green below 3.0x, amber 3.0x to 5.0x, red above 5.0x or EBITDA negative. Keep the `note` saying the thresholds are set for the demonstration, not by Moody's.
8. `portfolio_read_across`: one sourced line per link to a current or former TDR portfolio company, or an empty list. This goes in the check log, not on the page.
9. `meta`: `title` (spell out QSR), `page_title`, `subtitle` (who it is for, how many names, "Moody's data only; news is third-party via Moody's NewsEdge. A demonstration, not an investment view."), `pulled` (the dates S1 and S2 were run), `tools`.
10. `as_of`: today's date.
11. `feed_extra` (optional): sector items that S2 found but could not file under a company, each with `date`, `publisher`, `headline`, `tag`, `metric`, `number`. They join the feed as "Macro and sector".

## Step 12. Data audit (STOP after this step)

Run:
`python3 build_dashboard.py --s1 tdr-s1-output.json --s2 tdr-s2-output.json --syn tdr-s3-synthesis.json --template tdr-dashboard-template.html --audit-only`

It prints the market context line, then per company the period and basis, the four indicators (arrows as up, down or flat; lights as G, A, R or - for grey; each with the figure), revenue years, cash flow, Moody's view, news kept, what changed and the latest development. Then every grey light and why, accounts older than 12 months, and listed names without cash flow. It stops with ERROR lines if an input is broken (a verdict word, a headline that is not neutral, a growth figure that compares an LTM with a calendar year, a research item without a type, a tool name in a source, a series of the wrong length, EBITDA equal to EBITA, an item without a source, an em dash); fix the input and run again. Show the audit and the WARN lines, ask Alvaro to confirm (AskUserQuestion if available, otherwise in text), and wait. Point out any company whose two lights are both one colour and both arrows point the same way, and the news that gives the other side, so he is ready for the question. Also list which names use group accounts and which use a single trading company (from `entities` and `series.note`).

## Step 13. Build

`python3 build_dashboard.py --s1 tdr-s1-output.json --s2 tdr-s2-output.json --syn tdr-s3-synthesis.json --template tdr-dashboard-template.html --out tdr-dashboard-YYYY-MM-DD.html --as-of YYYY-MM-DD`

It writes the page and runs a JavaScript syntax check when Node is available.

## Step 14. Check and publish

1. `python3 tdr_eval.py html tdr-dashboard-YYYY-MM-DD.html tdr-golden.json --s2 tdr-s2-output.json --as-of YYYY-MM-DD`. It checks excluded names, em dashes, verdict wording, literal undefined or NaN, network calls, that the As of date is today, that no old dates are left in the page code, all nine names, every company's figures against `tdr-s2-output.json`, that every arrow and light follows its rule and figure, that each has a period, basis and source, the market context line (a warning if missing), the starting question, and research types. Fix any FAIL in the inputs and rebuild.
2. If a headless browser is available, open the page, click each tab and open each company from the screen: the company page must scroll to the end, with no console errors and no sideways scroll at phone width. If not, say the visual check was skipped.
3. Read the synthesis lines once more against rules 2 to 6.
4. Publish the page as an artifact (the page carries Moody's branding; if the publishing tool declines, give Alvaro the HTML file instead). Send a short check log: eval result, the grey lights and why, any WARN lines, the portfolio read-across, and what changed since the last run (lights that changed colour, deal signals, counts).

## Reference: 7 Oct 2026 run (sanity check only)

Market context: UK hospitality like-for-like sales +0.5%, 12 months to Jul 2026 (NIQ RSM, cited in Moody's Credit Conditions – UK, 2 Sep 2026).
Indicators (growth arrow, margin light, margin change arrow, leverage light): Greggs up +6.8%, G 16.1%, down −1.6 pts, G 1.19x (debt mostly leases; company net cash before leases); Domino's up +3.1%, G 20.8%, down −6.0 pts, A 3.85x; Tortilla up +8.8%, R −3.0%, down −14.3 pts, R n.m.; PizzaExpress flat −0.5% (FY 2025 on FY 2024, Moody's-adjusted), G 19.1%, down −1.0 pts, R 5.4x; Wagamama down −4.2%, G 15.8%, up +9.2 pts (2024 EBITDA unusually low), R 7.19x; Gail's (group) up +20.0%, G 18.4%, flat −0.2 pts, R 6.44x; Itsu (FY Jan-26) up +2.8%, R 2.1%, up +1.5 pts, R 14.0x; Nando's (group) up +8.0%, G 19.4%, up +4.5 pts, A 4.55x; Pret (FY Jan-26) down −4.1%, A 6.0%, up +12.5 pts, R 6.69x.
Greggs' margin arrow points down, and that goes with its news: four manufacturing sites and about 740 roles proposed for closure, Derby and Kettering adding costs in 2027, greater inflationary pressure flagged for 2027, against sales +7.7% and a raised outlook.
Scope: Gail's and Nando's are group accounts (Grain Topco, Nando's Group Holdings); Pret is the UK trading company (the parent holds only debt); Itsu is the restaurant company (grocery files separately).
Deal signals: PizzaExpress possible sale at up to £500m (Marketline citing the FT, 21 Sep 2026); Bridgepoint appoints Goldman Sachs to sell its Itsu stake (Grocer citing Sky News, 10 Sep 2026); Wagamama's parent TRG selling its airport concessions to Areas (Marketline, 16 Jul 2026). Refinancing: Domino's £200m notes due Jul 2027, refinancing planned by end 2026 (H1 call, 4 Aug 2026).
Building the three example files reproduces the 7 Oct v3 page.
