---
name: tdr-s1-trigger
description: Stage 1 of the TDR Capital origination demo on Moody's data. Validates a macro or news trigger, traces how it reaches company results and maps the exposed UK sectors, ending at a sector choice. Also has a warm-up mode that pre-loads company filings so the live run does not wait. Use on /tdr-s1, /tdr-s1 warmup, or when Alvaro starts the trigger-to-dashboard workflow.
---

# TDR S1: trigger, chain, market map

Two modes, from the first word of the arguments:

- `/tdr-s1 warmup`: pre-load company filings only (Step 0), report "loaded" or "still loading" per company, stop. Do not summarise the filing text. Run it about 8 to 10 minutes before the live run, and again if it still says "still loading". Tested 7 Oct 2026: loading takes about 5 to 8 minutes, and a load lasts somewhere between about 13 and 21 minutes before it has to load again, so do not warm up much earlier than that.
- `/tdr-s1 [trigger]`: the full run. If no trigger is given, use "UK food inflation rising again, driven by energy costs".

Output of the full run: `tdr-s1-output.md` (tables for reading) and `tdr-s1-output.json` (what S3 reads to build the trigger panel). Copy the field names in `files/tdr-s1-output.example.json`, next to this SKILL.md, exactly. Send both files to Alvaro.

Run all steps in one go. Stop only at the end, for the sector choice. About 13 tool calls.

## Rules for every answer in this run

1. Moody's data only, through the Moody's MCP tools (research, credit opinions, Précis, Orbis company data, filings, NewsEdge news). No web search. News is third-party: give publisher and date every time. If a Moody's macroeconomic connector is present, find its tool names at runtime; if not, say "Macro connector not connected" once and carry on.
2. The lens is a private equity buyout fund (TDR Capital) looking for deal situations: take-privates, secondary sales, refinancings, stake sales, businesses under pressure.
3. Exclusions: never list or name Stonegate, Leon, Burger King or any supermarket (Tesco, Sainsbury's, Asda, Morrisons, Aldi, Lidl, Waitrose, Marks and Spencer, Ocado, Co-op). Pub company and supermarket documents will come back in sector searches; use them only for sector-level data points and never name the excluded company, including in document titles. Describe such a document generically, for example "Moody's credit opinion on a UK pub operator, 21 Jul 2026". Drop news stories whose subject is an excluded company.
4. Source and date on every figure. Mark calculations "calculated" and reasoning "inference". Write "n.d." for missing data. Never estimate or invent an impact number. Use only documents and figures that this run's tool calls returned: if a news item's returned text has no number, do not add one, and do not list research you know of but did not get back.
5. Separate what Moody's forecasts from what current data shows.
6. Compact tables, plain English, no em dashes. Today's date drives all ages and windows.
7. Label every research source by type, so the room knows what it is looking at: "Macro research" (economy-wide, e.g. State of the Consumer), "Sector research" (a sector in-depth, outlook or comment), "Credit opinion (rated issuer)" (a Moody's opinion on one rated company, even when you cite it for a sector figure), "Précis (macro)", "Company filing", "Company statement" (a trading update reported in the news), "News". Give the document title as well as the date.
8. Describe, never judge. The audience are experts on these companies. State what the sources say; no verdicts about companies and no dramatic wording.

## Entity IDs used in this skill

| Name | Entity ID |
|---|---|
| Greggs PLC | b3JnSWQ6bzAwMzkzNjI0NSNvcmJpc0lkOjAwMzkzNjI0NSNidmRJZDpHQjAwNTAyODUxI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Domino's Pizza Group PLC | b3JnSWQ6bzAwNDk0MTEzNSNvcmJpc0lkOjAwNDk0MTEzNSNidmRJZDpHQjAzODUzNTQ1I2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Tortilla Mexican Grill PLC | b3JnSWQ6bzUwOTczNDYxNSNvcmJpc0lkOjUwOTczNDYxNSNidmRJZDpHQjEzNTExODg4I2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |

For a different trigger and sector, resolve the two or three largest listed names in the sector with one `findEntity` call instead.

## Step 0. Start the filings loading (first calls of every run)

One `searchCompanyFilings` call per company (never several companies in one call: three companies returned 279,000 characters on 7 Oct), each with `filingTypes` ["interim"] (accepted values are only annual, interim and earnings_call_transcript), `reportYears` ["2026"] and `query` "cost inflation hedging forward cover market share visits outlook". Even one interim report returns about 50,000 characters, so keep only the lines you need. If a company says "ingesting", do not wait: carry on with Step 1 and Step 3 and come back in Step 2. Tortilla returns "not found" (no filings in the tool); that is expected. In warmup mode, report per company "loaded", "still loading" or "not in the filings tool" and stop.

## Step 1. Validate the trigger

Do not assume direction or size. Run in this order:

1. `searchAllDocuments`. Parameter names: `keywords` and `filter` with `publishDate` as "YYYY-MM-DD to YYYY-MM-DD", `regions` and `sectors` as plain names. Sector names that work (tested 7 Oct 2026): "Restaurants" (casual dining, quick service and pubs), "Fast Food", "Packaged Foods", "Business Services" (contract catering). "contract catering" and "Food Distribution" return nothing at all, which is not the same as no research: use a working name or keywords without a sector. Pass `chunks` 3 to keep responses short. Two calls: (a) keywords on the trigger (for food inflation: "UK food inflation outlook energy costs consumer"), last 90 days, regions ["United Kingdom"]; (b) keywords on the downstream sector (for food inflation: "UK restaurants casual dining consumer demand costs"), last 12 months, sectors ["Restaurants"], regions ["United Kingdom"]. Tested 7 Oct 2026: (a) returned the State of the Consumer (29 Sep 2026) and the UK grocery in-depth (6 Aug 2026); (b) returned the Wagamama opinion and pub company documents. Then (c), market context (a line above the company screen, not a light): keywords "NIQ RSM Hospitality Business Tracker like-for-like sales UK hospitality restaurants", last 120 days, no sector filter, `chunks` 3. Take the newest figure for the wider UK hospitality market, with its period and the Moody's document that cites it. 7 Oct 2026: Moody's Credit Conditions – UK (sector research, 2 Sep 2026) cites NIQ RSM: hospitality like-for-like sales +0.5% and pubs +1.9% in the 12 months to July 2026. If the newest figure sits in a document about an excluded company, describe the document generically and look for the same figure in another document first.
2. `searchPrecisReports` with keywords "United Kingdom inflation consumer spending outlook". There is no sort; keep only rows titled "United Kingdom" and take the newest by date. Give its vintage and publish date. If it predates the current shock (the 2026 energy shock for this run), say so and do not use it as the current macro view. Tested 7 Oct 2026: newest is the December 2025 vintage, published 16 Jan 2026.
3. Macro connector, if present: UK food CPI, headline CPI, retail sales volumes, household consumption, average weekly earnings, consumer confidence, monthly, last 24 months.
4. `searchNews` without entities: `query` on the trigger (for food inflation: "UK grocery inflation shop price index food prices Britain"), `searchType` "hybrid", `rerankResults` true, `timeRange` "past30days", `maxResultsPerEntity` 30. Keep stories about the UK, whatever the publisher's country (a US paper carrying a UK story counts). Count two reports of the same release once. Report kept out of fetched; expect about 5 of 30. Do not use keyword search with sortBy recency for topic news: it returned nothing from the UK. Drop share-price pieces and the publishers Stockpulse, Ad Hoc News, MarketBeat, Watchlist News and The Markets Daily.

Output: evidence table (claim, figure, source, date, direction up/down/flat), one line separating Moody's forecast from current data, then a one-line verdict: confirmed, partly confirmed, or not supported. "Partly confirmed" means Moody's expects it but current data has not shown it yet.

## Step 3. Market map (run before Step 2 so the filings have time to load)

Map the trigger across UK sectors downstream of it, leaving out food retail. For food inflation consider: quick-service and food-to-go, casual dining, coffee and bakery chains, pubs and bars, contract catering, food distribution to foodservice, packaged food.

For each sector: channel (input cost, demand, labour, financing), Moody's research in the last 12 months (title and date, or "none found", applying rule 3 to titles) via `searchAllDocuments` with a working sector name from Step 1 in `filter.sectors` and regions ["United Kingdom"], one line of evidence, exposure (high, medium, low, unclear). The "Restaurants" results from Step 1 already cover casual dining and pubs; reuse them. For food distribution no sector name works; say "none found" unless a keyword search returns something relevant.

Recommend one segment for the dashboard in two lines. Name it in full the first time, with abbreviations spelled out: for this trigger, "UK quick service restaurants (QSR) and casual dining" (QSR means fast food, takeaway and food-to-go counters; casual dining means sit-down, mid-priced chains). Pubs were left out because they bring in Stonegate.

## Step 2. Transmission chain

Trace the trigger to company results in four links. For food inflation: energy costs rise > food input costs follow, with a delay > consumers trade down > lower-priced formats gain share, while higher-priced and more indebted operators face cost and demand pressure at once. The last link is a hypothesis for the company screen to test, not a finding: always INFERRED unless a source states it.

For each link give the evidence with date and a status: SOURCED (a Moody's document or company filing states it), PLAUSIBLE (evidence points that way), INFERRED (our reasoning only). Use the Step 0 filings results (Greggs for cost inflation, forward cover and Circana visit data; Domino's for hedging); if a company said "ingesting", call it again now with the same inputs, then every 30 seconds up to six times. If it is still loading, say "filings still loading" for the links that need them, mark them INFERRED, and finish; do not hold the run longer. Stop at the first link with no support and say so.

## Finish

1. Write `tdr-s1-output.md`: the starting question, trigger, evidence table (with the type of each source), verdict, chain with statuses, market map, market context figure, recommended segment, and a seed list of 8 to 12 UK chains in that segment across listed, sponsor-owned, credit-fund-owned and family-owned (for UK QSR and casual dining: Greggs, Domino's Pizza Group, Tortilla Mexican Grill, PizzaExpress, Wagamama, Gail's, Itsu, Nando's, Pret A Manger). Give the seed list as a table: name, format (QSR or casual dining), ownership type, why it is in (which ownership type it covers) and what Moody's holds on it (credit opinion if rated; Orbis accounts; filings if listed). This answers "how were these names chosen?" in the meeting.
2. Write `tdr-s1-output.json` with the example's fields: `as_of`, `trigger`, `question` (the starting question in one sentence, abbreviations spelled out), `glossary` (one line defining QSR and casual dining), `selection` (two sentences on how the names were chosen), `verdict`, `macro_connector`, `segment`, `seed_list`, `market` {`benchmark` {label, value, period, period_end, source, kind} (the JSON key is `benchmark`; the page shows it as a market context line, not a light), `context` [up to three {text, src, kind}]}, `kpi` (the headline trigger figure for the KPI card), `panel` (title, badge, headline with the key figures in `**bold**`, verdict chip text, the current-data line, four `steps` with `status` SOURCED, PLAUSIBLE or INFERRED, and up to three `evidence` items each for `research`, `macro`, `news`, `filings`, each with `kind` (rule 7), `title` for research, `text` and `src`), `news_kept` {kept, fetched, note}, and `feed` (the kept macro and sector news and research items, each with `date`, `publisher`, `headline` written as a plain statement of fact, `tag` Costs, Demand or Other, `metric`, `number` only if the source gives one; no `direction`). Put company trading statements that speak to the trigger in `filings` with kind "Company statement" (7 Oct: Greggs flagged signs of greater inflationary pressure in 2027, Proactive Investors, 1 Oct 2026).
3. Send both files. Ask Alvaro to confirm or change the segment and seed list, then run `/tdr-s2`. Do not start S2 yourself.

## Reference: what the runs found (sanity check, not data)

- Moody's UK grocery sector in-depth, 6 Aug 2026: food inflation to around 5% by early 2027 from 1.7% in the 12 months to June; nowhere near the 17.5% peak of 2022.
- Moody's State of the Consumer Europe, 29 Sep 2026: UK inflation 3.1%; real private consumption about 1.0% in 2026 and 0.7% in 2027; Strait of Hormuz closure and crude spike.
- Moody's Wagamama credit opinion, 19 Jan 2026: UK restaurants had negative sales growth in 10 of the 11 months to Nov 2025 (NIQ).
- Newest UK Précis: December 2025 vintage, published 16 Jan 2026, predates the energy shock. Not used.
- News, 6 Oct run: grocery inflation 2.3% (Worldpanel, 15 Sep); BRC shop price inflation eased to 1.4% in September (MSN, 4 Oct); UBS cut UK grocery growth forecast to 2.5% from 4% (Proactive Investors, 21 Sep); restaurant sales recovered in August (NIQ via MarketScreener, 17 Sep).
- News, 7 Oct rerun: the 1.4% shop price item came via MarketLine (4 Oct); the Worldpanel item came via Farmers Journal (15 Sep) with no figure in the returned text; a new UK item said food inflation could rise above 6% next year, according to industry (carried by The Sacramento Bee, 9 Sep). The UBS and NIQ items of 6 Oct did not come back. Results vary between runs; that is fine.
- Filings, 7 Oct: Greggs H1 cost inflation 2.2%, about 50% of 2027 energy covered, 2026 capex cut to about £180m, food-to-go visits down 1.9% while Greggs' share rose to 8.7% (Circana); Domino's hedged for 2026 into 2027, £200m notes due July 2027 to be refinanced by year end.
- Market context, 7 Oct: UK hospitality like-for-like sales +0.5%, 12 months to Jul 2026 (NIQ RSM, cited in Moody's Credit Conditions – UK, 2 Sep 2026). Context: pubs +1.9%; UK food-to-go visits −1.9%, 12 months to Jun 2026 (Circana via Greggs interim); UK restaurants negative in 10 of 11 months to Nov 2025 (NIQ via the Wagamama opinion).
- Greggs Q3 trading update (30 Sep and 1 Oct 2026, Proactive Investors): 2026 cost inflation about 2%, signs of greater inflationary pressure in 2027. The returned text did not tie it to energy; do not add that.
- Verdict: partly confirmed. Chain links 1 and 2 SOURCED. Link 3 was INFERRED on 6 Oct and PLAUSIBLE on 7 Oct (Moody's grocery in-depth says consumers are scaling back out-of-home dining; Greggs gained share as visits fell). Link 4 INFERRED.
