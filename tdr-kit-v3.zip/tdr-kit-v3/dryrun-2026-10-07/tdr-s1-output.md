# TDR S1: trigger, chain, market map (run 7 Oct 2026)

Trigger: UK food inflation rising again, driven by energy costs. Macro connector not connected.

## Evidence

| Claim | Figure | Source | Date | Direction |
|---|---|---|---|---|
| UK food inflation will rise again, with a lag to energy | ~5% by early 2027 from 1.7% (12 months to June) | Moody's UK grocery sector in-depth | 6 Aug 2026 | up (forecast) |
| Not near the 2022 peak | peak was 17.5% | Moody's UK grocery sector in-depth | 6 Aug 2026 | n/a |
| UK headline inflation | 3.1% | Moody's State of the Consumer, Europe | 29 Sep 2026 | up |
| UK real private consumption growth | ~1.0% (2026), ~0.7% (2027) | Moody's State of the Consumer, Europe | 29 Sep 2026 | down (forecast) |
| UK restaurants negative sales growth | 10 of 11 months to Nov 2025 (NIQ) | Moody's Wagamama credit opinion | 19 Jan 2026 | down |
| Shop price inflation (BRC) | 1.4% in Sep, from 1.5% in Aug | MarketLine | 4 Oct 2026 | down |
| Grocery prices (Worldpanel) | edged up, 4 weeks to 6 Sep (no figure given) | Farmers Journal | 15 Sep 2026 | up |
| Industry forecast for food inflation | above 6% next year | The Sacramento Bee | 9 Sep 2026 | up (forecast) |
| Newest UK Précis | December 2025 vintage | Moody's Précis | 16 Jan 2026 | predates the energy shock; not used |

Moody's forecast: food inflation to about 5% by early 2027. Current data: shop prices easing (1.4%) and grocery prices only edging up.
**Verdict: partly confirmed.** Moody's expects the rise; current prices have not shown it yet.

News: 5 UK stories kept out of 30 fetched (topic search, last 30 days).

## Transmission chain

| # | Link | Evidence | Status |
|---|---|---|---|
| 1 | Energy costs rise | Strait of Hormuz closure, crude spike, UK inflation 3.1% (Moody's, 29 Sep 2026) | SOURCED |
| 2 | Food input costs follow, with a delay | Food inflation to ~5% by early 2027; follows energy with a significant delay (Moody's, 6 Aug 2026) | SOURCED |
| 3 | Squeezed consumers trade down | Consumers scaling back out-of-home dining (Moody's, 6 Aug 2026); food-to-go visits -1.9% while Greggs' share rose to 8.7% (Circana, Greggs interim, 29 Jul 2026) | PLAUSIBLE |
| 4 | Cheaper formats gain; pricier, indebted operators hit twice | Casual dining faces discounting and quick-service competition (Wagamama opinion, 19 Jan 2026); to be tested on the names | INFERRED |

Hedging context (filings): Greggs H1 cost inflation 2.2%, ~70% of H2 food and packaging bought forward, ~50% of 2027 energy covered (interim, 29 Jul 2026). Domino's: all major cost lines hedged for 2026 and into 2027 (H1 results, 4 Aug 2026). Tortilla: no filings in the filings tool.

## Market map

| Sector | Channel | Moody's research, last 12 months | Evidence | Exposure |
|---|---|---|---|---|
| Quick-service and food-to-go | input cost, demand | none found for UK names (the sector filter returned only an Iberian quick-service franchisee) | Food-to-go visits -1.9% (Circana, via Greggs, 29 Jul 2026) | high |
| Casual dining | demand, labour, financing | Wagamama credit opinion, 19 Jan 2026 | Discounting and quick-service competition (Moody's, 19 Jan 2026) | high |
| Coffee and bakery chains | input cost | none found | Greggs: 2.2% H1 cost inflation, hedged into 2027 (29 Jul 2026) | medium |
| Pubs and bars | demand, labour | Sector comment on the UK business-rates cut for pubs, 24 Jul 2026; credit opinions on UK pub operators (excluded names) | Pubs outperforming restaurants on lower spend per visit (Moody's credit opinion on a UK pub operator, 21 Jul 2026) | medium (out of scope) |
| Contract catering | input cost | Compass Group key facts, 9 Feb 2026 | Contract caterers pass on price increases (Moody's on a US peer, 20 Oct 2025) | low |
| Food distribution to foodservice | input cost, demand | none found | n.d. | unclear |
| Packaged food | input cost | Packaged Food Europe in-depth, 6 Aug 2026 | Higher energy and raw material costs; weak sentiment limits price pass-through (6 Aug 2026) | medium |

**Recommended segment: UK eating out (food-to-go, quick-service and casual dining chains).** Directly exposed on both costs and demand, with a mix of listed, sponsor, credit-fund and family owners. Pubs left out because they bring in an excluded name.

## Seed list

Greggs, Domino's Pizza Group, Tortilla Mexican Grill, PizzaExpress, Wagamama, Gail's, Itsu, Nando's, Pret A Manger.

Next: confirm or change the segment and seed list, then run `/tdr-s2 names`.
