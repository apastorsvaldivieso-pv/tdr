# TDR Capital on Moody's data: prompt pack, macro trigger to dashboard

Workflow 1 (origination): macro and news trigger > transmission chain > sector > names > evidence > dashboard.
Worked example: UK food inflation and UK quick service restaurants (QSR) and casual dining. Output: the "UK QSR and casual dining" dashboard (Overview, Company, News and events, Sources).

Version: 3, 7 Oct 2026, after client feedback: no verdicts on companies; a traffic light per company on published metrics with stated thresholds; basis and period on every figure; neutral, two-sided news; the starting question at the top; research labelled by type; no bubble chart or illustrative sensitivity. Version 2 was Built backwards from the published dashboard, so every step produces something the page uses. Tool parameters rechecked against the Moody's MCP on 7 Oct 2026. The skills (tdr-s1, tdr-s2, tdr-s3) now automate this pack and build the page with build_dashboard.py; use this pack to run steps by hand or to read the logic.

---

## How to use this pack

1. **One step per message.** Moody's entity search (findEntity) works once per message, so steps that need entity IDs are split (4a, 4b).
2. **Replace anything in [square brackets].** The brackets hold this run's values; swap them to run a different trigger or sector.
3. **CHECKPOINT steps stop and wait.** Read the table, compare it with Appendix A, correct it, then send the next step. Appendix A holds the values from the 6 Oct 2026 run, so a mismatch is either new data (fine, note it) or a wrong entity (fix it).
4. **Run Steps 1 to 12 the day before the demo.** Filings can take minutes to load and news needs hand filtering. Step 13 builds the page from the confirmed tables. Step 14 is the check.
5. **Live in the meeting**, show Step 1 (trigger), Step 3 (market map) and one company from Step 7 or 10, then open the finished dashboard. Do not build the page live.
6. **If the chat gets long**, start a new one, resend Step 0, and paste the last confirmed table.

---

## Step 0. Rules (first message of every chat)

```
For this chat, follow these rules in every answer.

1. Sources. Moody's data only, through the Moody's MCP tools: research, credit opinions, Orbis company data, ownership, managers and directors, financials, company filings and earnings call transcripts, and Moody's NewsEdge news. No web search. News is third-party: always give publisher and date. If a Moody's macroeconomic connector is available, find its tool names at runtime; if it is not connected, say so and carry on.

2. Lens. You are working for a private equity buyout fund, [TDR Capital], looking for deal situations: take-privates, secondary sales, refinancings, stake sales, and businesses under pressure. Current and former [TDR] portfolio companies: [PizzaExpress (former, 2003 take-private), Stonegate, Leon, Asda]. Flag any portfolio link you see; do not assume one.

3. Exclusions. Do not research, list or mention [Stonegate], [Leon] or any supermarket ([Tesco, Sainsbury's, Asda, Morrisons, Aldi, Lidl, Waitrose, Marks and Spencer, Ocado, Co-op]). If one appears in a result, drop it silently. Supermarket data may be used only as macro evidence (for example a grocery inflation figure), never as a company row.

4. Ownership. Ownership type is the organising principle, not ratings: listed (route: take-private), sponsor or credit-fund owned (route: secondary sale or refinancing), family-owned (route: succession or primary deal). Show the ownership chain and its source. Where sources disagree, show both and flag "Sources disagree". Where Orbis stops at a holding company or SPV, flag "Orbis stops at a holding company". Where only Orbis gives the owner, flag "Orbis only".

5. Ratings. No ratings column. A rating, outlook or downgrade trigger appears only as context for a financing event (a maturity, a refinancing, a sale).

6. Projections. Forecasts only where a source states them (Moody's forecast, company guidance), with source and date. Never project, extrapolate or invent an impact number.

7. Financials. Use the latest available period and show its end date and age in months. Label the basis on every number: "Moody's format" (Moody's Ratings Format, as reported), "filed" (Orbis Standard Format) or "Moody's-adjusted" (credit opinions). Bases are not like-for-like; say so when comparing. Pull key indicators only unless I ask for a section.

8. EBITDA rule. If EBITDA equals EBITA (no depreciation captured), say so and do not use that EBITDA for margin or leverage.

9. Evidence. Give source and date for every figure. Mark anything calculated as "calculated" and anything inferred as "inference". Write "n.d." where data is missing. Never estimate. If a tool fails or returns nothing, retry once, then report it.

10. Named-name rule. Every company I name must appear in the output, with data or with a one-line reason why there is none.

11. Entity rule. After any name match, check the profile: it must be the UK operating business or the right group parent. If the match is a bank, a finance vehicle, a different country or a holding company, say so and find the right entity. Research, accounts and news may sit on different entities of the same group; name each.

12. News. Search by entity, not by topic (topic search has no geography). Fetch by recency, then filter by hand. Drop share-price and ticker articles, product launches and recalls, and the publishers Stockpulse, Ad Hoc News, MarketBeat, Watchlist News and The Markets Daily. Kalkine and Motley Fool are commentary: use them only to point to a primary item. Always report kept out of fetched.

13. Format. Compact tables. Plain English, no jargon. No em dashes.

14. Date. Today is [7 October 2026]. Use it to compute ages and windows.

Reply "Rules set" and nothing else.
```

---

## Part A. Trigger

### Step 1. Validate the trigger

```
Trigger to test: [UK food inflation rising again, driven by energy costs]. Do not assume its direction or size.

Run, in this order:
1. searchAllDocuments, query "[UK food inflation outlook energy costs consumer]", publishDate last 90 days, regions ["United Kingdom"]. Then a second call with query "[UK restaurants casual dining consumer demand costs]", sectors ["Restaurants"], last 12 months. If the sector filter rejects the value, drop the filter and keep the query.
2. searchPrecisReports with keywords "[United Kingdom] inflation consumer spending outlook". It has no sort, so keep only rows titled "[United Kingdom]" and take the newest by date. Give the vintage and publish date. If it predates [the 2026 energy shock], say so and do not use it as the current macro view.
3. The Moody's macroeconomic connector, if available: [UK food CPI, headline CPI, retail sales volumes, household consumption, average weekly earnings, consumer confidence], monthly, last 24 months. If not connected, say "Macro connector not connected" and move on.
4. searchNews, query "[UK grocery inflation shop price index food prices Britain]", searchType hybrid, rerankResults true, timeRange past30days, maxResultsPerEntity 30. (Keyword search sorted by recency returned nothing from the UK.) Keep stories about the UK whatever the publisher's country, and report kept out of fetched.

Output:
- Evidence table: claim, figure, source (Moody's research, Précis, macro series, or news with publisher), date, direction (up, down, flat).
- Separate what Moody's forecasts from what current data shows.
- One-line verdict: confirmed, partly confirmed, or not supported. "Partly confirmed" means Moody's expects it but current data has not shown it yet.
```

**Expect (6 Oct run):** Moody's UK grocery in-depth, 6 Aug 2026: food inflation from 1.7% (12 months to June) to around 5% by early 2027. State of the Consumer Europe, 29 Sep 2026: UK inflation 3.1%, real consumption about 1.0% (2026) and 0.7% (2027). Précis December 2025 vintage, too old. News: Worldpanel grocery inflation 2.3% (15 Sep), shop prices 1.4% in September (MSN, 4 Oct), UBS cut grocery growth forecast to 2.5% (Proactive, 21 Sep), NIQ restaurant sales recovered in August (17 Sep). Verdict: partly confirmed.

### Step 2. Transmission chain

```
Trace how the trigger from Step 1 reaches company results, one link at a time:
[energy costs rise] > [food input costs follow, with a delay] > [squeezed consumers trade down] > [cheaper formats gain share; pricier and heavily indebted operators are hit on both costs and demand].

For each link: the evidence (Moody's research, macro series, news or company filing) with date, and a status:
- SOURCED: a Moody's document or company filing states it.
- PLAUSIBLE: evidence points that way but does not state it.
- INFERRED: our reasoning only.

Also search company filings of [Greggs PLC] and [Domino's Pizza Group PLC] for cost inflation, hedging and food-to-go market data, to test the trade-down link. Stop at the first link with no support and say so. Keep the chain to four links.
```

**Expect:** links 1 and 2 SOURCED; links 3 and 4 INFERRED (support: food-to-go visits fell 1.9% while Greggs gained share, Circana via Greggs interim results, 29 Jul 2026).

### Step 3. Market map (CHECKPOINT)

```
Map the trigger across UK sectors that sit downstream of food and consumer spending, excluding food retail (supermarkets are out of scope). Consider: [quick-service and food-to-go, casual dining, coffee and bakery chains, pubs and bars, contract catering, food distribution to foodservice, packaged food].

For each sector: channel (input cost, demand, labour, financing), Moody's research on it in the last 12 months (title and date, or "none found"), one line of evidence, exposure (high, medium, low, unclear). Use searchAllDocuments with sector filters.

Then recommend one segment for the dashboard and say why in two lines. Stop and wait.
```

**Decision taken on 6 Oct:** [UK eating out: food-to-go, quick-service and casual dining chains]. Pubs left out (they bring in Stonegate). Confirm or change before Step 4.

---

## Part B. Names

### Step 4a. Candidate list

```
For [UK eating out: food-to-go, quick-service and casual dining], list the 10 to 14 largest UK-headquartered chains you would expect a buyout fund to screen, across listed, sponsor-owned, credit-fund-owned and family-owned. Seed list (must be checked): [Greggs, Domino's Pizza Group, Tortilla Mexican Grill, PizzaExpress, Wagamama, Gail's, Itsu, Nando's, Pret A Manger]. Add any others with a reason. Apply the exclusions in Step 0.

Output: trading name, expected legal name, expected ownership type, one line on exposure to the Step 2 chain. Do not call any tool yet.
```

### Step 4b. Match and verify (CHECKPOINT)

```
Run findEntity once for all of these legal names, with getAlternatives true and maxAlternatives 3:
[Greggs PLC; Domino's Pizza Group PLC; Tortilla Mexican Grill PLC; PizzaExpress; Wagamama (Holdings) Limited; Gail's Limited; Itsu Limited; Nando's Chickenland Limited; Pret A Manger (Europe) Limited; Pret A Manger Limited; Wheel Bidco Limited]

Then getEntityProfile for every match. Apply the entity rule.

Table 1: trading name, matched legal name, entity ID, country, listed or private, role (operating company, financing entity, parent), and what this entity is used for (research, accounts, ownership, news).
Table 2: names that did not resolve or resolved wrongly, with the reason and the fix.

Note: one group can need several entities. PizzaExpress research sits on Wheel Bidco Limited, ownership and profile on Pizzaexpress (Restaurants) Limited, news on Pizzaexpress Limited. Pret accounts sit on Pret A Manger (Europe) Limited; parent debt and news on Pret A Manger Limited. "PizzaExpress" now resolves to PizzaExpress Financing 2 plc, a dormant finance vehicle with a withdrawn rating: use the alternatives (Wheel Bidco Limited in Jersey, not the UK business-services company of the same name).
Stop and wait.
```

**Check against Appendix A, section A1.** Nine companies, twelve entity IDs.

### Step 5. Ownership (CHECKPOINT)

```
For each of the nine, using the entity IDs confirmed in Step 4b:
1. getEntityUltimateOwners with minimumOwnershipThreshold 25.01.
2. getEntityShareholders for the direct level.
3. For PizzaExpress and Wagamama, the ownership described in the latest Moody's credit opinion.
4. Where Orbis and Moody's research disagree, or Orbis stops at a holding company, one searchNews call for that entity over past365days, query "[owner acquisition sale stake]".

Table: company, ownership type (listed, sponsor-owned, credit-fund owned, family-owned), chain (up to three levels plus top owner), source for each level with date, flag (Sources disagree / Orbis stops at a holding company / Orbis only / none), likely deal route (take-private, secondary sale or refinancing, succession or primary deal).
Flag any current or former [TDR Capital] link and its source. Stop and wait.
```

**Expect:** PizzaExpress: Moody's (2 Jul 2026) names Bain Capital Credit, Cyrus and Glendon with 61%; Orbis stops at Wheel Topco (Jersey). Flag Sources disagree. Former TDR portfolio (2003 take-private), no current TDR link found in Moody's data. Wagamama: Moody's says TRG, owned by Apollo since Dec 2023; Orbis shows Unicorn Topco and Levine Leichtman. Sources disagree. Itsu: Orbis shows Bridgepoint via Butterfly 21 Bidco at 100%; news says a minority stake. Sources disagree. Gail's: Grain Topco and Bain Capital Credit JJJ Fund, Orbis only. Nando's: "L. Perlman SECS", Orbis only, needs checking. Pret: Reimann family via Agnaten SE.

### Step 6. Management

```
For each of the nine: getEntityManagersDirectors_v2 with includeDetails true. Give CEO and CFO names, start date and the "last confirmed" date. For the three listed names, check against the latest annual or interim report (searchCompanyFilings) and news from the last 90 days. Where they differ, show both with sources. Flag any record older than 12 months. Never name a CEO from memory; if no source gives a CEO role, write "n.d.".
```

**Expect:** Greggs: Roisin Currie CEO (director data still says "designate"; filings say CEO), CFO Richard Hutton. Domino's: Nicola Frampton (H1 call, 4 Aug 2026; director data lists other names with the CEO role and is out of date). Tortilla: Brandon Stephens, founder and CEO; CFO Richard Haley in filings, Andrew Naylor in director data (show both). Private names: no CEO role in the data, so n.d.

---

## Part C. Evidence

### Step 7. Financials

```
For each of the nine, getEntityFinancials_v2 with filterCriteria periods ["2025","2024","2023","2022","2021"] and sections ["key_indicators"], excludeInterimData true. For the three listed names also sections ["cash_flow_statement"] for the last two years.

Table per company, one row per year: period end, basis, revenue, revenue growth, EBITDA, EBITDA margin, total debt, debt/EBITDA, cash from operations and capex (listed only), free cash flow = CFO minus capex (calculated, listed only).
Then a summary table, latest period only: company, period end, age in months, basis, revenue, growth, EBITDA, margin, debt/EBITDA.

Rules: apply the EBITDA rule. If EBITDA or revenue swings more than 50% year on year, look for an impairment or a one-off in filings or news and note it. If a year is missing, leave it out; do not fill it.
If a name comes back without EBITDA or debt (Itsu on 7 Oct), call it alone with sections ["balance_sheet"] and source "standard": the Detailed Financials give Ebitda, Loans and Long Term Debt (debt = loans plus long-term debt, calculated).
The summary period is the newest of the filed or Moody's format accounts and the credit opinion's LTM column: PizzaExpress uses the opinion (LTM Mar 2026); Wagamama uses its filed Dec 2025 accounts.
For cash flow, ask only for accountNames ["Cash Flow From Operations","Cash payments to acquire PP&E and Intangibles"] with reportingBasis "reported"; capex is the PP&E and intangibles line.
```

**Check against Appendix A, section A2.**

### Step 8. Moody's research for the rated names

```
For [Wheel Bidco Limited (PizzaExpress)] and [Wagamama (Holdings) Limited]:
1. getCreditOpinion with sections ["Summary","KeyIndicatorsTable","FactorsLeadingToUpgrade","FactorsLeadingToDowngrade"].
2. searchAllDocuments for any newer Moody's document on the entity (issuer comment, rating action), newest first.

Give: date of the opinion, Moody's-adjusted key indicators (latest and forecast years, labelled "Moody's forecast"), upgrade and downgrade thresholds, debt structure and maturities, liquidity, and the main credit view in two lines. If the opinion is older than 6 months, say so and let newer documents override it. These are context for financing events only, not a ratings column.
```

**Expect:** PizzaExpress (2 Jul 2026): LTM Mar 2026 revenue £444.4m, margin 19.1%, 5.4x, EBIT/interest 0.9x; forecast leverage 5.4x and 5.2x, cover 0.9x and 1.0x; £280m 9.875% notes due Sep 2029; £30m RCF due Mar 2029 with £7.5m drawn; cash £13.5m. Wagamama (19 Jan 2026): 6.6x LTM Sep 2025; forecast 2026 leverage 5.9x, cover 1.3x; outlook negative; downgrade if above 5.5x or below 1.5x cover; upgrade if below 4.5x and above 2.0x.

### Step 9. Filings and calls for the listed names

```
For [Greggs PLC], [Domino's Pizza Group PLC] and [Tortilla Mexican Grill PLC]: searchCompanyFilings, one company per call (two companies returned 279,000 characters), with filingTypes ["annual","interim","earnings_call_transcript"] (the only accepted values), query "[cost inflation hedging food energy outlook like-for-like sites refinancing]". If the tool says "ingesting", wait 30 seconds and retry, up to eight times (loading took 6 to 8 minutes on 7 Oct). If a call is still missing, search NewsEdge for the Aiera transcript of that call.

Per company, with document and date for each line:
- Cost exposure and hedging (what share of costs is bought forward, for how long).
- Demand signals (like-for-like sales, market share, visits).
- Guidance, with date. If later guidance replaced earlier guidance, use the latest and say what it replaced.
- Debt, maturities and refinancing plans.
- Cost of sales for the latest full year, where disclosed.
```

**Expect:** Greggs: cost inflation 2.2% in H1; about 70% of H2 food and packaging bought forward; about 50% of 2027 energy covered; 2026 capex about £180m; FY2025 cost of sales £829.1m (interim report comparatives); July H2 profit guidance superseded by the 30 Sep update. Domino's: fully hedged on key cost items for 2026 with some cover into 2027; £200m notes due Jul 2027 to be refinanced by end 2026 (H1 call, 4 Aug). Tortilla: shares suspended 1 to 27 Jul 2026; H1 call via Aiera in NewsEdge (1 Oct).

### Step 10. News per company (CHECKPOINT)

```
For each of the nine, using the news entity IDs from Step 4b:
Pass 1: searchNews with importance "significance", timeRange "past30days", sortBy recency, maxResultsPerEntity 100, no query. (With 30, share-price bots filled the cap for Greggs and the window stopped early.)
Pass 2: searchNews with searchType "hybrid", rerankResults true, timeRange "past90days", query "[results trading update sales profit outlook sale stake refinancing]".

Filter by hand. Keep: results, trading updates, prices, sites, ownership, management, financing, suppliers, regulation. Drop under the Step 0 news rule.

Table per company: date, publisher, headline (a plain statement of fact, both sides where the source has both, no verdict or dramatic verbs), tag (Results, Deal, Costs, Demand, Sites, Other), metric hit, number only if the article gives it. Then a line per company: kept X of Y fetched.
Stop and wait.
```

**Expect (6 Sep to 6 Oct):** Greggs 1 of 12 (Q3 sales +7.7%, like-for-like +3.4%, outlook raised, four factories and about 740 jobs under review, Proactive 30 Sep). Domino's 1 of 30. Tortilla 3 of 10. PizzaExpress 1 of 1 (sale at up to £500m, Marketline citing the FT, 21 Sep). Wagamama 2 of 10. Gail's 2 of 10. Itsu 1 of 1 (Bridgepoint to sell minority stake, Marketline 9 Sep). Nando's 1 of 1. Pret 1 of 15. Counts will change on refresh; that is fine.

---

## Part D. Synthesis

### Step 11. Reads, changes and deal signals

```
Using only Steps 1 to 10:

1. No verdict per company. The page shows four indicators per company on published figures, with fixed rules stated on the page. Arrows, no colour: revenue growth over two full years (up 1% or more, flat within 1%, down 1% or more); margin change on the prior year (up 0.5 pts or more, flat within 0.5 pts, down 0.5 pts or more). Lights: EBITDA margin (green 15% or more, amber 5% to 15%, red below 5%); leverage, debt/EBITDA (green below 3.0x, amber 3.0x to 5.0x, red above 5.0x or EBITDA negative). Only metrics every name has; market share and like-for-like sales are in Moody's data for one or two names only. Each light shows figure, period, basis, rule and source.
2. What changed in the last 90 days: up to three items per company, each with source and date, from news, filings or research.
3. Deal signals: live sale processes, stake sales, refinancings due inside 12 months. Source and date for each.
4. Coming up: dated events (maturities, refinancings, site openings, cost programmes), sorted by date, source for each.
5. No illustrative sensitivity: the room asks where a number comes from, and this one is not in any source.
6. Portfolio read-across for [TDR Capital]: one line on any link to current or former portfolio companies, sourced, or "none found".
7. Top five items for a "This month" strip.
```

**Expect (7 Oct, growth arrow / margin light / margin change arrow / leverage light):** Greggs up G down G; Domino's up G down A; Tortilla up R down R; PizzaExpress flat G down R; Wagamama down G up R; Gail's (group) up G flat R; Itsu (FY Jan-26) up R up R; Nando's (group) up G up A; Pret (FY Jan-26) down A up R. Market context: UK hospitality like-for-like sales +0.5%, 12 months to Jul 2026 (NIQ RSM, cited in Moody's Credit Conditions – UK, 2 Sep 2026).

### Step 12. Data audit (CHECKPOINT)

```
Before building, audit what we have. For each company and each element the page will show, mark: have (with source and date), n.d., or flagged.

Elements: ownership chain, management, revenue (years available), EBITDA (years available), margin, debt/EBITDA, cash flow, Moody's view, forecasts, news kept, what changed, next event, read.

Then list every chart that would have fewer than two data points as "will not be shown", and every table row that would be all n.d. as "will be dropped". List companies whose latest accounts are older than 12 months. Stop and wait.
```

**Expect:** no annual chart for Tortilla, Itsu or Pret where fewer than two points come back; no Moody's view outside PizzaExpress and Wagamama; no cash flow outside the listed three; Gail's, Itsu, Nando's and Pret accounts older than 12 months.

---

## Part E. Build

### Step 13. Build the dashboard

```
Build one self-contained HTML page from the confirmed tables in Steps 1 to 12 only. Data written into the page as a JavaScript object. No external libraries, no network calls when opened. Charts as inline SVG. Publish it as an artifact.

HEADER
- Navy bar (#1A0055), title "[UK Eating Out]", subtitle "[TDR Capital] origination screen on Moody's data", "As of [7 Oct 2026]".
- A scrolling ticker of the five "This month" items with dates.
- Three tabs: Overview, Company, Catalysts and events.

STYLE
- Background #F4F5F7, white cards, primary blue #0028A1, serif logo text, monospace numbers, small uppercase card labels.
- Works on a laptop screen and at phone width. Light and dark mode.

OVERVIEW TAB
1. Six KPI cards: Names in screen (with split listed / sponsor or credit-fund owned / family-owned); Live deal signals (count and names); Refinancing inside 12 months; Food inflation (Moody's) "1.7% to ~5%" with dates; With Moody's research (count and names); Accounts older than 12 months (count and names).
2. Filters: ownership type and a search box. The starting question sits above everything, with QSR spelled out and a line on how the names were chosen.
3. Trigger panel, full width: headline figure, verdict chip "PARTLY CONFIRMED", one line on what current data shows, the four-step chain with a SOURCED or INFERRED tag on each step, and four evidence boxes (Research, Macro, News, Company filings) with two or three bullets each, source and date on every bullet.
4. Left column:
   - Ownership lens: one bar per ownership type, sized by combined revenue, with company count, names and the deal route tag.
   - This month: the five strip items with dates.
5. Company screen, full width: the market context line with its source, then one row per company: owner, revenue (period and basis), the four lights (growth, margin, margin change, leverage), each with figure, period and basis, and the latest development with its source. A legend states each rule. Clicking a row opens the full company page (no side drawer: it could not scroll).

COMPANY TAB
- Company selector. Snapshot cards (revenue, EBITDA, margin, debt/EBITDA, each with period and basis).
- The four lights as cards, each with figure, period, basis, rule and source.
- Deal and financing facts, sourced.
- What changed in the last 90 days.
- Company profile: only rows with data (legal name, HQ, employees, incorporation, website, description).
- Historic financials chart: revenue bars and EBITDA bars per year, only if there are at least two revenue points. Negative EBITDA drawn below a zero line. Moody's forecasts drawn as dashed bars and labelled "Moody's forecast". Below it a table with only the rows that have data.
- Cash flow (listed names only): CFO, capex, free cash flow labelled "calculated".
- Ownership tree: the chain from Step 5 with source and flag.
- Moody's view (PizzaExpress and Wagamama only): date, credit view, forecasts, thresholds, debt and maturities.
- Company statements and data gaps, each sourced.
- Recent developments: only if news was kept.

NEWS AND EVENTS TAB
- News feed from Step 10: filter by company and topic chips (Results, Deal, Costs, Demand, Sites, Other). Each item: date, publisher, a headline written as a plain statement of fact (both sides where the source has both), company, topic, metric. No positive or negative tags.
- Coming up: the dated list from Step 11, with sources.

SOURCES TAB
- The question and how the names were chosen; Moody's research used, each labelled macro research, sector research or credit opinion (rated issuer); Moody's company data per name; company filings and statements; news kept out of fetched.
- Footer: Moody's tools used, and "News is third-party via Moody's NewsEdge".

HARD RULES
- No empty charts or panels. If a chart has fewer than two points, do not draw it; drop the panel or show the single figure as text.
- Negative values sit below the zero line.
- Basis and period on every number.
- No ratings column. Ratings only inside financing-event text.
- No projections or impacts unless sourced.
- No verdict wording about a company and no dramatic verbs.
- No [Stonegate], [Leon], supermarket or [Burger King UK] content anywhere.
- No figure that is not in Steps 1 to 12.
- No em dashes.
```

### Step 14. Check

```
Open the page you built and check it:
1. Every figure on the page against its source and date in Steps 1 to 12. List any mismatch.
2. Any chart with fewer than two points, any empty panel, any row that is all n.d.
3. Any negative value drawn above the zero line.
4. Any number without basis or period.
5. Any excluded company anywhere in the page text.
6. Any projection or impact without a source or a visible formula.
7. Any em dash.
8. The page makes no network calls.
Fix what you find, republish, and list what changed.
```

---

## Appendix A. Reference values (6 Oct 2026 run)

Use these to check each CHECKPOINT. A different value on refresh is fine if the source is newer; a different entity is not.

### A1. Entity IDs

| Company | Entity | Use | ID |
|---|---|---|---|
| Greggs | Greggs PLC | all | b3JnSWQ6bzAwMzkzNjI0NSNvcmJpc0lkOjAwMzkzNjI0NSNidmRJZDpHQjAwNTAyODUxI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Domino's | Domino's Pizza Group PLC | all | b3JnSWQ6bzAwNDk0MTEzNSNvcmJpc0lkOjAwNDk0MTEzNSNidmRJZDpHQjAzODUzNTQ1I2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Tortilla | Tortilla Mexican Grill PLC | all | b3JnSWQ6bzUwOTczNDYxNSNvcmJpc0lkOjUwOTczNDYxNSNidmRJZDpHQjEzNTExODg4I2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| PizzaExpress | Wheel Bidco Limited | Moody's research | b3JnSWQ6ODY3MzM4Nzg2I29yYmlzSWQ6NDk4MzkyMzQzI2J2ZElkOkdCSkUxMzIzMjUjZGVhbElkOm51bGwjdHJhbmNoZUlkOm51bGw |
| PizzaExpress | Pizzaexpress (Restaurants) Limited | ownership, profile | b3JnSWQ6bzAwNDM5MzQwMyNvcmJpc0lkOjAwNDM5MzQwMyNidmRJZDpHQjAyODA1NDkwI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| PizzaExpress | Pizzaexpress Limited | news | b3JnSWQ6bzAwNDA3MTQzNCNvcmJpc0lkOjAwNDA3MTQzNCNidmRJZDpHQjAxNDA0NTUyI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Wagamama | Wagamama (Holdings) Limited | all | b3JnSWQ6ODY5MzIwODg4I29yYmlzSWQ6MTAzNDg4NzA4I2J2ZElkOkdCMDc1NTY1MjUjZGVhbElkOm51bGwjdHJhbmNoZUlkOm51bGw |
| Gail's | Gail's Limited | all | b3JnSWQ6bzA2MTkxNzA2NiNvcmJpc0lkOjA2MTkxNzA2NiNidmRJZDpHQjA2MDU1MzkzI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Itsu | Itsu Limited | all | b3JnSWQ6bzAwNDYwNzU1MiNvcmJpc0lkOjAwNDYwNzU1MiNidmRJZDpHQjAzMjg2MzQyI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Nando's | Nando's Chickenland Limited | all | b3JnSWQ6bzAwNDMxOTkyNSNvcmJpc0lkOjAwNDMxOTkyNSNidmRJZDpHQjAyNTgwMDMxI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Pret | Pret A Manger (Europe) Limited | accounts, profile | b3JnSWQ6bzAwNDE1MjYzOSNvcmJpc0lkOjAwNDE1MjYzOSNidmRJZDpHQjAxODU0MjEzI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Pret | Pret A Manger Limited | parent debt, news | b3JnSWQ6bzM4MTUxODQ3MyNvcmJpc0lkOjM4MTUxODQ3MyNidmRJZDpHQjExMzkxMzIxI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |

### A2. Latest financials

| Company | Period end | Basis | Revenue (growth) | EBITDA | Debt/EBITDA | FCF (calculated) |
|---|---|---|---|---|---|---|
| Greggs | Dec 2025 | Moody's format | £2,151.2m (+6.8%) | £346.1m | 1.19x | £51.6m (CFO 337.0, capex 285.4); 2024 £77.7m (318.6, 240.9) |
| Domino's | Dec 2025 | Moody's format | £685.4m (+3.1%) | £142.8m | 3.85x (company 2.3x, H1) | £79.8m (103.9, 24.1); 2024 £85.0m (103.5, 18.5) |
| Tortilla | Dec 2025 | Moody's format | £74.0m (+8.8%) | -£2.2m | n.m. | £3.2m per the data pull (CFO 7.4, capex 4.3, rounded; the unrounded figures give 3.2, the rounded ones 3.1, so check on refresh); 2024 £5.6m (10.6, 5.0); £9.9m impairment |
| PizzaExpress | LTM Mar 2026 | Moody's-adjusted | £444.4m | margin 19.1% (company pre-IFRS 16 EBITDA £55m) | 5.4x | FCF/debt -1.9% (Moody's) |
| Wagamama | Dec 2025 | filed | £480.5m (-4.2%) | £75.9m (2024 £33.1m, 2023 £71.8m) | 7.19x filed (shown on the page); 6.6x Moody's-adjusted LTM Sep 2025 (sub-label) | n.d. |
| Gail's | Feb 2025 | filed | £219.8m (+22.8%) | £36.5m | 0.51x | n.d. |
| Itsu | Jan 2025 | filed | £120.3m | £0.7m | 40.0x | n.d. |
| Nando's | Feb 2025 | Moody's format | £1,128.2m (+9.8%) | £275.1m | 1.08x | n.d. |
| Pret | Jan 2025 | filed (Europe entity) | £734.8m | -£47.9m | n.m.; parent debt £599.8m Jan 2026 (from £531.0m) | n.d. |

Domino's 2024 FCF: 103.5 minus 18.5 = £85.0m. Check this against the tool on refresh.

### A3. Moody's forecasts (the only projections allowed)

- PizzaExpress (2 Jul 2026): revenue 2026F £458.1m, 2027F £474.0m; leverage 5.4x and 5.2x; EBIT/interest 0.9x and 1.0x; restaurants 474 now, 482 and 487.
- Wagamama (19 Jan 2026): revenue 2026F £496.9m, 2027F £518.0m; leverage 5.9x and 5.5x; EBIT/interest 1.3x and 1.5x; restaurants 242 and 244.
- Company guidance: Greggs 2026 capex about £180m; Domino's leverage target 1.5x to 2.5x.

### A4. Deal signals and coming up

- PizzaExpress: sale preparation at up to £500m (Marketline citing the FT, 21 Sep 2026).
- Itsu: Bridgepoint to sell its minority stake (Marketline, 9 Sep 2026).
- Domino's: £200m notes due Jul 2027, refinancing planned by end 2026 (H1 call, 4 Aug 2026).
- Coming up: Greggs Derby site H2 2026; Wagamama £8m savings from H2 2026; PizzaExpress RCF Mar 2029 and notes Sep 2029; Greggs £100m RCF Jun 2029; Domino's £300m RCF 2030.

---

## Appendix B. Known traps

- **Spelling breaks entity search.** "Pizza Express (Restaurants) Limited" returned nothing; "PizzaExpress" with alternatives worked. Use legal names and the IDs above.
- **One group, several entities.** Research, accounts, ownership and news can each sit on a different entity (PizzaExpress, Pret).
- **Unrated names have no Moody's research.** Only PizzaExpress (via Wheel Bidco) and Wagamama have it. Their evidence comes from filings, news and sector research.
- **Private accounts lag 19 to 21 months** (Gail's, Itsu, Nando's, Pret). Show the age.
- **Bases differ.** Moody's format, filed and Moody's-adjusted numbers are not like-for-like. Label every figure "As reported" or "Moody's-adjusted" with its period.
- **Filings load slowly.** On 7 Oct they took 6 to 8 minutes and the load does not last overnight. Run /tdr-s1 warmup 10 to 15 minutes before the live demo. Calls may reach NewsEdge (Aiera) first.
- **Full financial pulls are huge.** Ask for key indicators or one section.
- **Ultimate owner can stop at an SPV** or disagree with research and news. Show the chain and the flag.
- **The newest UK Précis is December 2025** and predates the 2026 energy shock.
- **Topic news has no geography.** A UK grocery topic search returned Pakistan, Nigeria and New Zealand items. Filter by entity, or keep UK items only.
- **Guidance gets superseded.** Greggs' July H2 profit guidance was replaced by the 30 Sep update.
- **Director data lags.** Greggs' CEO still shows as "designate"; Tortilla's CFO differs between sources.
- **Open checks before Friday:** Nando's owner ("L. Perlman SECS", Orbis only); reason for Tortilla's July suspension; Itsu stake size; whether the macro connector works.
