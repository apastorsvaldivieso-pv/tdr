#!/usr/bin/env python3
"""Turn the approved 6 Oct dashboard into a data-driven template.

Every edit is an exact string replacement on the approved file, asserted to match once,
so layout, styles and chart code stay as approved. Output: shared/tdr-dashboard-template.html
with an empty data block; build_dashboard.py fills it.
"""
import pathlib, sys

HERE = pathlib.Path(__file__).resolve().parent
src = (HERE / "original-approved-dashboard.html").read_text(encoding="utf-8")
out = src


def rep(old, new, count=1):
    global out
    n = out.count(old)
    if n != count:
        sys.exit(f"expected {count} match(es), found {n}: {old[:90]!r}")
    out = out.replace(old, new)


def rep_between(start, end, new):
    """Replace from start (inclusive) up to end (exclusive)."""
    global out
    i = out.find(start)
    j = out.find(end, i + 1)
    if i < 0 or j < 0 or out.count(start) != 1:
        sys.exit(f"block not found: {start[:60]!r}")
    out = out[:i] + new + out[j:]


# ---------------------------------------------------------------- CSS --
# Grid children default to min-width:auto, so the register table pushed the page
# wider than the window below 1100px. This keeps the table scrolling inside its panel.
rep(".main-grid{display:grid;grid-template-columns:1.15fr 2.6fr;gap:14px;padding:0 16px 18px;align-items:start}",
    ".main-grid{display:grid;grid-template-columns:1.15fr 2.6fr;gap:14px;padding:0 16px 18px;align-items:start}\n"
    ".main-grid>div,.feed-grid>div{min-width:0}")

# --------------------------------------------------------------- HTML --
rep('<div class="hdr-title">UK Eating Out: Food Inflation Screen</div>',
    '<div class="hdr-title" id="hdrTitle"></div>')
rep('<div class="hdr-sub">Prepared for TDR Capital\'s deal team. Nine food-to-go, delivery and casual dining names. Moody\'s data only; news third-party via NewsEdge.</div>',
    '<div class="hdr-sub" id="hdrSub"></div>')
rep('<div class="hdr-meta">As of 6 October 2026<br>Moody\'s Orbis · Research · Filings · NewsEdge</div>',
    '<div class="hdr-meta" id="hdrMeta">As of 6 October 2026<br>Moody\'s Orbis · Research · Filings · NewsEdge</div>')
rep('<div class="ph"><span class="ph-title">Trigger: UK food inflation</span><span class="ph-badge">Moody\'s research · macro · news · company filings</span></div>',
    '<div class="ph"><span class="ph-title" id="trigTitle"></span><span class="ph-badge" id="trigBadge"></span></div>')
rep('<div class="panel">\n        <div class="ph"><span class="ph-title">Margin vs Leverage</span>',
    '<div class="panel" id="scatterPanel">\n        <div class="ph"><span class="ph-title">Margin vs Leverage</span>')
rep('<span class="ph-badge">6 Sep to 6 Oct 2026</span>', '<span class="ph-badge" id="monthBadge"></span>')
i = out.find('<div class="panel"><div class="ph"><span class="ph-title">Illustrative Sensitivity</span>')
j = out.find('</div></div></div>', i) + len('</div></div></div>')
assert i > 0 and j > i
out = out[:i] + ('<div class="panel" id="sensPanel"><div class="ph"><span class="ph-title">Illustrative Sensitivity</span>'
                 '<span class="ph-badge" id="sensBadge"></span></div><div class="pb"><div class="thesis note" id="sensText"></div></div></div>') + out[j:]

# ------------------------------------------------------------ DATA ----
rep_between("/* ============================================================\n   DATA:",
            "/* ---------- helpers ---------- */",
            """/* ============================================================
   DATA: written by build_dashboard.py from the S1, S2 and S3 outputs.
   Do not hand-edit. Change the inputs and rebuild.
   ============================================================ */
const DATA = /*TDR_DATA_START*/{}/*TDR_DATA_END*/;
const META=DATA.meta||{}, CO=DATA.companies||[], MONTH=DATA.month||[], FEED=DATA.feed||[], KEPT=DATA.kept||[], UPCOMING=DATA.upcoming||[];

""")

# --------------------------------------------------------- helpers ----
rep("let state={own:\"all\",read:\"all\",q:\"\",tag:\"all\",dir:\"all\"};",
    """let state={own:"all",read:"all",q:"",tag:"all",dir:"all"};
const NUMW=["no","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve"];
const numWord=n=>NUMW[n]||String(n);
const andList=a=>a.length<2?a.join(""):a.slice(0,-1).join(", ")+" and "+a[a.length-1];
const poss=s=>/s$/i.test(s)?s+"'":s+"'s";
const fm1=v=>"£"+v.toLocaleString("en-GB",{minimumFractionDigits:1,maximumFractionDigits:1})+"m";
const md=s=>esc(s).replace(/\\*\\*(.+?)\\*\\*/g,"<b>$1</b>");""")

# ------------------------------- ticker, KPIs, trigger, lens, scatter --
rep_between("/* ---------- ticker ---------- */", "/* ---------- this month ---------- */", r'''/* ---------- ticker ---------- */
(function(){
  const items=META.ticker||[];
  if(!items.length){$(".ticker-wrap").style.display="none";return;}
  const t=items.concat(items);
  $("#ticker").innerHTML=t.map(s=>`<span>${esc(s)}</span><span class="sep">•</span>`).join("");
})();

/* ---------- KPI ---------- */
function renderKPIs(){
  const listed=CO.filter(c=>c.type==="Listed").length, fam=CO.filter(c=>c.type==="Family-owned").length, spon=CO.length-listed-fam;
  const stale=CO.filter(c=>c.stale), rated=CO.filter(c=>c.rated), K=META.kpi||{};
  const deals=K.dealSignals||[], refis=K.refinancing||[];
  const cards=[
    {c:"",l:"Names in screen",v:CO.length,s:`${listed} listed · ${spon} sponsor or credit-fund owned · ${fam} family-owned`},
    {c:"g",l:"Live deal signals",v:deals.length,s:deals.length?deals.join(" · "):"None found in the sources"},
    {c:"a",l:"Refinancing inside 12 months",v:refis.length,s:refis.length?refis.join(" · "):"None found in the sources"},
    K.trigger?{c:"r",l:K.trigger.label,v:K.trigger.value,s:K.trigger.sub}:null,
    {c:"t",l:"With Moody's research",v:rated.length,s:rated.length?rated.map(c=>c.name).join(", ")+": forecasts and triggers available":"None of the names is rated"},
    {c:"p",l:"Accounts older than 12 months",v:stale.length,s:stale.length?stale.map(c=>c.name).join(", "):"None"}
  ].filter(Boolean);
  $("#kpiRow").innerHTML=cards.map(k=>`<div class="kpi-card ${k.c}"><div class="kpi-label">${esc(k.l)}</div><div class="kpi-value">${esc(k.v)}</div><div class="kpi-sub">${esc(k.s)}</div></div>`).join("");
}

/* ---------- trigger panel ---------- */
function renderTrigger(){
  const T=META.trigger;
  if(!T){$(".trigger-wrap").style.display="none";return;}
  $("#trigTitle").textContent=T.title||"";
  $("#trigBadge").textContent=T.badge||"";
  const steps=T.steps||[], ev=T.evidence||{};
  const tag=s=>s==="SOURCED"?'<span class="tag stab">SOURCED</span>':`<span class="tag inf">${esc(s||"INFERRED")}</span>`;
  const box=(h,arr,cls)=>arr&&arr.length?`<div><div class="ev-h">${esc(h)}</div>
    <ul class="blist${cls?" "+cls:""}">${arr.map(x=>`<li>${esc(x.text)} <span class="src">${esc(x.src)}</span></li>`).join("")}</ul>
    </div>`:"";
  $("#triggerPanel").innerHTML=`<div class="trig-grid"><div>
    <div class="trig-head">${md(T.headline)}</div>
    <span class="verdict">${esc(T.verdict)}</span>
    <div style="font-size:10px;color:var(--txt-dim);margin-top:6px">${esc(T.current)}</div>
    <div class="chain">${steps.map((x,i)=>`<div class="cstep ${x.status!=="SOURCED"?'inf':''}"><div class="cnum">${i+1}</div><div><div class="ct">${esc(x.t)} ${tag(x.status)}</div><div class="cs">${esc(x.s)}</div></div></div>`).join("")}</div>
    </div><div class="ev-grid">${box("Research",ev.research,"")}${box("Macro",ev.macro,"")}${box("News",ev.news,"neu")}${box("Company filings",ev.filings,"pos")}</div></div>`;
}

/* ---------- ownership lens ---------- */
function renderOwn(){
  const groups=[{k:"Listed",l:"Listed",route:"Take-private",col:"--blue"},{k:"Sponsor",l:"Sponsor or credit-fund owned",route:"Secondary sale or refinancing",col:"--teal"},{k:"Family-owned",l:"Family-owned",route:"Succession or primary deal",col:"--purple"}];
  const rows=groups.map(g=>{const co=CO.filter(c=>OWN_GROUP(c)===g.k);return {...g,n:co.length,rev:co.reduce((a,c)=>a+(c.rev||0),0),names:co.map(c=>c.name).join(", ")};}).filter(r=>r.n>0);
  const max=Math.max(1,...rows.map(r=>r.rev));
  const per={}; CO.forEach(c=>{const k=c.date+(c.periodType==="LTM"?" LTM":"");(per[k]=per[k]||[]).push(c.name);});
  const pnote=Object.keys(per).map(k=>`${k} for ${andList(per[k])}`).join("; ");
  $("#ownPanel").innerHTML=rows.map(r=>`<div class="bar-row">
    <div class="bar-label"><span>${esc(r.l)} <span style="color:var(--txt-dim);font-weight:400">· ${r.n} cos · ${fmtM(r.rev)} revenue</span></span><span class="tag stab">${esc(r.route.toUpperCase())}</span></div>
    <div class="bar-wrap"><div class="bar-fill" style="width:${Math.round(r.rev/max*100)}%;background:var(${r.col})"></div></div>
    <div style="font-size:9.5px;color:var(--txt-dim);margin-top:4px">${esc(r.names)}</div></div>`).join("")+
    `<div style="font-size:9px;color:var(--txt-dim);margin-top:8px">Revenue is each name's latest available period, so periods differ (${esc(pnote)}).</div>`;
}

/* ---------- scatter: only names with a positive margin and leverage on the scale; hidden below two points ---------- */
function renderScatter(){
  const ok=c=>c.margin!=null&&c.lev!=null&&c.margin>0&&c.lev<15;
  const pts=CO.filter(ok);
  if(pts.length<2){$("#scatterPanel").style.display="none";return;}
  const W=300,H=196,pad={l:36,r:12,t:18,b:26};
  const xMin=0,xMax=Math.ceil(Math.max(...pts.map(p=>p.margin))/5)*5+5;
  const yMin=0,yMax=Math.ceil(Math.max(...pts.map(p=>p.lev)))+1;
  const xS=v=>pad.l+(v-xMin)/(xMax-xMin)*(W-pad.l-pad.r), yS=v=>pad.t+(1-(v-yMin)/(yMax-yMin))*(H-pad.t-pad.b);
  const rMax=Math.max(...pts.map(p=>p.rev)); const rS=v=>5+Math.sqrt(v/rMax)*11;
  let svg=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto" role="img" aria-label="EBITDA margin against leverage">`;
  for(let gx=xMin;gx<=xMax;gx+=5){const x=xS(gx);svg+=`<line x1="${x}" y1="${pad.t}" x2="${x}" y2="${H-pad.b}" stroke="#EEF2F7"/><text x="${x}" y="${H-pad.b+13}" font-size="8" fill="#566B8A" text-anchor="middle">${gx}%</text>`;}
  for(let gy=0;gy<=yMax;gy+=1){const y=yS(gy);svg+=`<line x1="${pad.l}" y1="${y}" x2="${W-pad.r}" y2="${y}" stroke="#EEF2F7"/><text x="${pad.l-6}" y="${y+3}" font-size="8" fill="#566B8A" text-anchor="end">${gy}x</text>`;}
  svg+=`<text x="${(pad.l+W-pad.r)/2}" y="${H-2}" font-size="8" fill="#566B8A" text-anchor="middle">EBITDA margin</text><text x="${pad.l}" y="9" font-size="8" fill="#566B8A">Debt/EBITDA</text>`;
  const colOf={"Listed":cssv("--blue"),"Sponsor":cssv("--teal"),"Family-owned":cssv("--purple")};
  pts.forEach(p=>{const x=xS(p.margin),y=yS(p.lev),r=rS(p.rev),col=colOf[OWN_GROUP(p)];
    svg+=`<circle cx="${x}" cy="${y}" r="${r}" fill="${col}" fill-opacity="0.30" stroke="${col}" stroke-width="1.3" style="cursor:pointer" data-open="${p.id}"><title>${esc(p.name)}: ${fmtM(p.rev)} revenue, ${fmtP(p.margin)} margin, ${fmtX(p.lev)} (${esc(p.basis)})</title></circle>`;
    svg+=`<text x="${x}" y="${y-r-3}" font-size="7" fill="#0D1F3C" text-anchor="middle" style="pointer-events:none">${esc(p.name.split(" ")[0])}</text>`;});
  svg+=`</svg>`;
  $("#scatter").innerHTML=svg;
  const why=c=>c.margin==null?"no margin":(c.margin<=0?"negative EBITDA":(c.lev==null?"no meaningful leverage":`${fmtX(c.lev)}, off the scale`));
  const out=CO.filter(c=>!ok(c)).map(c=>`${c.name} (${why(c)})`);
  $("#scatterNote").textContent=`Bubble size = revenue. Bases differ by name (see register).${out.length?" Not plotted: "+out.join(", ")+".":""}`;
  $("#scatter").querySelectorAll("circle").forEach(el=>el.addEventListener("click",()=>openDrawer(el.dataset.open)));
}

''')

# ---------------------------------------------------------- register --
rep("<td class=\"r num\">${esc(c.ebTxt)}<span class=\"sub\">${esc(c.basis.split(\",\")[0])}</span></td>",
    "<td class=\"r num\">${esc(c.ebTxt)}<span class=\"sub\">${esc(c.ebBasis||c.basis.split(\",\")[0])}</span></td>")
rep("<td class=\"r num\">${c.margin!=null?fmtP(c.margin):\"n.d.\"}${c.id===\"pizzaexpress\"?'<span class=\"sub\">Moody\\'s-adjusted</span>':(c.id===\"wagamama\"?'<span class=\"sub\">calculated, filed</span>':\"\")}</td>",
    "<td class=\"r num\">${c.margin!=null?fmtP(c.margin):\"n.d.\"}${c.marSub?`<span class=\"sub\">${esc(c.marSub)}</span>`:\"\"}</td>")

# ------------------------------------------------- financial table ----
rep("let html=`<table class=\"fin-tbl\"><thead><tr><th>${esc(c.fc?\"Moody's-adjusted, £m\":\"£m, \"+c.basis.split(\",\")[0])}</th>",
    "let html=`<table class=\"fin-tbl\"><thead><tr><th>${esc(c.seriesBasis===\"Moody's-adjusted\"?\"Moody's-adjusted, £m\":\"£m, \"+c.basis.split(\",\")[0])}</th>")

# --------------------------------------------------------- peer table --
rep_between("function peerTable(c){", "\nconst NT=", r'''function peerTable(c){
  const rows=CO.map(p=>({id:p.id,name:p.name,rev:p.rev,eb:p.ebitda!=null?fmtM(p.ebitda):(p.peerEb?p.peerEb+"*":"n.d."),m:p.margin,lev:p.lev,basis:p.basis.split(",")[0],period:p.date,self:p.id===c.id}));
  const ms=rows.map(r=>r.m).filter(v=>v!=null), med=median(ms);
  let html=`<table class="peer-tbl"><thead><tr><th>Company</th><th>Revenue</th><th>EBITDA</th><th>Margin</th><th>Debt/EBITDA</th><th>vs median margin</th><th>Basis · period</th></tr></thead><tbody>`;
  rows.forEach(r=>{const d=r.m!=null?r.m-med:null;
    html+=`<tr class="${r.self?'self':''}"><td>${r.self?'<b>'+esc(r.name)+'</b>':esc(r.name)}</td><td class="num">${fmtM(r.rev)}</td><td class="num">${esc(r.eb)}</td><td class="num">${fmtP(r.m)}</td><td class="num">${r.lev!=null?fmtX(r.lev):"n.m."}</td><td class="num ${d==null?'trend-fl':(d>=0?'trend-up':'trend-dn')}">${d==null?"n/a":(d>=0?"+":"")+d.toFixed(1)+"pp"}</td><td style="font-size:9px;color:var(--txt-dim)">${esc(r.basis)} · ${esc(r.period)}</td></tr>`;});
  const stars=CO.filter(p=>p.ebitda==null&&p.peerEb&&p.peerEbNote).map(p=>"*"+p.peerEbNote).join(" ");
  html+=`<tr class="med"><td>Median margin (${ms.length} names)</td><td></td><td></td><td class="num">${fmtP(med)}</td><td></td><td></td><td></td></tr></tbody></table>
  <div style="font-size:9.5px;color:var(--txt-dim);margin-top:7px">${esc(stars?stars+" ":"")}Periods and bases differ across names, so this is a screen, not a like-for-like comparison.</div>`;
  return html;
}
''')

# ------------------------------------------------------- Moody's view --
rep_between("function moodysSection(c){", "\nfunction newsFor(c)", r'''function moodysSection(c){
  if(!c.rated) return "";
  const projRows=(c.proj||[]).map(p=>`<li>${esc(p)}</li>`).join("");
  return `<div class="sec-card"><div class="sec-card-h">Moody's View <span class="hint">credit opinion · forecasts · triggers</span></div><div class="sec-card-b">
    <ul class="blist neu">${(c.moodys||[]).map(m=>`<li>${esc(m)}</li>`).join("")}</ul>
    ${projRows?`<div class="own-head">Moody's forecasts, as published</div><ul class="blist">${projRows}</ul>`:""}</div></div>`;
}
''')

# ------------------------------------------------------- detail page --
rep("    {l:\"Employees\",v:c.emp,s:c.empSrc.split(\";\")[0]}",
    "    c.emp&&c.emp!==\"n.d.\"?{l:\"Employees\",v:c.emp,s:(c.empSrc||\"\").split(\";\")[0]}:null")
rep("${c.fc?'<span class=\"dh-badge\">MOODY\\'S RESEARCH</span>':''}",
    "${c.rated?'<span class=\"dh-badge\">MOODY\\'S RESEARCH</span>':''}", count=2)
rep("        <tr><td>Headquarters</td><td>${esc(c.hq)} · ${esc(c.web)}</td></tr>\n        <tr><td>Employees</td><td class=\"num\" style=\"font-family:var(--mono)\">${esc(c.emp)} <span class=\"src\">${esc(c.empSrc)}</span></td></tr>\n        <tr><td>Management</td><td>${esc(c.ceo)} <span class=\"src\">${esc(c.ceoSrc)}</span></td></tr>",
    "        ${c.hq&&c.hq!==\"n.d.\"?`<tr><td>Headquarters</td><td>${esc(c.hq)}${c.web?\" · \"+esc(c.web):\"\"}</td></tr>`:\"\"}\n        ${c.emp&&c.emp!==\"n.d.\"?`<tr><td>Employees</td><td class=\"num\" style=\"font-family:var(--mono)\">${esc(c.emp)} <span class=\"src\">${esc(c.empSrc)}</span></td></tr>`:\"\"}\n        ${c.ceo&&c.ceo!==\"n.d.\"?`<tr><td>Management</td><td>${esc(c.ceo)} <span class=\"src\">${esc(c.ceoSrc)}</span></td></tr>`:\"\"}")
rep("    <div class=\"sec-card\"><div class=\"sec-card-h\">Historic Financials <span class=\"hint\">${esc(c.basis)}${c.fc?\" · Moody's forecasts shaded\":\"\"}</span></div><div class=\"sec-card-b\">${chart}<div style=\"margin-top:${chart?10:0}px\">${finTable(c)}</div></div></div>",
    "    ${(c.revS||[]).some(v=>v!=null)?`<div class=\"sec-card\"><div class=\"sec-card-h\">Historic Financials <span class=\"hint\">${esc(c.basis)}${c.fc?\" · Moody's forecasts shaded\":\"\"}</span></div><div class=\"sec-card-b\">${chart}<div style=\"margin-top:${chart?10:0}px\">${finTable(c)}</div></div></div>`:\"\"}")
rep("<span class=\"hint\">vs the other eight names</span>",
    "<span class=\"hint\">vs the other ${numWord(CO.length-1)} names</span>")
rep("${!c.fc?`<div class=\"src\" style=\"margin-top:6px\">Unrated by Moody's",
    "${!c.rated?`<div class=\"src\" style=\"margin-top:6px\">Unrated by Moody's")
rep("Pulled 5 and 6 October 2026. \"n.d.\" means no data returned.",
    "Pulled ${esc(META.pulled)}. \"n.d.\" means no data returned.")

# ---------------------------------------------------------- catalysts --
rep("const TAGS=[\"all\",", "const tagOf=f=>f.tag||TAG_OF(f);\nconst TAGS=[\"all\",")
rep("(state.tag===\"all\"||TAG_OF(f)===state.tag)", "(state.tag===\"all\"||tagOf(f)===state.tag)")
rep("${DIRL[f.dir]} · ${TAG_OF(f)} · ${esc(f.m)}", "${DIRL[f.dir]} · ${tagOf(f)} · ${esc(f.m)}")
rep("const nameOf=id=>id===\"macro\"?\"Macro and sector\":by(id).name;",
    "const nameOf=id=>id===\"macro\"?\"Macro and sector\":((by(id)||{}).name||id);")

# ------------------------------------------------------- footer, init --
i = out.find('$("#pageFoot").innerHTML=`<b>Data sources:</b>')
j = out.find("`;", i) + 2
assert i > 0
foot = out[i:j]
foot = foot.replace("Moody's research and credit opinions (PizzaExpress via Wheel Bidco Limited; Wagamama (Holdings) Limited)",
                    "Moody's research and credit opinions (${esc(RESEARCH_NAMES||\"none of the names is rated\")})")
foot = foot.replace("Snapshot pulled 5 and 6 October 2026; no live refresh.", "Snapshot pulled ${esc(META.pulled)}; no live refresh.")
assert "5 and 6 October" not in foot and "Wheel Bidco" not in foot
out = out[:i] + """const RESEARCH_NAMES=CO.filter(c=>c.rated).map(c=>{const l=c.researchEntity||c.legal;return l.toLowerCase().includes(c.name.split(" ")[0].toLowerCase())?l:`${c.name} via ${l}`;}).join("; ");
""" + foot + out[j:]

rep("renderKPIs();renderTrigger();renderOwn();renderScatter();renderMonth();renderTable();renderCompany();renderChips();renderFeed();renderUpcoming();renderKept();",
    r'''/* ---------- header and sensitivity, from META ---------- */
function renderHeader(){
  if(META.pageTitle) document.title=META.pageTitle;
  $("#hdrTitle").textContent=META.title||"";
  $("#hdrSub").textContent=META.subtitle||"";
  $("#hdrMeta").innerHTML=`As of ${esc(META.asOfLong)}<br>${esc(META.tools||"")}`;
  $("#monthBadge").textContent=META.monthWindow||"";
}
function renderSens(){
  const S=META.sensitivity;
  if(!S){$("#sensPanel").style.display="none";return;}
  const one=S.costOfSales/100, share=one/S.ebitda*100;
  $("#sensBadge").textContent=S.badge||"";
  $("#sensText").innerHTML=`${esc(poss(S.company))} cost of sales was <b class="num">${fm1(S.costOfSales)}</b> in ${esc(S.period)} (${esc(S.cosSource)}). A 1% rise in cost of sales is <b class="num">${fm1(one)}</b>, about <b class="num">${share.toFixed(1)}%</b> of ${esc(S.period)} EBITDA of ${fm1(S.ebitda)} (${esc(S.ebitdaBasis)}). ${esc(S.note||"")} A calculation for illustration, not a forecast.`;
}

renderHeader();renderSens();renderKPIs();renderTrigger();renderOwn();renderScatter();renderMonth();renderTable();renderCompany();renderChips();renderFeed();renderUpcoming();renderKept();''')

# ------------------------------------------------------------ checks --
for leftover in ("5 and 6 October", "6 Sep to 6 Oct", "Itsu at 40x", "eight names", "c.id===\"pizzaexpress\"",
                 "r.id===\"pizzaexpress\"", "c.id===\"wagamama\"", "Greggs · food costs", "829.1"):
    if leftover in out.split("/*TDR_DATA_START*/")[1]:
        sys.exit(f"leftover run-specific text in renderer: {leftover}")
for bad in ("undefined", "NaN", "fetch(", "XMLHttpRequest", "\u2014"):
    if bad in out:
        sys.exit(f"template contains {bad!r}")

dest = HERE.parent / "shared" / "tdr-dashboard-template.html"
dest.write_text(out, encoding="utf-8")
print("wrote", dest, len(out), "chars")
