#!/usr/bin/env python3
"""One-off: build the three example input files from the approved 6 Oct page and the
original S2 example, so the build can be tested against the approved dashboard.

Changes made on purpose (agreed in review):
- Wagamama leverage on the page is the filed 7.19x (same basis and period as its margin);
  Moody's-adjusted 6.6x (LTM Sep 2025) becomes the sub-label.
- Gail's news follows the S2 record (2 kept: Winchester and Watford).
"""
import json, pathlib, copy

HERE = pathlib.Path(__file__).resolve().parent
SH = HERE.parent / "shared"
app = json.load(open(HERE / "approved-data.json", encoding="utf-8"))
old = json.load(open(HERE / "v1-tdr-s2-output.example.json", encoding="utf-8"))
CO = {c["name"]: c for c in app["CO"]}
FEED = app["FEED"]
KEPT = {k[0]: k for k in app["KEPT"]}

# EBITA by year from the Moody's format key indicators (pulled 7 Oct 2026), aligned to the page's year labels.
EBITA = {
    "Greggs": [153.1, 160.5, 202.5, 221.7, 190.2],
    "Domino's Pizza Group": [129.2, 122.9, 181.2, 166.5, 128.3],
    "Tortilla Mexican Grill": [3.6, 0.7, -1.1, -12.1],
    "Nando's": [40.8, 92.5, 147.0, 225.1],
}
PERIOD = {  # period type and the entity use labels the page needs
    "PizzaExpress": "LTM",
}
USES = {
    "Wheel Bidco Limited": "research",
    "Pizzaexpress (Restaurants) Limited": "ownership, profile, accounts",
    "Pizzaexpress Limited": "news",
    "Pret A Manger (Europe) Limited": "accounts, profile",
    "Pret A Manger Limited": "parent debt, news",
}
DISPLAY = {
    "PizzaExpress": {"rev_sub": "LTM Mar 2026; +1.0% on 2025", "eb_txt": "£55m",
                     "eb_sub": "Company, pre-IFRS 16; Moody's margin 19.1%", "eb_basis": "Company, pre-IFRS 16",
                     "eb_note": "PizzaExpress EBITDA is the company's pre-IFRS 16 figure for the 12 months to March 2026; its margin is Moody's-adjusted."},
    "Domino's Pizza Group": {"lev_sub": "Own measure 2.3x at H1"},
    "Wagamama": {"lev_sub": "Filed; Moody's-adjusted 6.6x (LTM Sep 2025)"},
    "Pret A Manger": {"lev_sub": "Parent debt £600m (Jan 2026)"},
}


def split_src(s):
    text, src = s.rsplit(" (", 1)
    return {"text": text, "source": src.rstrip(")")}


s2 = copy.deepcopy(old)
s2["as_of"] = "2026-10-07"
for c in s2["companies"]:
    a = CO[c["name"]]
    c_new = {"name": c["name"], "id": a["id"]}
    ents = c["entities"]
    for e in ents:
        e["use"] = USES.get(e["legal"], "all")
    c_new["entities"] = ents
    own = c["ownership"]
    own.update(top_owner=a["owner"], top_owner_source=a["ownerSrc"], flag=a["ownerFlag"], chain=a["chain"])
    c_new["ownership"] = own
    c_new["profile"] = {"legal_display": a["legal"], "hq": a["hq"], "website": a["web"], "employees": a["emp"],
                        "employees_source": a["empSrc"], "description": a["desc"],
                        "sites": a["sites"], "sites_source": a["sitesSrc"]}
    c_new["management"] = {"ceo": a["ceo"], "source": a["ceoSrc"]}
    f = c["financials"]
    f.pop("years", None)
    pe = __import__("datetime").date.fromisoformat(f["period_end"]); ao = __import__("datetime").date(2026, 10, 7)
    f["age_months"] = (ao.year - pe.year) * 12 + ao.month - pe.month - (1 if ao.day < pe.day else 0)
    f["period_type"] = PERIOD.get(c["name"], "FY")
    if c["name"] in DISPLAY:
        f["display"] = DISPLAY[c["name"]]
    series = {"basis": "Moody's-adjusted" if a.get("fc") else f["basis"], "years": a["years"], "revenue": a["revS"]}
    if a.get("ebS") is not None:
        series["ebitda"] = a["ebS"]
    if c["name"] in EBITA:
        series["ebita"] = EBITA[c["name"]]
    for k_src, k_dst in (("marS", "margin"), ("levS", "debt_ebitda"), ("icS", "interest_cover"),
                         ("fc", "forecast"), ("fcfDebtS", "fcf_debt"), ("unitsS", "units")):
        if a.get(k_src) is not None:
            series[k_dst] = a[k_src]
    series["note"] = a.get("seriesNote", "")
    f["series"] = series
    if a.get("cfoS"):
        f["cash_flow"] = {"years": a["cfoS"]["years"], "cfo": a["cfoS"]["cfo"], "capex": a["cfoS"]["capex"],
                          "capex_line": "Cash payments to acquire PP&E and Intangibles", "source": "getEntityFinancials_v2, Moody's format cash flow statement"}
    if a.get("capexGuide"):
        f["capex_guide"] = {"label": a["capexGuide"]["label"], "value": a["capexGuide"]["v"], "source": "Interim results, 29 Jul 2026"}
    if a.get("ebFiled"):
        f["ebitda_filed"] = {"years": a["ebFiled"]["years"], "values": a["ebFiled"]["v"], "source": "Orbis Standard Format"}
    c_new["financials"] = f
    c_new["evidence"] = {"cost": a["cost"], "demand": a["demand"], "financing": a["financing"]}
    c_new["says"] = a["says"]
    c_new["priorities"] = {"items": a["priorities"], "source": a.get("prioritiesSrc", "")}
    c_new["gaps"] = a["gaps"]
    m = c.get("moodys")
    if m:
        m["view"] = a["moodys"]
        m["forecasts"] = [split_src(p) | {"metric": split_src(p)["text"].split(" ")[0]} for p in a["proj"]]
        for p in m["forecasts"]:
            if p["source"] == "Moody's forecast":
                p["source"] = "Moody's forecast, " + ("2 Jul 2026" if c["name"] == "PizzaExpress" else "19 Jan 2026")
        m["thresholds"] = {"text": next((x for x in a["moodys"] if "pgrade" in x or "ograde" in x), ""),
                           "source": "Moody's credit opinion, " + ("2026-07-02" if c["name"] == "PizzaExpress" else "2026-01-19")}
    c_new["moodys"] = m
    c_new["filings"] = []
    c_new["projections"] = [split_src(p) for p in a["proj"]]
    # news: approved page wording, S2 counts
    n = c["news"]
    items = []
    feed_items = [x for x in FEED if x["co"] == a["id"]]
    dirmap = {"pos": "positive", "neg": "negative", "mix": "mixed", "deal": "mixed"}
    for it in n["items"]:
        match = next((x for x in feed_items if x["d"] == it["date"]
                      and x["p"].split(" ")[0].lower() == it["publisher"].split(" ")[0].lower()), None)
        if match:
            tag = it["tag"]
            if match["m"] == "Management":
                tag = "Other"
            items.append({"date": match["d"], "publisher": match["p"], "headline": match["h"], "tag": tag,
                          "direction": dirmap[match["dir"]], "metric": match["m"], "number": match["n"]})
        else:
            items.append({"date": it["date"], "publisher": it["publisher"],
                          "headline": "Gail's opens a new bakery in Watford.", "tag": it["tag"],
                          "direction": it["direction"], "metric": "Sites", "number": ""})
    note = KEPT[c["name"]][3]
    if c["name"] == "Gail's":
        note = "Several results were about unrelated companies with similar names."
    c_new["news"] = {"fetched": n["fetched"], "kept": len(items), "note": note,
                     "window": "6 Sep to 6 Oct 2026", "items": items}
    c.clear(); c.update(c_new)

# Greggs filings lines used by the sensitivity and the trigger panel
g = next(c for c in s2["companies"] if c["name"] == "Greggs")
g["filings"] = [
    {"topic": "cost", "text": "H1 2026 cost inflation 2.2%; about 70% of H2 food and packaging bought forward; about 50% of 2027 energy covered", "document": "Interim results", "date": "2026-07-29"},
    {"topic": "demand", "text": "Share of food-to-go visits 8.7% (+0.3 pts) while market visits fell 1.9% (Circana)", "document": "Interim results", "date": "2026-07-29"},
    {"topic": "cost of sales", "text": "FY2025 cost of sales £829.1m", "value": 829.1, "document": "Interim results (FY2025 comparatives)", "date": "2026-07-29"},
    {"topic": "guidance", "text": "2026 capex about £180m; July H2 profit guidance superseded by the 30 Sep update", "document": "Interim results; Q3 update", "date": "2026-09-30"},
]
d = next(c for c in s2["companies"] if c["name"] == "Domino's Pizza Group")
d["filings"] = [
    {"topic": "cost", "text": "Fully hedged on key cost items for 2026, some cover into 2027", "document": "H1 2026 call", "date": "2026-08-04"},
    {"topic": "financing", "text": "£200m US private placement notes due July 2027, to be refinanced by end 2026; £300m RCF to 2030", "document": "H1 2026 call", "date": "2026-08-04"},
]
json.dump(s2, open(SH / "tdr-s2-output.example.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ------------------------------------------------------------------ S1 --
dirmap = {"pos": "positive", "neg": "negative", "mix": "mixed"}
tagmap = {"Food prices": "Costs", "Consumer demand": "Demand", "Sector sales": "Demand"}
s1 = {
    "as_of": "2026-10-06",
    "trigger": "UK food inflation rising again, driven by energy costs",
    "verdict": "partly confirmed",
    "macro_connector": "not connected",
    "segment": "UK eating out: food-to-go, quick-service and casual dining chains",
    "seed_list": ["Greggs", "Domino's Pizza Group", "Tortilla Mexican Grill", "PizzaExpress", "Wagamama", "Gail's", "Itsu", "Nando's", "Pret A Manger"],
    "kpi": {"label": "Food inflation (Moody's)", "value": "1.7% to ~5%", "sub": "12 months to June 2026 to early 2027 · 6 Aug 2026"},
    "panel": {
        "title": "Trigger: UK food inflation",
        "badge": "Moody's research · macro · news · company filings",
        "headline": "UK food inflation: **1.7%** in June, about **5%** by early 2027",
        "verdict": "PARTLY CONFIRMED · forecast, mostly still ahead",
        "current": "Grocery inflation was 2.3% in September (Worldpanel) and overall shop prices eased to 1.4% (MSN, 4 Oct), so the rise Moody's expects has not yet reached prices.",
        "steps": [
            {"t": "Energy costs rise", "s": "Middle East conflict; closure of the Strait of Hormuz and a spike in crude. Moody's State of the Consumer, 29 Sep 2026.", "status": "SOURCED"},
            {"t": "Food input costs follow, with a delay", "s": "Food inflation to around 5% by early 2027 from 1.7% in the 12 months to June. Moody's UK grocery sector in-depth, 6 Aug 2026.", "status": "SOURCED"},
            {"t": "Squeezed consumers trade down", "s": "Inference. Food-to-go visits fell 1.9% while Greggs, the value leader, gained share (Circana, via Greggs' interim results).", "status": "INFERRED"},
            {"t": "Cheaper formats gain; pricier and indebted operators are hit twice", "s": "Inference, tested against the nine names in the register.", "status": "INFERRED"},
        ],
        "evidence": {
            "research": [
                {"text": "Food inflation to rise to around 5% by early 2027 from 1.7%; nowhere near the 17.5% peak of 2022.", "src": "Moody's, 6 Aug 2026"},
                {"text": "UK casual dining under pressure from discounting and competition from quick-service chains.", "src": "Moody's, Wagamama credit opinion, 19 Jan 2026"},
            ],
            "macro": [
                {"text": "UK inflation 3.1%; real consumer spending growth about 1.0% in 2026 and 0.7% in 2027.", "src": "Moody's, State of the Consumer, 29 Sep 2026"},
                {"text": "The newest UK Précis returned (December 2025 vintage) predates the energy shock, so it is not used.", "src": "Moody's Précis, 16 Jan 2026"},
            ],
            "news": [
                {"text": "Grocery inflation edged up to 2.3%, with fewer shopping trips.", "src": "Worldpanel via Global Banking and Finance Review and LSE.co.uk, 15 Sep 2026"},
                {"text": "Shop price inflation eased to 1.4% in September; promotions held prices down.", "src": "MSN, 4 Oct 2026"},
                {"text": "UBS cut its UK grocery sales growth forecast to 2.5% from 4%, as food inflation has not picked up as expected.", "src": "Proactive Investors, 21 Sep 2026"},
            ],
            "filings": [
                {"text": "Greggs: cost inflation 2.2% in H1; about 70% of H2 food and packaging bought forward; about 50% of 2027 energy covered.", "src": "Interim results, 29 Jul 2026"},
                {"text": "Domino's: fully hedged on key cost items for 2026, with some cover into 2027.", "src": "H1 2026 call, 4 Aug 2026"},
            ],
        },
    },
    "feed": [{"date": x["d"], "publisher": x["p"], "headline": x["h"], "tag": tagmap.get(x["m"], "Other"),
              "direction": dirmap[x["dir"]], "metric": x["m"], "number": x["n"]} for x in FEED if x["co"] == "macro"],
}
json.dump(s1, open(SH / "tdr-s1-output.example.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ------------------------------------------------------------ S3 synth --
syn = {
    "as_of": "2026-10-06",
    "meta": {"title": "UK Eating Out: Food Inflation Screen",
             "page_title": "UK eating out: food inflation screen",
             "subtitle": "Prepared for TDR Capital's deal team. Nine food-to-go, delivery and casual dining names. Moody's data only; news third-party via NewsEdge.",
             "pulled": "5 and 6 October 2026",
             "tools": "Moody's Orbis · Research · Filings · NewsEdge"},
    "ticker": [
        "PizzaExpress preparing a possible sale at up to £500m (Marketline / FT, 21 Sep)",
        "Bridgepoint intends to sell its minority stake in Itsu (Marketline, 9 Sep)",
        "Greggs Q3 sales +7.7%, like-for-like +3.4%, outlook raised (Proactive, 30 Sep)",
        "Domino's to refinance £200m notes due Jul 2027 by year end (H1 call, 4 Aug)",
        "Moody's: UK food inflation to about 5% by early 2027 from 1.7% (6 Aug)",
        "Grocery inflation 2.3% (Worldpanel, 15 Sep); shop prices +1.4% in Sep (MSN, 4 Oct)",
        "Restaurant sales recovered in August (NIQ, 17 Sep)"],
    "month": app["MONTH"],
    "upcoming": app["UPCOMING"],
    "deal_signals": [
        {"company": "PizzaExpress", "short": "PizzaExpress sale process", "text": "Preparing a possible sale at up to £500m", "source": "Marketline citing the FT, 21 Sep 2026"},
        {"company": "Itsu", "short": "Itsu stake sale", "text": "Bridgepoint intends to sell its minority stake", "source": "Marketline, 9 Sep 2026"}],
    "refinancing": [
        {"company": "Domino's Pizza Group", "short": "Domino's £200m notes due Jul 2027, refinancing planned by end 2026", "source": "H1 2026 call, 4 Aug 2026"}],
    "companies": {a["id"]: {"read": a["read"], "why": a["readWhy"], "deal": a["deal"], "changed": a["changed"]} for a in app["CO"]},
    "sensitivity": {"company": "Greggs", "badge": "Greggs · food costs", "period": "FY2025", "cost_of_sales": 829.1,
                    "cos_source": "interim report comparatives", "ebitda": 346.1, "ebitda_basis": "Moody's format",
                    "note": "Cost of sales includes more than food, and about 70% of H2 2026 food and packaging is bought forward, so the exposure sits mainly in 2027."},
    "portfolio_read_across": [
        {"company": "PizzaExpress", "text": "Former TDR portfolio company (2003 take-private); no current TDR link in Moody's data.", "source": "Moody's credit opinion, 2 Jul 2026 (current owners)"}],
}
json.dump(syn, open(SH / "tdr-s3-synthesis.example.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("examples written")
