#!/usr/bin/env python3
"""Evals for the TDR skills.

Usage:
  python3 tdr_eval.py s2 tdr-s2-output.json tdr-golden.json [--stage names|numbers|news|all]
  python3 tdr_eval.py html dashboard.html tdr-golden.json [--s2 tdr-s2-output.json] [--as-of YYYY-MM-DD]

Exit code 0 = all checks passed, 1 = at least one FAIL. WARN never fails the run.
"""
import json, re, sys, datetime as dt

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"
results = []
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]


def rec(status, check, detail=""):
    results.append((status, check, detail))


def near(a, b, tol):
    return a is not None and b is not None and abs(float(a) - float(b)) <= tol


def full_months(d1, d2):
    """Whole months from d1 to d2 (27 Dec 2025 to 7 Oct 2026 is 9)."""
    m = (d2.year - d1.year) * 12 + d2.month - d1.month
    return m - 1 if d2.day < d1.day else m


def parse_date(s):
    for fmt in ("%Y-%m-%d", "%Y-%m"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except Exception:
            pass
    return None


def scan_banned(text, golden, label):
    hits = [n for n in golden["banned_names"] if re.search(r"\b" + re.escape(n) + r"\b", text, re.I)]
    rec(FAIL if hits else PASS, f"{label}: no excluded company names", ", ".join(hits))
    if "\u2014" in text:
        rec(FAIL, f"{label}: no em dashes", f"{text.count(chr(0x2014))} found")
    else:
        rec(PASS, f"{label}: no em dashes")


# ---------------------------------------------------------------- S2 ----
def check_names(c, g, golden, tag):
    ents = {e.get("legal"): e.get("id") for e in c.get("entities", [])}
    for legal, gid in g["entities"].items():
        got = ents.get(legal)
        if got == gid:
            rec(PASS, f"{tag} entity ID {legal}")
        elif got is None:
            rec(FAIL, f"{tag} entity ID {legal}", "entity missing from output")
        else:
            rec(FAIL, f"{tag} entity ID {legal}", "ID differs from golden: wrong match until proven otherwise")
    for e in c.get("entities", []):
        if not e.get("use"):
            rec(WARN, f"{tag} entity use recorded", e.get("legal", ""))
    own = c.get("ownership", {}) or {}
    t = own.get("type")
    rec(PASS if t == g["type"] else FAIL, f"{tag} ownership type", f"got {t!r}, golden {g['type']!r}")
    if t not in golden["allowed_types"]:
        rec(FAIL, f"{tag} ownership type allowed", repr(t))
    if g.get("flag_required"):
        rec(PASS if own.get("flag") else FAIL, f"{tag} ownership flag present", own.get("flag", ""))
    if g.get("top_owner_contains"):
        top = (own.get("top_owner") or "") + " " + json.dumps(own.get("chain", []), ensure_ascii=False)
        ok = g["top_owner_contains"].lower() in top.lower()
        rec(PASS if ok else WARN, f"{tag} top owner names {g['top_owner_contains']}", "check source; ownership may have changed")
    if own.get("top_owner") and not own.get("top_owner_source"):
        rec(FAIL, f"{tag} top owner has a source")
    chain = own.get("chain", [])
    bad = [x for x in chain if not (isinstance(x, list) and len(x) == 2 and x[1])]
    rec(FAIL if bad else PASS, f"{tag} every ownership level has a source", f"{len(bad)} without")
    mgmt = c.get("management", {}) or {}
    if g.get("ceo_contains"):
        ceo = mgmt.get("ceo") or ""
        rec(PASS if g["ceo_contains"].lower() in ceo.lower() else WARN, f"{tag} CEO names {g['ceo_contains']}", ceo)
    ceo = mgmt.get("ceo")
    if ceo and ceo != "n.d." and not mgmt.get("source"):
        rec(FAIL, f"{tag} CEO line has a source", "no source given")
    prof = c.get("profile") or {}
    missing = [k for k in ("hq", "description", "employees") if not prof.get(k)]
    rec(WARN if missing else PASS, f"{tag} profile filled for the page", ", ".join(missing))


def check_numbers(c, g, golden, tag, as_of):
    f = c.get("financials", {}) or {}
    pe = parse_date(f.get("period_end", "") or "")
    gpe = parse_date(g["period_end"])
    if pe is None:
        rec(FAIL, f"{tag} period end present")
        return
    rec(PASS if f.get("basis") in golden["allowed_bases"] else FAIL, f"{tag} basis labelled", repr(f.get("basis")))
    age = full_months(pe, as_of)
    if f.get("age_months") is not None:
        rec(PASS if abs(int(f["age_months"]) - age) <= 1 else FAIL, f"{tag} age in months", f"stated {f['age_months']}, computed {age}")
    if age > 12 and not f.get("stale"):
        rec(FAIL, f"{tag} stale flag", f"accounts {age} months old but not flagged stale")
    if pe == gpe:
        for k, tol in (("revenue", 0.15), ("revenue_growth", 0.15), ("ebitda", 0.15), ("margin", 0.2), ("debt_ebitda", None)):
            gv, ov = g.get(k), f.get(k)
            if tol is None and gv is not None:
                tol = max(0.02, abs(gv) * 0.02)  # leverage: 2% relative (40x on a tiny EBITDA moves with rounding)
            if gv is None:
                rec(PASS if ov is None else WARN, f"{tag} {k} is n.d. in golden", f"output has {ov}")
            else:
                rec(PASS if near(ov, gv, tol) else FAIL, f"{tag} {k}", f"got {ov}, golden {gv}")
        if f.get("basis") != g["basis"]:
            rec(FAIL, f"{tag} basis matches golden", f"got {f.get('basis')!r}, golden {g['basis']!r}")
        if g.get("listed"):
            for k in ("cfo", "capex", "fcf"):
                tol = g.get("fcf_tolerance", 0.15) if k == "fcf" else 0.15
                rec(PASS if near(f.get(k), g.get(k), tol) else FAIL, f"{tag} {k} matches golden", f"got {f.get(k)}, golden {g.get(k)}")
    elif pe > gpe:
        rec(WARN, f"{tag} newer period than golden", f"{pe} vs {gpe}: review figures by hand")
    else:
        rec(FAIL, f"{tag} period end", f"{pe} is older than golden {gpe}")
    if f.get("revenue") and f.get("ebitda") is not None and f.get("margin") is not None:
        calc = float(f["ebitda"]) / float(f["revenue"]) * 100
        rec(PASS if near(f["margin"], calc, 0.2) else FAIL, f"{tag} margin = EBITDA / revenue", f"stated {f['margin']}, calculated {calc:.1f}")
    if g.get("listed"):
        for k in ("cfo", "capex", "fcf"):
            rec(PASS if f.get(k) is not None else FAIL, f"{tag} {k} present (listed name)")
        if all(f.get(k) is not None for k in ("cfo", "capex", "fcf")):
            calc = float(f["cfo"]) - float(f["capex"])
            rec(PASS if near(f["fcf"], calc, g.get("fcf_tolerance", 0.15)) else FAIL, f"{tag} FCF = CFO minus capex", f"stated {f['fcf']}, calculated {calc:.1f}")
    else:
        for k in ("cfo", "capex", "fcf"):
            if f.get(k) is not None:
                rec(WARN, f"{tag} {k} given for a private name", "allowed only if filed accounts include a cash flow statement")
    # legacy per-year dict
    for y, row in (f.get("years", {}) or {}).items():
        if row.get("ebitda") is not None and row.get("ebita") is not None and near(row["ebitda"], row["ebita"], 0.05):
            rec(FAIL, f"{tag} {y} EBITDA equals EBITA", "depreciation missing; drop EBITDA, margin and leverage for that year")
    s = f.get("series") or {}
    yrs = s.get("years") or []
    if not yrs:
        rec(WARN, f"{tag} yearly series present", "no series: the page will show no historic chart")
    for k in ("revenue", "ebitda", "ebita", "margin", "debt_ebitda", "interest_cover", "forecast", "fcf_debt", "units"):
        if s.get(k) is not None and len(s[k]) != len(yrs):
            rec(FAIL, f"{tag} series.{k} length", f"{len(s[k])} values for {len(yrs)} years")
    eb, ea = s.get("ebitda") or [], s.get("ebita") or []
    for i, (x, y) in enumerate(zip(eb, ea)):
        if x is not None and y is not None and near(x, y, 0.05):
            rec(FAIL, f"{tag} {yrs[i]} EBITDA equals EBITA in series", "drop that year's EBITDA, margin and leverage")
        if x is None and y is not None:
            for k in ("margin", "debt_ebitda"):
                arr = s.get(k) or []
                if i < len(arr) and arr[i] is not None:
                    rec(FAIL, f"{tag} {yrs[i]} {k} left in after EBITDA was dropped")
    if any(s.get("forecast") or []):
        srcs = (c.get("moodys") or {}).get("forecasts") or c.get("projections")
        rec(PASS if srcs else FAIL, f"{tag} forecast years have a sourced forecast")
    # inputs for the traffic lights
    gr = f.get("growth") or {}
    if not gr:
        rec(FAIL, f"{tag} growth pair recorded", "financials.growth {value, end, prior_end, basis} drives the revenue growth light")
    else:
        rec(PASS if near(gr.get("value"), f.get("revenue_growth"), 0.05) else FAIL, f"{tag} growth.value = revenue_growth", f"{gr.get('value')} vs {f.get('revenue_growth')}")
        rec(PASS if (gr.get("end") and gr.get("prior_end")) or gr.get("label") else FAIL, f"{tag} growth periods stated")
        rec(PASS if gr.get("basis") in golden["allowed_bases"] else FAIL, f"{tag} growth basis labelled", repr(gr.get("basis")))
        if f.get("period_type") == "LTM" and not gr.get("label", "").startswith("FY"):
            rec(FAIL, f"{tag} growth compares like periods", "an LTM figure must not be compared with a calendar year; use two full years")
    mc = f.get("margin_change") or {}
    if not mc:
        rec(FAIL, f"{tag} margin change recorded", "financials.margin_change {value, current, prior, label, basis} drives the margin change light")
    else:
        miss = [k for k in ("value", "current", "prior", "label", "basis") if mc.get(k) in (None, "")]
        rec(FAIL if miss else PASS, f"{tag} margin change complete", ", ".join(miss))
        if not miss:
            rec(PASS if near(mc["value"], mc["current"] - mc["prior"], 0.051) else FAIL, f"{tag} margin change = current minus prior", f"{mc['value']} vs {mc['current']} - {mc['prior']}")
            rec(PASS if mc["basis"] in golden["allowed_bases"] else FAIL, f"{tag} margin change basis labelled", repr(mc["basis"]))
            if f.get("period_type", "FY") == "FY" and f.get("margin") is not None:
                rec(PASS if near(mc["current"], f["margin"], 0.051) else WARN, f"{tag} margin change starts from the margin shown", f"{mc['current']} vs {f['margin']}")
    for k in ("lfl", "market_share"):
        if f.get(k):
            rec(FAIL, f"{tag} no {k} field", "only metrics every name has go on the page")
    sp = (f.get("revenue_split") or {}).get("items")
    if sp:
        tot = sum(x.get("share", 0) for x in sp)
        rec(PASS if abs(tot - 100) <= 0.6 else FAIL, f"{tag} revenue split adds to 100%", f"{tot:.1f}%")
    for k in ("source",):
        if re.search(r"get[A-Z]\w+|search[A-Z]\w+|_v2", f.get(k) or ""):
            rec(FAIL, f"{tag} financials.source is written for people", "name the dataset, not the tool: " + f.get(k, "")[:60])
    m = c.get("moodys")
    if g.get("rated"):
        od = (m or {}).get("opinion_date")
        rec(PASS if od else FAIL, f"{tag} Moody's opinion present (rated)", od or "")
        if od and parse_date(od) and full_months(parse_date(od), as_of) > 6 and not (m or {}).get("newer_documents_checked"):
            rec(WARN, f"{tag} opinion older than 6 months", "newer documents must be checked and noted")
        for p in (m or {}).get("forecasts", []):
            if not p.get("source"):
                rec(FAIL, f"{tag} forecast has a source", json.dumps(p, ensure_ascii=False))
    else:
        rec(PASS if not m else FAIL, f"{tag} no Moody's view for an unrated name", "")
    for p in c.get("projections", []) or []:
        if not p.get("source"):
            rec(FAIL, f"{tag} projection has a source", json.dumps(p, ensure_ascii=False))


def check_news(c, g, golden, tag, as_of):
    n = c.get("news", {}) or {}
    fetched, kept = n.get("fetched"), n.get("kept")
    items = n.get("items", []) or []
    if fetched is None or kept is None:
        rec(FAIL, f"{tag} kept out of fetched recorded")
    else:
        rec(PASS if kept <= fetched and kept == len(items) else FAIL, f"{tag} kept <= fetched and matches items", f"kept {kept}, fetched {fetched}, items {len(items)}")
    for it in items:
        pub = it.get("publisher", "")
        if any(b.lower() in pub.lower() for b in golden["banned_publishers"]):
            rec(FAIL, f"{tag} banned publisher kept", pub)
        if not it.get("date") or not pub:
            rec(FAIL, f"{tag} news item has date and publisher", json.dumps(it, ensure_ascii=False)[:80])
        d = parse_date(it.get("date", "") or "")
        if d and (as_of - d).days > 95:
            rec(FAIL, f"{tag} news item inside 90-day window", it.get("date"))
        if it.get("tag") not in ("Results", "Deal", "Costs", "Demand", "Sites", "Other"):
            rec(FAIL, f"{tag} news tag allowed", repr(it.get("tag")))
        if "direction" in it:
            rec(FAIL, f"{tag} news item has no direction", "positive or negative is a judgement; remove the field")
        check_wording(it.get("headline", ""), golden, f"{tag} news headline")


def check_wording(text, golden, label):
    """Fail on verdict labels and dramatic verbs: the page states facts, not views."""
    low = (text or "").lower()
    if not low.strip():
        rec(FAIL, f"{label} present")
        return
    bad = [w for w in golden.get("judgement_words", []) + golden.get("dramatic_words", []) if re.search(r"\b" + re.escape(w) + r"\b", low)]
    rec(FAIL if bad else PASS, f"{label} is factual", (", ".join(bad) + ": " + text[:70]) if bad else "")


def eval_s2(out, golden, stage):
    as_of = parse_date(out.get("as_of", "")) or dt.date.today()
    gcos = golden["companies"]
    cos = {c.get("name"): c for c in out.get("companies", [])}
    missing = [n for n in gcos if n not in cos]
    rec(FAIL if missing else PASS, "all seed names present", ", ".join(missing))
    scan_banned(json.dumps(out, ensure_ascii=False), golden, "output")
    for name, g in gcos.items():
        c = cos.get(name)
        if not c:
            continue
        tag = f"[{name}]"
        if stage in ("names", "all"):
            check_names(c, g, golden, tag)
        if stage in ("numbers", "all"):
            check_numbers(c, g, golden, tag, as_of)
        if stage in ("news", "all"):
            check_news(c, g, golden, tag, as_of)


# -------------------------------------------------------------- HTML ----
def page_data(html):
    m = re.search(r"/\*TDR_DATA_START\*/(.*?)/\*TDR_DATA_END\*/", html, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(1).replace("<\\/", "</"))
    except Exception as e:
        rec(FAIL, "page data block is valid JSON", str(e)[:120])
        return None


def eval_html(path, golden, s2_path=None, as_of=None):
    html = open(path, encoding="utf-8").read()
    scan_banned(html, golden, "page")
    for name in golden["companies"]:
        rec(PASS if name.split()[0] in html else FAIL, f"page names {name}")
    for bad in ("undefined", "NaN", "[object Object]", "TBD", "lorem"):
        rec(FAIL if bad in html else PASS, f"page has no literal {bad!r}")
    for ext in ("<script src=\"http", "<link rel=\"stylesheet\" href=\"http", "fetch(", "XMLHttpRequest"):
        rec(FAIL if ext in html else PASS, f"page makes no network call ({ext.strip()})")
    m = re.search(r"As of (\d{1,2}) (\w+) (\d{4})", html)
    rec(PASS if m else FAIL, "page shows an 'As of' date")
    for word in ("Moody's forecast", "calculated", "n.d."):
        rec(PASS if word in html else WARN, f"page uses the label {word!r}")
    data = page_data(html)
    if data is None:
        rec(WARN, "page has a TDR data block", "built by hand? data checks skipped")
        return
    meta = data.get("meta", {})
    if as_of:
        want = f"{as_of.day} {MONTHS[as_of.month - 1]} {as_of.year}"
        shown = " ".join(m.groups()) if m else ""
        rec(PASS if shown == want else FAIL, "As of date is the run date", f"page says {shown!r}, expected {want!r}")
        rec(PASS if meta.get("asOf") == as_of.isoformat() else FAIL, "data block as-of is the run date", meta.get("asOf", ""))
    # leftover dates in the renderer (everything outside the data block, <title> and the As of line)
    rest = re.sub(r"/\*TDR_DATA_START\*/.*?/\*TDR_DATA_END\*/", "", html, flags=re.S)
    rest = re.sub(r"<title>.*?</title>", "", rest, flags=re.S)
    rest = re.sub(r'id="hdrMeta">As of [^<]*', "", rest)
    old = re.findall(r"\b\d{1,2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w* 20\d\d\b", rest)
    rec(FAIL if old else PASS, "no hard-coded dates outside the data block", ", ".join(sorted(set(old)))[:200])
    cos = data.get("companies", [])
    for c in cos:
        n = len([v for v in c.get("revS", []) if v is not None])
        if c.get("fc") and not c.get("proj"):
            rec(FAIL, f"[{c['name']}] forecasts drawn without a sourced forecast line")
        if n == 1:
            rec(WARN, f"[{c['name']}] one revenue point", "chart will be skipped; single figure shown in the table")
    # v3: no verdicts, an explicit question, a sourced benchmark, typed research
    low = json.dumps(data, ensure_ascii=False).lower()
    bad = sorted({w for w in golden.get("judgement_words", []) if re.search(r"\b" + re.escape(w) + r"\b", low)})
    rec(FAIL if bad else PASS, "page data has no verdict wording", ", ".join(bad))
    for it in data.get("feed", []):
        check_wording(it.get("h", ""), golden, f"feed headline {it.get('d', '')}")
    rec(PASS if meta.get("question") else FAIL, "page shows the starting question")
    rec(PASS if "(QSR)" in (meta.get("question", "") + meta.get("title", "")) else WARN, "QSR spelled out at the top")
    bench = (meta.get("market") or {}).get("benchmark")
    rec(PASS if bench and bench.get("source") and bench.get("period") and bench.get("value") is not None else WARN, "market context line with value, period and source")
    for grp, items in (((meta.get("trigger") or {}).get("evidence")) or {}).items():
        for x in items:
            rec(PASS if x.get("kind") in golden.get("research_kinds", []) else FAIL, f"trigger {grp} item has a source type", x.get("text", "")[:50])
    rec(FAIL if re.search(r"id=\"scatter|Margin vs Leverage|readSeg|Our read", html) else PASS, "no bubble chart or verdict filter in the page")
    if s2_path:
        s2 = json.load(open(s2_path, encoding="utf-8"))
        check_lights(data, s2)
        by = {c["name"]: c for c in cos}
        kept = {k[0]: k for k in data.get("kept", [])}
        for sc in s2.get("companies", []):
            name, f = sc["name"], sc.get("financials", {}) or {}
            pc = by.get(name)
            if not pc:
                rec(FAIL, f"[{name}] on the page", "in S2 output but missing from the page")
                continue
            for sk, pk in (("revenue", "rev"), ("ebitda", "ebitda"), ("margin", "margin"), ("debt_ebitda", "lev"), ("fcf", "fcf"), ("revenue_growth", "revG")):
                a, b = f.get(sk), pc.get(pk)
                ok = (a is None and b is None) or near(a, b, 0.05)
                rec(PASS if ok else FAIL, f"[{name}] page {sk} matches S2", f"page {b}, S2 {a}")
            rec(PASS if pc.get("type") == (sc.get("ownership") or {}).get("type") else FAIL, f"[{name}] page ownership type matches S2")
            rec(PASS if bool(pc.get("rated")) == (sc.get("moodys") is not None) else FAIL, f"[{name}] Moody's view only for rated names")
            n = sc.get("news") or {}
            k = kept.get(name)
            rec(PASS if k and k[1] == len(n.get("items", [])) and k[2] == n.get("fetched") else FAIL,
                f"[{name}] page kept/fetched matches S2", f"page {k[1:3] if k else None}, S2 {len(n.get('items', []))}/{n.get('fetched')}")
            feed_n = len([x for x in data.get("feed", []) if x.get("co") == pc["id"]])
            rec(PASS if feed_n == len(n.get("items", [])) else FAIL, f"[{name}] page news items match S2", f"page {feed_n}, S2 {len(n.get('items', []))}")
        extra = [c["name"] for c in cos if c["name"] not in {x["name"] for x in s2.get("companies", [])}]
        rec(FAIL if extra else PASS, "no page company missing from S2", ", ".join(extra))


def light_colour(k, f, cfg):
    """Recompute a light from the S2 figures and the thresholds on the page."""
    def change(v, band):
        return "grey" if v is None else ("up" if v >= band else ("down" if v <= -band else "flat"))
    if k == "growth":
        return change((f.get("growth") or {}).get("value", f.get("revenue_growth")), cfg["revenue_growth"]["band"])
    if k == "margin":
        v, g = f.get("margin"), cfg["margin"]
        return "grey" if v is None else ("green" if v >= g["green_min"] else ("amber" if v >= g["amber_min"] else "red"))
    if k == "mchange":
        return change((f.get("margin_change") or {}).get("value"), cfg["margin_change"]["band"])
    if k == "lev":
        eb, mg, v, g = f.get("ebitda"), f.get("margin"), f.get("debt_ebitda"), cfg["leverage"]
        if (eb is not None and eb < 0) or (mg is not None and mg < 0):
            return "red"
        return "grey" if v is None else ("green" if v < g["green_max"] else ("amber" if v <= g["amber_max"] else "red"))


def check_lights(data, s2):
    cfg = ((data.get("meta") or {}).get("lights") or {}).get("cfg")
    if not cfg:
        rec(FAIL, "page carries the light thresholds")
        return
    by = {c["name"]: c for c in data.get("companies", [])}
    for sc in s2.get("companies", []):
        pc = by.get(sc["name"])
        if not pc:
            continue
        L = {x["k"]: x for x in pc.get("lights", [])}
        rec(PASS if set(L) == {"growth", "margin", "mchange", "lev"} else FAIL, f"[{sc['name']}] four lights", ", ".join(L))
        lt = pc.get("latest") or {}
        rec(PASS if lt.get("text") and lt.get("src") else FAIL, f"[{sc['name']}] latest development with a source")
        for k, x in L.items():
            want = light_colour(k, sc.get("financials") or {}, cfg)
            rec(PASS if x.get("c") == want else FAIL, f"[{sc['name']}] {k} light follows its rule", f"page {x.get('c')}, rule gives {want} ({x.get('v')})")
            if x.get("c") != "grey":
                miss = [m for m in ("period", "basis", "src", "rule") if not x.get(m)]
                rec(FAIL if miss else PASS, f"[{sc['name']}] {k} light has period, basis, source and rule", ", ".join(miss))


# -------------------------------------------------------------- main ----
def main():
    if len(sys.argv) < 4:
        print(__doc__); sys.exit(2)
    mode, path, gpath = sys.argv[1], sys.argv[2], sys.argv[3]
    opt = lambda k: sys.argv[sys.argv.index(k) + 1] if k in sys.argv else None
    stage = opt("--stage") or "all"
    golden = json.load(open(gpath, encoding="utf-8"))
    if mode == "s2":
        try:
            out = json.load(open(path, encoding="utf-8"))
        except Exception as e:
            print(f"FAIL  output is not valid JSON: {e}"); sys.exit(1)
        eval_s2(out, golden, stage)
    elif mode == "html":
        eval_html(path, golden, opt("--s2"), parse_date(opt("--as-of")) if opt("--as-of") else None)
    else:
        print(__doc__); sys.exit(2)
    counts = {s: sum(1 for r in results if r[0] == s) for s in (PASS, WARN, FAIL)}
    for s, check, detail in results:
        if s != PASS:
            print(f"{s:5} {check}" + (f"  ({detail})" if detail else ""))
    print(f"\n{counts[PASS]} passed, {counts[WARN]} warnings, {counts[FAIL]} failed")
    sys.exit(1 if counts[FAIL] else 0)


if __name__ == "__main__":
    main()
