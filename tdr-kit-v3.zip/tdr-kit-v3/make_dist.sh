#!/bin/sh
# Copy the shared files into each skill and zip each skill for upload.
# Run from the kit folder after editing anything in shared/.
set -e
cd "$(dirname "$0")"
S1=skills/tdr-s1-trigger/files
S2=skills/tdr-s2-names-evidence/files
S3=skills/tdr-s3-dashboard/files
mkdir -p "$S1" "$S2" "$S3" dist

# The S3 template ships with the 7 Oct v3 example data in it, so it opens as the approved page.
python3 shared/build_dashboard.py --s1 shared/tdr-s1-output.example.json --s2 shared/tdr-s2-output.example.json \
  --syn shared/tdr-s3-synthesis.example.json --template shared/tdr-dashboard-template.html \
  --out "$S3/tdr-dashboard-template.html" > /dev/null

cp shared/tdr-s1-output.example.json "$S1/"
cp shared/tdr_eval.py shared/tdr-golden.json shared/tdr-s2-output.example.json "$S2/"
cp shared/build_dashboard.py shared/tdr_eval.py shared/tdr-golden.json \
   shared/tdr-s1-output.example.json shared/tdr-s2-output.example.json shared/tdr-s3-synthesis.example.json "$S3/"

rm -f dist/*.zip
for s in tdr-s1-trigger tdr-s2-names-evidence tdr-s3-dashboard; do
  (cd skills && zip -qr "../dist/$s.zip" "$s" -x '*.DS_Store' -x '*__pycache__*')
done
echo "skills refreshed; zips in dist/"
ls -la dist
