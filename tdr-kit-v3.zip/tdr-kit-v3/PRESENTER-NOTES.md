# Presenter notes: Workflow 1, Friday

From Saul's prep call on 7 Oct. About 60 people across investment, IR, legal, compliance and operations.

## Shape of the session

1. About 5 minutes of setup, then go straight into the UK QSR and casual dining research. This is the main workflow.
2. Walk through the conversation, not the tools. Show what was asked at each stage and what came back. Don't dwell on tool names.
3. Spend real time on the sources (the Sources tab and the labels on each item). Saul expects this to be one of the most valuable parts: "don't just fly through it."
4. Say early, and again at the end: it uses Moody's data only, and the team can rerun and update it themselves.

## The story to tell

Saul's own framing: "We looked at macro. This gave us an idea of what the market growth looks like. Then we looked at peers."

| Step | Where on the page | What to say |
|---|---|---|
| The question | The bar at the top | UK food inflation is rising again because of energy costs. What does that mean for UK quick service restaurants (QSR: fast food, takeaway, food-to-go) and casual dining (sit-down, mid-priced chains)? |
| Macro | Macro trigger panel | Moody's research expects food inflation to rise from 1.7% to about 5% by early 2027. Current prices have not moved much yet. Greggs itself now flags greater inflationary pressure in 2027. Each item is labelled macro research, sector research, credit opinion or company statement. |
| Market | Context line above the screen | UK hospitality like-for-like sales were +0.5% in the 12 months to July 2026 (NIQ RSM, as cited in Moody's own UK research). That is the backdrop: a flat market. |
| Peers | Company screen | Four indicators per company on published figures every name has. Two arrows, no colour, because direction is a fact: revenue growth and margin change on the prior year. Two lights with a stated threshold: EBITDA margin and leverage. Hover over any of them for the figure, period, basis, rule and source. The last column is each company's latest development, with its source. |
| One company | Click a row | The full company page: the four indicators in detail, what changed, deal and financing facts, accounts, ownership, the Moody's credit opinion if rated, and the news. |
| Sources | Sources tab | Every Moody's document by type, the company data behind each name, filings, and how much news was kept out of what was fetched. |

## How the names were chosen (Saul asked)

What to say: the nine are UK chains in the segment, picked to cover every ownership type. Three are listed, four are sponsor- or credit-fund-owned and two are family-owned, because ownership type is what points to a deal route for a buyout fund. Each has company data in Moody's Orbis.

What Moody's holds on them:
- Two are rated (PizzaExpress and Wagamama), so they also have Moody's credit opinions.
- The other seven are covered by Orbis accounts, filings for the three listed names, and news.
- Gail's has no listed debt and no rating; it is in for its ownership type.

Be straight about where the list came from. The seed list is set in the Stage 1 skill. Claude proposes it at the end of Stage 1 and the presenter confirms it before Stage 2. With a different trigger, Stage 1 would propose a different list.

## Which accounts each figure comes from

Orbis holds accounts per legal company, so the page says which one on each company page and in the Sources tab:
- **Listed names (Greggs, Domino's, Tortilla):** the listed parent's group accounts.
- **Rated names (PizzaExpress, Wagamama):** Moody's credit opinions on the group, plus Wagamama (Holdings) group accounts.
- **Gail's and Nando's:** the group parents' accounts (Grain Topco Limited; Nando's Group Holdings Limited), to February 2025. These carry the group's debt, which is why their leverage is 6.44x and 4.55x. The operating companies alone show 0.51x and 1.08x.
- **Pret:** the UK trading company, Pret A Manger (Europe) Limited, to 1 January 2026. The parent's accounts hold only debt (£599.8m) and assets, so Moody's has no group revenue.
- **Itsu:** the restaurant company, Itsu Limited, to 1 January 2026. The grocery business files separately (£75.8m revenue); Moody's has no combined accounts.

## If anyone challenges a company or a figure

- Saul's line: "we're just trying to demonstrate... this is just demonstrative." The page shows published figures with their source; it is not an equity view.
- The arrows and lights carry no verdict. Arrows show direction; lights apply a stated threshold to one number. The thresholds were set for the demo, not by Moody's; change them in one file and rebuild.

**Greggs** reads: growth up 6.8%, margin green at 16.1%, margin change down 1.6 points on 2024, leverage green at 1.19x. The down arrow is the one that matches the news on its page: four manufacturing sites and about 740 roles proposed for closure, Derby and Kettering adding costs in 2027, greater inflationary pressure flagged for 2027. The same update raised the 2026 outlook on Q3 sales up 7.7%.

## Questions to be ready for

| Question | Answer |
|---|---|
| Greggs has net cash; why debt/EBITDA of 1.19x? | Moody's data counts lease liabilities as debt (total £474.8m). Greggs reports net cash of £15.9m before leases at June 2026. Both are on the company page. |
| Gail's is low-debt, isn't it? | Gail's Limited alone is (0.51x). The group parent, Grain Topco, carries £329.4m of debt, 6.44x EBITDA, with interest cover of 0.76x, in its filed accounts to February 2025. The data does not itemise it. |
| Nando's at 4.55x? | Group accounts: Nando's Group Holdings has £1,305m of debt against £286.9m EBITDA. The UK operating company alone shows 1.08x. Both are on the page. |
| Pret is a £1bn-plus business; why £705m? | The figure is the UK trading company's accounts to 1 January 2026. The parent's accounts in Moody's hold only debt and assets, so there is no group revenue to show. |
| Why does Pret show a big margin recovery? | EBITDA went from a £47.9m loss (year to Jan 2025) to £42.5m (year to Jan 2026). Other operating expenses were £117m higher in the loss year; the data does not say why. |
| Itsu's revenue looks small. | It is the restaurant company only, £123.7m to January 2026. The grocery business is a separate company with £75.8m of revenue; Moody's has no combined accounts. |
| Why is PizzaExpress EBITDA £55m and its margin 19.1%? | £55m is the company's own pre-IFRS 16 figure; 19.1% is Moody's-adjusted, for the 12 months to March 2026. Both are labelled. |
| Why is PizzaExpress revenue growth negative? | −0.5% is full-year 2025 on 2024, Moody's-adjusted. The 12 months to March 2026 were slightly higher, but comparing that with a calendar year would mix overlapping periods. |
| Wagamama's margin arrow points up? | On filed accounts, 2024 EBITDA was unusually low (£33.1m against £71.8m in 2023 and £75.9m in 2025); the data does not explain it. On Moody's-adjusted figures the margin fell. Both are on the page. |
| Why are Gail's and Nando's accounts 19 months old? | Private companies file late and Orbis shows what has been filed; February 2025 is the latest year for both. The age is on every one. |
| Is this Moody's view? | No. Only the credit opinion sections (PizzaExpress, Wagamama) are Moody's views, and they are labelled. |
| Can we update it ourselves? | Yes. The same three steps can be rerun on new data or a new question. |

## Before you go in

- Thursday: run S1, S2 and S3 in Cowork and publish the page.
- Friday: run `/tdr-s1 warmup` 8 to 10 minutes before the live S1 run.
- Have the Sources tab and the Greggs company page ready to show.
