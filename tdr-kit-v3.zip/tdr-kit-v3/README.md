# TDR Capital demo kit: trigger to dashboard on Moody's data (v3, 7 Oct 2026)

One workflow, three commands, one eval, one build script. Each skill carries its own files.

## What changed in v3 (client feedback, 7 Oct)

Saul's point: the audience know these companies, so every figure must be current, sourced and labelled, and any view must come from checkable metrics, not a verdict.

- **No verdicts.** Winner, Neutral, Pressured and "our read" are gone from the data, the page and the skills. The build and the eval fail on that wording and on dramatic verbs in headlines.
- **Four indicators** on published figures that every name has, worked out by the build script from fixed rules stated on the page. Two arrows with no colour, because direction is a fact: revenue growth over two full years, and margin change on the prior year. Two traffic lights with a stated threshold: EBITDA margin and leverage (debt/EBITDA). Each shows its figure, period, basis, rule and source. Market share and like-for-like sales were tried and dropped: Moody's data holds them for one or two names only.
- **Market context from Moody's research** above the screen: UK hospitality like-for-like sales +0.5% in the 12 months to July 2026 (NIQ RSM, cited in Moody's Credit Conditions – UK, 2 Sep 2026).
- **Basis and period on every figure.** Labels are "As reported" or "Moody's-adjusted", with periods like "FY Dec-25" and "LTM Mar-26". Moody's Ratings Format pulls now ask for `reportingBasis` "reported" explicitly.
- **Scope of the private names fixed.** Orbis holds accounts per legal company. Gail's and Nando's now use the group parents' accounts (Grain Topco: revenue £278.1m, leverage 6.44x; Nando's Group Holdings: £1,476.3m, 4.55x), which carry far more debt than the operating companies shown before (0.51x and 1.08x). Pret and Itsu now use their accounts to 1 January 2026, nine months old, which the v2 skill missed because it asked for years up to 2025 and Orbis labels those accounts "2026". Pret's EBITDA is back to £42.5m from a £47.9m loss.
- **Figures re-checked against live Moody's data.** PizzaExpress growth is −0.5% (FY 2025 on FY 2024, Moody's-adjusted); the v2 +1.0% compared overlapping periods. Greggs' £474.8m debt is mostly leases, and the company reports net cash before leases; the page says so.
- **News is factual and two-sided**, with no positive or negative tags. Greggs' 30 Sep update shows both sides: Q3 sales +7.7% and a raised outlook; four manufacturing sites and about 740 roles proposed for closure; Derby and Kettering adding costs in 2027; greater inflationary pressure flagged for 2027 (also in the macro panel).
- **Starting question at the top**, with QSR spelled out and a line on how the names were chosen.
- **Research labelled by type**: macro research, sector research, or credit opinion (rated issuer). A new **Sources** tab lists every source and the news kept out of fetched.
- **Removed**: the bubble chart, the illustrative sensitivity, the market-share column and the side drawer (it could not scroll). Clicking a company opens the full Company tab, with Previous and Next buttons.

The v2 kit is unchanged in `../tdr-kit-v2`. `run-2026-10-07/` holds the v3 inputs and page for 7 Oct; the same files are the examples in `shared/`.

## Folder layout

| Path | What it is |
|---|---|
| `skills/tdr-s1-trigger/` | `SKILL.md` + `files/tdr-s1-output.example.json` |
| `skills/tdr-s2-names-evidence/` | `SKILL.md` + `files/` with `tdr_eval.py`, `tdr-golden.json`, `tdr-s2-output.example.json` |
| `skills/tdr-s3-dashboard/` | `SKILL.md` + `files/` with `build_dashboard.py`, `tdr-dashboard-template.html`, `tdr_eval.py`, `tdr-golden.json` and the three example JSON files |
| `dist/` | One zip per skill, ready to upload |
| `shared/` | The single source for files used by more than one skill. Edit here, then run `make_dist.sh` |
| `reference/` | The long-form prompt pack, updated for the 7 Oct tool checks |
| `dev/` | How the v2 template was derived from the original page (history only; the v3 template is edited directly in `shared/`) |
| `run-2026-10-07/` | The 7 Oct v3 inputs (S1, S2, synthesis) and the page built from them |
| `PRESENTER-NOTES.md` | Talking points for Friday, from Saul's call |

## Installing the skills

Upload each zip in `dist/` as a skill (Settings > Capabilities > Skills > Upload, or the skills panel in Cowork). Each zip holds one folder with `SKILL.md` and `files/`. If you already saved v1 skills with the same names, replace them.

If you change a shared file (the golden file, the eval, the template, the build script, an example), edit it in `shared/` and run `./make_dist.sh`. That copies it into each skill and rebuilds the zips.

## Running order

**Thursday (day before), in Cowork with the Moody's connector on:**

1. `/tdr-s1 UK food inflation rising again, driven by energy costs`. Confirm the segment and seed list when it stops. Keep `tdr-s1-output.md` and `.json`.
2. `/tdr-s2 names`. The first call starts loading filings for the listed names. Check the entity table against the IDs the eval reports, then confirm.
3. `/tdr-s2 numbers`. Read the FAIL and WARN lines; a WARN for a newer period means new accounts arrived, so review by hand. Confirm.
4. `/tdr-s2 news`. Confirm.
5. `/tdr-s3`. It writes the synthesis, prints the data audit (what will not be shown) and stops. Confirm. It then builds, checks and publishes the page.

**Friday (live):**

1. About 8 to 10 minutes before you run `/tdr-s1` live: `/tdr-s1 warmup`. Loading takes about 5 to 8 minutes and a load lasted under about 20 minutes on 7 Oct, so do not warm up earlier than that. If a company still says "still loading", run it again after 3 minutes. If filings are not ready during the live run, S1 marks the links that need them and carries on.
2. In the meeting: show `/tdr-s1` running (a few minutes; narrate it), then open the dashboard published on Thursday. Do not run S2 or S3 live. See `PRESENTER-NOTES.md`.

## Rules every skill carries

- Moody's data only, no web search.
- Ownership type is the organising principle; there is no ratings column.
- Describe, never judge: published figures, fixed thresholds, plain-fact headlines.
- Stonegate, Leon, supermarkets and Burger King UK are excluded. Supermarket figures are allowed only as macro evidence, never named.
- Source and date on every figure; basis ("As reported" or "Moody's-adjusted") and period on every number.
- Forecasts only where sourced. No calculated impact numbers.
- No empty charts. No em dashes.

## What the eval cannot do

It catches:
- transcription errors and wrong entity matches
- broken arithmetic and wrong capex lines
- missing flags and stale dates
- page numbers that differ from S2
- rule breaks

It cannot tell you that a figure the tool really returned is wrong. The skills are told never to edit a figure to make the eval pass; glance at the FAIL lines yourself.

## Tool facts the skills depend on (checked 7 Oct 2026)

- `searchAllDocuments` takes `keywords`, `filter` (publishDate "YYYY-MM-DD to YYYY-MM-DD", regions, sectors) and optional `entities` (up to 5). Unresolved sector names are dropped silently. The Restaurants filter works.
- `searchPrecisReports` takes `keywords` and optional `entities`; it has no sort. The newest UK Précis is the December 2025 vintage (16 Jan 2026).
- `searchNews` takes one entity per call. Topic news needs `searchType` "hybrid" and `rerankResults` true. `maxResultsPerEntity` goes up to 500 (100 with rerank).
- `findEntity` runs once per query with all names in `data`. "PizzaExpress" resolves to PizzaExpress Financing 2 plc; use the alternatives.
- `searchCompanyFilings` accepts only `annual`, `interim`, `earnings_call_transcript`. Loading took 5 to 8 minutes on 7 Oct and the load lasted between about 13 and 21 minutes. Responses are large: about 50,000 characters for one filing type, 129,000 to 185,000 for three, 279,000 for three companies, so the skills call one company and one filing type at a time. Tortilla has no filings in the tool.
- `getEntityUltimateOwners` threshold is the string "25.01".
- `getEntityFinancials_v2`:
  - Itsu's key indicators came back without EBITDA on 7 Oct; `sections` ["balance_sheet"] with `source` "standard" returns the detailed figures.
  - `accountNames` with `reportingBasis` "reported" cuts the cash flow pull to two lines per company.

## Dry run, 7 Oct 2026

v3 re-check on 7 Oct (after client feedback): S2 eval 266/266, page 262/262, no console errors and no sideways scroll at phone width on every tab and company page; the company page scrolls to the end. The paragraph below is the v2 dry run.

The three skills were run end to end on live data from the packaged zips: S1, S2 names (eval 56/56), numbers (106/106), news, all stages (168/168), S3 audit, build and page check (118/118), no console errors at phone, laptop and desktop width. Fixes from that run are in this version: one company and one filing type per filings call, working sector names for S1, Burger King added to S1's exclusions, the debt-structure search for rated names, moving mis-tagged news to the right company, the TDR link only when a tool returns it, and an optional `feed_extra` for sector news. New since 6 Oct: Wagamama's parent TRG selling its airport concessions to Areas (16 Jul); Goldman Sachs lined up for the Itsu stake sale (10 Sep); Itsu's third consecutive annual loss (9 Sep); more approaches for PizzaExpress (23 Sep); Pret's CEO named in trade press (Pano Christou, 18 Sep); Tortilla's CEO citing 2025 accounting issues in France (27 Jul).

## Open before Friday

- **Rules.** The flat bands for the arrows (1% for growth, 0.5 pts for margin change) and the light thresholds (15% and 5% for margin, 3.0x and 5.0x for leverage) are mine, set for the demo. Change them in `tdr-s3-synthesis.json` and rebuild. Greggs reads: growth up, margin green, margin change down (−1.6 pts), leverage green.
- **Group debt.** Gail's group leverage (6.44x, interest cover 0.76x) and Nando's (4.55x) are far above what the operating companies showed. The data does not itemise the group debt; leases and shareholder loans are likely (inference). Expect the room to know this.
- **Not in the returned Moody's text**, so not on the page: the Greggs restructuring cost (about £60m) and savings (about £20m a year); the energy link for its 2027 warning.
- **Greggs CFO.** Kalkine Media (7 Oct) reports a new CFO hired from Bakkavor. No primary source yet; it is listed as a data gap.
- **Second Moody's connector.** This session had two Moody's connectors on: "Moody's Credit MCP" (the one the skills use) and an older "Moody's" with different tool names. If Cowork shows both, switch the older one off.
- Nando's owner ("L. Perlman SECS", Orbis only).
- Reason for Tortilla's share suspension, 1 to 27 Jul 2026. Not stated in the data, but FY2025 results came out on 27 Jul (the day it lifted) and the CEO cited 2025 accounting issues in France (The Independent, 27 Jul), which points to late accounts (inference). Tortilla's director data names Maria Denny as CFO while the H1 call names Richard Haley.
- Itsu: Orbis says Bridgepoint 100% via a bidco, news says a minority stake.
- PizzaExpress: treated as a former TDR holding (2003 take-private) because Moody's names other current owners; no tool returned the link. Change the wording in S2 if you want it treated as current.
- Whether the macro connector is available in the demo session.
