# Presenter notes: Workflow 2, UK supermarkets

For the second page Saul asked for, built with the same three skills. The audience owns Asda, so they know these numbers better than anyone in the room. Everything below is about being straight on where each figure comes from.

## The story to tell

A different shape from workflow 1: the names and the screen first, then the sector and macro view below it, then one company.

| Step | Where on the page | What to say |
|---|---|---|
| The names | The line under the header | Eleven UK grocers, every ownership type, including one TDR portfolio company. There is no starting question and no KPI cards: this page is a side-by-side view of the sector. |
| Market | Context line above the screen | Food retail sales +2.6% year on year in August (BRC-KPMG, via Retail Gazette). Say plainly that this one comes from news via Moody's NewsEdge, because the Moody's documents returned did not carry a market-wide figure. |
| Peers | Company screen | Four indicators per company on published figures every name has. Two arrows, no colour: revenue growth and margin change. Two lights with stated thresholds: EBITDA margin (6% and 3%, set for grocery) and leverage (3.0x and 5.0x). Hover for figure, period, basis, rule and source. |
| Sector and macro | Panel below the screen | Macro: State of the Consumer (29 Sep 2026: inflation 3.1%, consumer spending about 1% in 2026) and the Précis UK report (December 2025 vintage: GDP about 1% in 2026, consumption +0.5%, unemployment 5.1%, CPI 2.4%; say that it predates the energy shock). Sector: Credit Conditions UK (consumer-facing sectors broadly fine, pockets of weakness) and the grocery in-depth (scale protects margins, volumes stable, price competition; food inflation rising towards 5%). News: sales, prices, the CMA decision on Aldi and Lidl, the Argos sale, the Morrisons merger report. Each item is labelled by type. |
| One company | Click a row | Start with a listed name (Tesco: group accounts, Moody's-adjusted 3.0x next to the as-reported 2.94x, Baa2 upgrade in May, board and management from Orbis). Then Asda, on your terms (below): the ownership chain ends at TDR Capital LLP and the beneficial-owner note lists the six individuals Orbis records. |
| Sources | Sources tab | Every Moody's document by type, the entity behind each company's figures, and the news kept out of fetched. |

## How the names were chosen

Eleven UK grocers picked to cover every ownership type: four listed (Tesco, Sainsbury's, Marks and Spencer, Ocado), two sponsor-owned (Asda, Morrisons), three family-owned (Aldi, Lidl, Iceland) and two mutual or employee-owned (Co-op, Waitrose). Seven are rated by Moody's and have credit opinions. Ocado is in as the online grocer and technology group, with the note that Ocado Retail is consolidated by M&S. Be straight that the list is set in the Stage 1 skill and confirmed before Stage 2.

## Asda: say this before anyone asks

The page shows Asda's leverage as **5.7x**, labelled as Moody's forecast for 2026 made in April 2025, which is Saul's number. Beneath it: the actual 8.3x at end-2025 and Moody's April 2026 forecast of 7.9x. All are Moody's numbers, a year apart:

| Moody's document | 2024 | 2025 | 2026 | 2027 |
|---|---|---|---|---|
| Credit opinion, 10 Apr 2025 (B1, outlook negative) | 5.9x actual | 6.8x forecast | **5.7x forecast** | |
| Credit opinion, 17 Apr 2026 (downgraded to B2) | 5.9x | **8.3x actual** | 7.9x forecast | 6.7x forecast |

What happened in between: 2025 Moody's-adjusted EBITDA came in at £1,079m, nearly £400m below 2024 and about £200m below Moody's forecast, mainly from the Project Future IT programme's effect on availability; a £531m sale and leaseback in November 2025 added lease liabilities. Moody's downgraded to B2 on 13 April 2026 and now sees leverage peaking at 8.6x in March 2026 and falling below 8.0x by the end of this year.

The company's own measure is different again: net debt to after-rent EBITDA, which the FT puts at 5.7x for 2024 and 6.9x for 2025. Moody's adds nearly £400m a year of lease and ground rent back to EBITDA and counts the lease liabilities as debt, so its ratio is higher on both sides. The FT figure is not in Moody's data, so it is not on the page.

What to say, in one breath: "The 5.7x on the screen is Moody's forecast for 2026 from April last year. After the 2025 results Moody's revised it: 8.3x at end-2025, 7.9x forecast for this year, 6.7x for next. The company's own after-rent measure runs lower, around 6.9x on the FT's figure. Same direction on every basis, and the page says which one it shows." The Asda leverage card carries this history with its sources.

Other Asda facts on the page: revenue £25,878m, down 3.6% on 2024; margin 4.2% from 5.5%; Q1 2026 like-for-like ex fuel −1.3% and EBITDA about 17% lower, with availability restored; free cash flow £189m in 2025 (Moody's definition); cash £1,339m and an undrawn £793m facility at end-2025; Ocado technology partnership from 2027. No usable Asda news in the 90-day window on 7 Oct, which the page says.

## Which accounts each figure comes from

- **Listed names (Tesco, Sainsbury's, M&S, Ocado):** the listed parent's group accounts in Moody's Ratings Format, as reported. Debt includes IFRS 16 leases, which is why Tesco shows 2.94x against its own net debt target range of 2.3x to 2.8x; the Moody's-adjusted figure (3.0x) is beside it.
- **Asda:** Moody's credit opinion on Bellis Finco PLC (above).
- **Morrisons:** filed accounts of Market Bidco Limited to October 2025 (revenue £15,772m, EBITDA £691m, debt £5,913m, 8.56x), the newest in Moody's; the Moody's-adjusted figure (8.1x, 12 months to July 2025) is beside it. Revenue is down 7.3% because the petrol forecourts were sold in April 2024. The margin-change arrow is grey because the filed prior-year EBITDA (£3,203m) includes the gain on that sale.
- **Aldi:** Aldi Stores Limited, UK and Ireland, calendar 2025. Leverage 0.76x: little debt.
- **Lidl:** Lidl Great Britain Limited to February 2025, 19 months old; FY Feb-26 is not yet in Moody's. 5.92x is mostly leases on a fast-growing estate.
- **Iceland:** Moody's credit opinion on Iceland VLNCo Limited to March 2026 (revenue just under £4.4bn, 4.8x gross, 4.3x net pro forma). The £311m EBITDA shown is the company's figure before rent; the margin (6.8%) is Moody's-adjusted. Both are labelled.
- **Co-op:** Co-operative Group Limited to January 2026. Group accounts: food plus funeral care, insurance and legal services. Moody's data does not split them.
- **Waitrose:** Waitrose Limited to January 2026, with the John Lewis Partnership group figures as a note (3.27x).

## Questions to be ready for

| Question | Answer |
|---|---|
| Asda is not 8.3x; we run it at 5.7x. | 5.7x is Moody's own April 2025 forecast for 2026. After the 2025 results Moody's revised it to 8.3x actual at end-2025, 7.9x forecast for 2026 and 6.7x for 2027. The company's after-rent measure (net debt to EBITDAR) is lower, 6.9x on the FT's figure, because Moody's counts leases as debt. Same direction on every basis; the card on the page shows the history. |
| Why is M&S revenue up 25%? | Ocado Retail was consolidated from 6 April 2025 (sales £3,193.4m). Excluding it, group sales grew 1.9%; food sales grew 7.0%. It is on the page from the annual report. |
| Why is Morrisons down 7.3%? | The petrol forecourts were sold in April 2024, so FY Oct-24 revenue still includes them. The page says so. |
| Why is Morrisons' margin change grey? | The filed prior-year EBITDA includes the forecourt disposal gain, so there is no comparable margin in the filed accounts. Moody's-adjusted margins (5.4% then 4.7%) are in the note. |
| Why is Ocado at 9.66x? | Ocado Group is the technology and logistics business; the UK retailer is the JV that M&S consolidates. Moody's rates it B3 and forecasts 4.9x in 2027 as debt is repaid. |
| Lidl at 5.92x and 19 months old? | Filed accounts to February 2025, the latest in Moody's; debt includes leases on more than 50 new stores a year. The age is on the page. |
| Why is Iceland's EBITDA £311m but its margin 6.8%? | £311m is the company's EBITDA before rent; 6.8% is Moody's-adjusted. Both labelled. Moody's publishes the margin, not an adjusted EBITDA figure. |
| Co-op's margin fell 1.6 points? | Group accounts, including insurance and funerals, for the year to January 2026, after the April 2025 cyber attack. The page shows the £200m cost plan announced in September. |
| Why 6% and 3% for the margin lights? | Grocers' margins run from about 2% to 8%. Thresholds were set for the demo, not by Moody's; one file and a rebuild changes them. |
| Where is market share? | Not in Moody's data for all eleven names, so not on the page. |
| Is this Moody's view? | No. Only the credit opinion sections (seven names) are Moody's views, and they are labelled. |
| Can we update it? | Yes. The same three steps rerun on new data or a new question; Thursday's page is one run. |

## Before you go in

- Pre-brief Saul on the Asda reconciliation. Agree whether Asda stays on the page; removing it is a short rebuild.
- Thursday: rerun S2 news for Asda and Aldi (nothing usable and a failed pull on 7 Oct).
- Have the Tesco and Asda company pages and the Sources tab ready.
