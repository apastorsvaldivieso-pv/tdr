#!/usr/bin/env python3
"""Build the TDR dashboard from the S1, S2 and S3 outputs. No hand-editing of the HTML.

Usage:
  python3 build_dashboard.py --s1 tdr-s1-output.json --s2 tdr-s2-output.json \
      --syn tdr-s3-synthesis.json --template tdr-dashboard-template.html \
      --out tdr-dashboard.html [--as-of YYYY-MM-DD]
  Add --audit-only to print the data audit (Step 12) without writing the page.

Exit code 0 = built (warnings are printed), 1 = an input problem stopped the build.
Every number on the page comes from the input files. The traffic lights are worked out here,
mechanically, from those numbers and the thresholds in the synthesis file; nobody sets a colour by hand.
"""
import argparse, datetime as dt, json, re, shutil, subprocess, sys, tempfile, pathlib

MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
MONTH_LONG = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
# internal basis code -> (short label, long label)
BASIS = {
    "Moody's format": ("As reported", "As reported, Moody's Ratings Format"),
    "filed": ("As reported", "As reported, filed accounts (Orbis Standard Format)"),
    "Moody's-adjusted": ("Moody's-adjusted", "Moody's-adjusted, from the credit opinion"),
}
TYPES = ("Listed", "Sponsor-owned", "Credit-fund owned", "Family-owned", "Mutual or employee-owned")
KINDS = ("Macro research", "Sector research", "Credit opinion (rated issuer)", "Précis (macro)", "Company filing", "Company statement", "News")
# a company is described by its numbers, never by a verdict
JUDGEMENT = ("winner", "winners", "loser", "losers", "pressured", "data thin", "best placed", "best-placed", "losing out",
             "our read", "well placed", "poorly placed", "struggling", "outperformer", "underperformer")
DRAMATIC = ("soar", "soars", "soared", "slump", "slumps", "plunge", "plunges", "plummet", "crash", "crisis", "tumble", "tumbles",
            "hammered", "woes", "blow", "boost", "boosts", "jump", "jumps", "jumped", "surge", "surges", "sinks", "axe", "axes", "slash", "slashes")
DEFAULT_LIGHTS = {
    "revenue_growth": {"band": 1.0},
    "margin": {"green_min": 15.0, "amber_min": 5.0},
    "margin_change": {"band": 0.5},
    "leverage": {"green_max": 3.0, "amber_max": 5.0},
}
MINUS = "−"

warnings, errors = [], []


def warn(msg): warnings.append(msg)
def fail(msg): errors.append(msg)


def d(s):
    return dt.date.fromisoformat(s[:10])


def full_months(start, end):
    m = (end.year - start.year) * 12 + end.month - start.month
    return m - 1 if end.day < start.day else m


def money(v):
    if v is None:
        return "n.d."
    a = abs(v)
    s = f"{int(a + 0.5):,}" if a >= 100 else f"{a:.1f}".rstrip("0").rstrip(".")
    return (MINUS if v < 0 else "") + "£" + s + "m"


def pct(v):
    return (MINUS if v < 0 else "") + f"{abs(v):.1f}%"


def signed(v, unit="%"):
    return ("+" if v >= 0 else MINUS) + f"{abs(v):.1f}{unit}"


def lev_fmt(v):
    s = f"{v:.2f}"
    return (s[:-1] if s.endswith("0") else s) + "x"


def plabel(date_s, ptype="FY"):
    x = d(date_s)
    return f"{ptype} {MON[x.month-1]}-{str(x.year)[2:]}"


def slug(name):
    return re.sub(r"[^a-z]", "", name.lower().split(" ")[0]) or "co"


# ------------------------------------------------------------ lights ----
def rule_text(cfg):
    g, m, mc, v = cfg["revenue_growth"], cfg["margin"], cfg["margin_change"], cfg["leverage"]
    return {
        "growth": f"Arrow, no colour: up if revenue rose {g['band']:g}% or more · flat if within {g['band']:g}% either way · down if it fell {g['band']:g}% or more",
        "margin": f"Green {m['green_min']:g}% or more · amber {m['amber_min']:g}% to {m['green_min']:g}% · red below {m['amber_min']:g}%",
        "mchange": f"Arrow, no colour: up if the margin rose {mc['band']:g} pts or more · flat if within {mc['band']:g} pts either way · down if it fell {mc['band']:g} pts or more",
        "lev": f"Green below {v['green_max']:.1f}x · amber {v['green_max']:.1f}x to {v['amber_max']:.1f}x · red above {v['amber_max']:.1f}x or EBITDA negative",
    }


def band_up(v, green_min, amber_min):
    return "grey" if v is None else ("green" if v >= green_min else ("amber" if v >= amber_min else "red"))


def band_arrow(v, band):
    """Direction against the prior year: a fact, so no colour."""
    return "grey" if v is None else ("up" if v >= band else ("down" if v <= -band else "flat"))


def lights_for(name, f, cfg, rules, basis_code, period):
    """Four indicators, each a fixed rule applied to one published figure that every name has:
    arrows (direction, no colour) for the two changes, lights for the two levels."""
    out, src, disp = [], f.get("source", ""), f.get("display") or {}
    # 1. revenue growth, two full years on one basis
    gr = f.get("growth") or {}
    gv = gr.get("value", f.get("revenue_growth"))
    if gr.get("label"):
        gper = gr["label"]
    elif gr.get("end") and gr.get("prior_end"):
        gper = f"{plabel(gr['end'])} vs {plabel(gr['prior_end'])}"
    else:
        gper = "periods not stated"
        fail(f"{name}: financials.growth needs end and prior_end, or a label")
    if f.get("period_type") == "LTM" and not gper.startswith("FY"):
        fail(f"{name}: revenue growth must compare two full years, not an LTM with a calendar year")
    out.append({"k": "growth", "label": "Revenue growth", "c": band_arrow(gv, cfg["revenue_growth"]["band"]),
                "v": signed(gv) if gv is not None else "n.d.", "period": gper, "basis": BASIS.get(gr.get("basis", basis_code), ("",))[0],
                "src": src, "rule": rules["growth"], "note": ""})
    # 2. EBITDA margin, latest period
    mg = f.get("margin")
    out.append({"k": "margin", "label": "EBITDA margin", "c": band_up(mg, cfg["margin"]["green_min"], cfg["margin"]["amber_min"]),
                "v": pct(mg) if mg is not None else "n.d.", "period": period, "basis": BASIS[basis_code][0] + (", calculated" if f.get("ebitda") is not None else ""),
                "src": src, "rule": rules["margin"], "note": disp.get("margin_note", "")})
    # 3. margin change on the prior year, same basis
    mc = f.get("margin_change") or {}
    if mc and mc.get("value") is None:
        out.append({"k": "mchange", "label": "Margin change", "c": "grey", "v": "n.d.", "period": "", "basis": "", "src": src, "rule": rules["mchange"],
                    "note": mc.get("note") or "No comparable prior-year margin in the data."})
        mc = None
    if mc and abs(mc["current"] - mc["prior"] - mc["value"]) > 0.051:
        fail(f"{name}: margin_change.value {mc['value']} is not current {mc['current']} minus prior {mc['prior']}")
    if mc is not None:
      out.append({"k": "mchange", "label": "Margin change", "c": band_arrow(mc.get("value"), cfg["margin_change"]["band"]),
                "v": signed(mc["value"], " pts") if mc else "n.d.", "period": mc.get("label", ""),
                "basis": BASIS.get(mc.get("basis", basis_code), ("",))[0] + (", calculated" if mc else ""),
                "src": src, "rule": rules["mchange"],
                "note": (f"{pct(mc['current'])} against {pct(mc['prior'])}. " + mc.get("note", "")).strip() if mc else "No prior-year margin in the data."})
    # 4. leverage, debt / EBITDA
    lev, eb = f.get("debt_ebitda"), f.get("ebitda")
    neg = (eb is not None and eb < 0) or (mg is not None and mg < 0)
    if neg:
        c, v, lnote = "red", "n.m.", "EBITDA is negative, so leverage is not meaningful."
    elif lev is None:
        c, v, lnote = "grey", "n.d.", "No debt figure in the data."
    else:
        c = "green" if lev < cfg["leverage"]["green_max"] else ("amber" if lev <= cfg["leverage"]["amber_max"] else "red")
        v, lnote = lev_fmt(lev), ""
    lnote = " ".join(x for x in (lnote, disp.get("lev_note") or disp.get("lev_sub", "")) if x)
    out.append({"k": "lev", "label": "Leverage (debt / EBITDA)", "c": c, "v": v, "period": disp.get("lev_period") or period, "basis": disp.get("lev_basis") or BASIS[basis_code][0],
                "src": src, "rule": rules["lev"], "note": lnote})
    return out


# ----------------------------------------------------------- company ----
def company(c, syn, as_of, cfg, rules):
    name = c["name"]
    f, own = c.get("financials") or {}, c.get("ownership") or {}
    p, mg = c.get("profile") or {}, c.get("management") or {}
    s, disp = f.get("series") or {}, f.get("display") or {}
    ents = c.get("entities") or []
    cid = c.get("id") or slug(name)
    if not ents:
        fail(f"{name}: no entities")
    legal = p.get("legal_display") or (ents[0]["legal"] if ents else name)
    research = next((e["legal"] for e in ents if "research" in (e.get("use") or "")), legal)

    pe = f.get("period_end")
    if not pe:
        fail(f"{name}: financials.period_end missing")
        pe = as_of.isoformat()
    ped = d(pe)
    age = full_months(ped, as_of)
    if f.get("age_months") is not None and abs(int(f["age_months"]) - age) > 1:
        warn(f"{name}: S2 age_months {f['age_months']} differs from {age} computed for {as_of}; page uses {age}")
    code = f.get("basis")
    if code not in BASIS:
        fail(f"{name}: basis {code!r} not one of {list(BASIS)}")
        code = "filed"
    ptype = f.get("period_type", "FY")
    period = plabel(pe, ptype)
    if re.search(r"get[A-Z]\w+|search[A-Z]\w+|_v2", f.get("source", "")):
        fail(f"{name}: financials.source names a tool; write the dataset for people (e.g. Moody's Ratings Format, as reported)")

    rev, ebitda, margin, lev, fcf = (f.get(k) for k in ("revenue", "ebitda", "margin", "debt_ebitda", "fcf"))
    neg = (ebitda is not None and ebitda < 0) or (margin is not None and margin < 0)
    sy = syn.get(cid) or syn.get(name)
    if sy is None:
        fail(f"{name}: no entry in synthesis 'companies' (key {cid!r})")
        sy = {}
    for k in ("read", "why"):
        if k in sy:
            fail(f"{name}: synthesis has '{k}'; verdicts are not shown any more, remove it")
    if own.get("type") not in TYPES:
        fail(f"{name}: ownership type {own.get('type')!r} not one of {TYPES}")
    short, long_ = BASIS[code]

    out = {
        "id": cid, "name": name, "legal": legal, "researchEntity": research,
        "type": own.get("type"), "owner": own.get("top_owner", ""), "ownerSrc": own.get("top_owner_source", ""),
        "ownerFlag": own.get("flag", ""), "chain": own.get("chain", []),
        "hq": p.get("hq", "n.d."), "web": p.get("website", ""), "emp": p.get("employees", "n.d."), "empSrc": p.get("employees_source", ""),
        "ceo": mg.get("ceo", "n.d."), "ceoSrc": mg.get("source", ""),
        "team": mg.get("team") or [], "teamSrc": mg.get("team_source", ""), "beneficial": own.get("beneficial"),
        "sites": p.get("sites", "n.d."), "sitesSrc": p.get("sites_source", ""), "desc": p.get("description", ""),
        "rev": rev, "revG": f.get("revenue_growth"), "ebitda": ebitda, "margin": margin, "lev": lev, "fcf": fcf,
        "revTxt": disp.get("rev_txt") or money(rev), "revSub": disp.get("rev_sub", ""),
        "ebTxt": disp.get("eb_txt") or money(ebitda),
        "ebSub": disp.get("eb_sub") or (pct(margin) + " margin, calculated" if margin is not None and ebitda is not None else ""),
        "ebBasis": disp.get("eb_basis", ""),
        "levTxt": disp.get("lev_txt") or (lev_fmt(lev) if lev is not None else ("n.m." if neg else "n.d.")),
        "levSub": disp.get("lev_sub", ""), "fcfTxt": disp.get("fcf_txt") or money(fcf),
        "basisCode": code, "basisShort": short, "basisLong": long_, "period": period, "periodType": ptype,
        "finSrc": f.get("source", ""), "date": f"{MON[ped.month-1]} {ped.year}", "age": age, "stale": age > 12,
        "cost": (c.get("evidence") or {}).get("cost") or "n.d.",
        "demand": (c.get("evidence") or {}).get("demand") or "n.d.",
        "financing": (c.get("evidence") or {}).get("financing") or "n.d.",
        "deal": sy.get("deal") or "None found", "changed": sy.get("changed", [])[:3],
        "rated": c.get("moodys") is not None, "opinionDate": (c.get("moodys") or {}).get("opinion_date", ""),
        "says": c.get("says", []), "moodys": (c.get("moodys") or {}).get("view", []),
        "gaps": c.get("gaps", []), "priorities": [x for x in ((c.get("priorities") or {}).get("items") or []) if not str(x).lower().startswith("n.d.")],
        "prioritiesSrc": (c.get("priorities") or {}).get("source", ""),
        "proj": [f"{x['text']} ({x['source']})" for x in c.get("projections", [])],
        "mgmtSrc": mg.get("source", ""),
        "filings": [{"document": x.get("document", ""), "date": x.get("date", ""), "text": x.get("text", "")} for x in c.get("filings", [])],
        "split": f.get("revenue_split"),
    }
    out["lights"] = lights_for(name, f, cfg, rules, code, period)
    lt = sy.get("latest") or {}
    if not lt.get("text") or not lt.get("src"):
        fail(f"{name}: synthesis needs latest {{text, src}} for the Latest development column")
    out["latest"] = lt
    if f.get("stale") is not None and bool(f["stale"]) != out["stale"]:
        warn(f"{name}: S2 stale={f['stale']} but accounts are {age} months old at {as_of}; page uses stale={out['stale']}")

    yrs = s.get("years") or []
    out["years"], out["revS"] = yrs, s.get("revenue") or []
    for src, dst in (("ebitda", "ebS"), ("margin", "marS"), ("debt_ebitda", "levS"), ("interest_cover", "icS"),
                     ("fcf_debt", "fcfDebtS"), ("units", "unitsS")):
        if s.get(src) is not None:
            if len(s[src]) != len(yrs):
                fail(f"{name}: series.{src} has {len(s[src])} values for {len(yrs)} years")
            out[dst] = s[src]
    if any(s.get("forecast") or []):
        out["fc"] = s["forecast"]
    out["seriesNote"] = s.get("note", "")
    out["seriesBasis"] = BASIS.get(s.get("basis", code), BASIS[code])[1]
    eb, ea = s.get("ebitda") or [], s.get("ebita") or []
    for i, (x, y) in enumerate(zip(eb, ea)):
        if x is not None and y is not None and abs(x - y) <= 0.05:
            fail(f"{name}: {yrs[i]} EBITDA equals EBITA; drop that year's EBITDA, margin and leverage")
    if f.get("ebitda_filed"):
        out["ebFiled"] = {"years": f["ebitda_filed"]["years"], "v": f["ebitda_filed"]["values"]}
    cf = f.get("cash_flow")
    if cf:
        out["cfoS"] = {"years": cf["years"], "cfo": cf["cfo"], "capex": cf["capex"], "src": cf.get("source", "")}
    if f.get("capex_guide"):
        out["capexGuide"] = {"label": f["capex_guide"]["label"], "v": f["capex_guide"]["value"], "src": f["capex_guide"].get("source", "")}
    return out


def feed_item(it, co):
    return {"d": it["date"][:10], "p": it.get("publisher", ""), "co": co, "h": it.get("headline", ""),
            "tag": it.get("tag", "Other"), "m": it.get("metric", ""), "n": it.get("number", "") or ""}


def sources(s1, cos, kept, s1kept):
    seen, research = set(), []
    ev = ((s1.get("panel") or {}).get("evidence") or {})
    mk = s1.get("market") or {}
    items = ev.get("research", []) + ev.get("macro", [])
    b = mk.get("benchmark")
    if b and not any(x.get("title") and x["title"] in b.get("source", "") for x in items):
        items = items + [{"kind": b.get("kind", "Sector research"), "title": "Market context",
                          "text": f"{b['label']} {signed(b['value'])}, {b['period']}.", "src": b["source"]}]
    for x in items:
        k = x.get("kind")
        if k not in KINDS:
            fail(f"research item without an allowed kind ({k!r}): {x.get('text', '')[:60]}")
        key = (x.get("title") or x.get("text"))[:80]
        if key in seen:
            continue
        seen.add(key)
        research.append({"kind": k, "title": x.get("title", ""), "text": x.get("text", ""), "src": x.get("src", "")})
    use = "Moody's-adjusted figures, Moody's forecasts and the factors Moody's says could lead to an upgrade or downgrade."
    for c in cos:
        if not c["rated"]:
            continue
        hit = next((r for r in research if c["researchEntity"].split(" (")[0] in r["title"]), None)
        if hit:
            hit["text"] += " Also used on the company page for " + use[0].lower() + use[1:]
        else:
            research.append({"kind": "Credit opinion (rated issuer)", "title": f"{c['researchEntity']} ({c['name']}) credit opinion",
                             "text": "Moody's-adjusted figures, Moody's forecasts and the factors Moody's says could lead to an upgrade or downgrade.",
                             "src": f"Moody's, {fmt_long(c['opinionDate'])}" if c["opinionDate"] else "Moody's"})
    company = [{"name": c["name"], "fin": c["finSrc"], "period": c["period"], "basis": c["basisLong"],
                "own": c["ownerSrc"], "mgmt": c["mgmtSrc"], "cash": (c.get("cfoS") or {}).get("src", ""),
                "split": (c.get("split") or {}).get("source", "")} for c in cos]
    filings = [{"co": "Macro trigger", "kind": x.get("kind", "Company filing"), "text": x["text"], "src": x["src"]} for x in ev.get("filings", [])]
    for c in cos:
        filings += [{"co": c["name"], "kind": "Company filing", "text": x["text"], "src": f"{x['document']}, {fmt_long(x['date'])}"} for x in c["filings"]]
    return {"research": research, "company": company, "filings": filings, "kept": kept, "s1kept": s1kept}


def fmt_long(s):
    try:
        x = d(s)
        return f"{x.day} {MON[x.month-1]} {x.year}"
    except Exception:
        return s


def build_data(s1, s2, syn, as_of):
    cfg = {k: {**v, **((syn.get("lights") or {}).get(k) or {})} for k, v in DEFAULT_LIGHTS.items()}
    rules = rule_text(cfg)
    bench = (s1.get("market") or {}).get("benchmark")
    if not bench:
        warn("no market benchmark in the S1 output; the market context line will be hidden")
    else:
        for k in ("label", "value", "period", "period_end", "source"):
            if bench.get(k) in (None, ""):
                fail(f"market.benchmark.{k} missing in the S1 output")
    synco = syn.get("companies") or {}
    cos = [company(c, synco, as_of, cfg, rules) for c in s2.get("companies", [])]
    ids = {c["id"] for c in cos}
    if len(ids) != len(cos):
        fail("two companies share an id; set distinct 'id' values in S2")
    feed = [feed_item(x, "macro") for x in s1.get("feed", []) + syn.get("feed_extra", [])]
    kept = []
    for c, co in zip(s2.get("companies", []), cos):
        n = c.get("news") or {}
        items = n.get("items", [])
        if n.get("kept") is not None and n["kept"] != len(items):
            fail(f"{c['name']}: news.kept {n['kept']} but {len(items)} items")
        feed += [feed_item(x, co["id"]) for x in items]
        kept.append([c["name"], len(items), n.get("fetched", 0), n.get("note", "")])
    feed.sort(key=lambda x: x["d"], reverse=True)
    for it in feed:
        low = it["h"].lower()
        bad = [w for w in DRAMATIC + JUDGEMENT if re.search(r"\b" + re.escape(w) + r"\b", low)]
        if bad:
            fail(f"news headline is not neutral ({', '.join(bad)}): {it['h'][:70]}")
    meta_in = syn.get("meta") or {}
    start = as_of - dt.timedelta(days=30)
    window = (f"{start.day} {MON[start.month-1]} to {as_of.day} {MON[as_of.month-1]} {as_of.year}" if start.year == as_of.year
              else f"{start.day} {MON[start.month-1]} {start.year} to {as_of.day} {MON[as_of.month-1]} {as_of.year}")
    trig = syn.get("trigger_panel") or s1.get("panel")
    if not trig:
        warn("no panel in S1 output or synthesis; the top panel will be hidden")
    for grp in ((trig or {}).get("evidence") or {}).values():
        for x in grp:
            if x.get("kind") not in KINDS:
                fail(f"trigger evidence without an allowed kind ({x.get('kind')!r}): {x.get('text', '')[:60]}")
    view = meta_in.get("view", "trigger")
    if not s1.get("question") and view != "sector":
        fail("S1 output has no 'question'; a trigger view must show the starting question (set meta.view to 'sector' for a portfolio view)")
    meta = {
        "asOf": as_of.isoformat(), "asOfLong": f"{as_of.day} {MONTH_LONG[as_of.month-1]} {as_of.year}",
        "title": meta_in.get("title", ""), "pageTitle": meta_in.get("page_title") or meta_in.get("title", ""),
        "subtitle": meta_in.get("subtitle", ""), "pulled": meta_in.get("pulled") or f"{as_of.day} {MONTH_LONG[as_of.month-1]} {as_of.year}",
        "tools": meta_in.get("tools", "Moody's research · Orbis · company filings · NewsEdge"),
        "monthWindow": meta_in.get("month_window") or window,
        "view": view, "question": s1.get("question", ""), "glossary": s1.get("glossary", ""), "selection": s1.get("selection", ""),
        "segment": s1.get("segment", ""), "ticker": syn.get("ticker", []),
        "kpi": {"dealSignals": [x["short"] for x in syn.get("deal_signals", [])],
                "refinancing": [x["short"] for x in syn.get("refinancing", [])],
                "trigger": s1.get("kpi")},
        "trigger": trig, "market": s1.get("market"),
        "lights": {"rules": rules, "cfg": cfg, "note": (syn.get("lights") or {}).get("note", "Thresholds are set for this demonstration, not by Moody's.")},
    }
    for m in syn.get("month", []):
        if not m.get("s"):
            fail(f"'This month' item without a source: {m.get('t')}")
    for u in syn.get("upcoming", []):
        if not u.get("src"):
            fail(f"'Coming up' item without a source: {u.get('what')}")
    data = {"meta": meta, "companies": cos, "month": syn.get("month", []), "feed": feed, "kept": kept,
            "upcoming": syn.get("upcoming", [])}
    data["sources"] = sources(s1, cos, kept, s1.get("news_kept"))
    text = json.dumps(data, ensure_ascii=False).lower()
    bad = sorted({w for w in JUDGEMENT if re.search(r"\b" + re.escape(w) + r"\b", text)})
    if bad:
        fail("verdict wording in the inputs: " + ", ".join(bad) + ". Describe the numbers instead.")
    return data


def audit(data):
    """Step 12: what the page will and will not show."""
    L = {"green": "G", "amber": "A", "red": "R", "grey": "-", "up": "\u2191", "down": "\u2193", "flat": "\u2192"}
    lines = ["| Company | Period · basis | Growth | Margin | Margin change | Leverage | Revenue yrs | Cash flow | Moody's view | News kept | What changed | Latest development |",
             "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    kept = {k[0]: k for k in data["kept"]}
    notes = []
    for c in data["companies"]:
        lt = {x["k"]: f"{L[x['c']]} {x['v']}" for x in c["lights"]}
        nrev = sum(v is not None for v in c.get("revS", []))
        nxt = c["deal"] if c["deal"] != "None found" else (c["financing"] if c["financing"] != "n.d." else "n.d.")
        lines.append("| " + " | ".join([
            c["name"], f"{c['period']} · {c['basisShort']}", lt["growth"], lt["margin"], lt["mchange"], lt["lev"],
            str(nrev) if nrev else "n.d.", "have" if c.get("cfoS") else "n.d.", "have" if c["rated"] else "n.d. (unrated)",
            str(kept.get(c["name"], [0, 0])[1]), str(len(c["changed"])) if c["changed"] else "n.d.", c["latest"].get("text", "")[:50]]) + " |")
        for x in c["lights"]:
            if x["c"] == "grey":
                notes.append(f"- {c['name']}: {x['label']} light is grey ({x.get('note') or x['v']})"[:200])
        if nrev < 2:
            notes.append(f"- {c['name']}: historic financials chart will not be shown (fewer than two revenue points)")
        if not c["changed"]:
            notes.append(f"- {c['name']}: no 'what changed' items")
    stale = [f"{c['name']} ({c['age']} months)" for c in data["companies"] if c["stale"]]
    notes.append("- Accounts older than 12 months (shown with an age badge): " + (", ".join(stale) if stale else "none"))
    nocash = [c["name"] for c in data["companies"] if c["type"] == "Listed" and not c.get("cfoS")]
    if nocash:
        notes.append("- Listed names without cash flow: " + ", ".join(nocash))
    b = (data["meta"].get("market") or {}).get("benchmark")
    head = f"Market context: {b['label']} {signed(b['value'])}, {b['period']} ({b['source']})\n\n" if b else "Market context: none\n\n"
    return head + "\n".join(lines) + "\n\nGrey lights and other things to know:\n" + "\n".join(notes)


def inject(template, data, as_of_long, title):
    blob = json.dumps(data, ensure_ascii=False, indent=1).replace("</", "<\\/")
    start, end = "/*TDR_DATA_START*/", "/*TDR_DATA_END*/"
    i, j = template.find(start), template.find(end)
    if i < 0 or j < 0:
        sys.exit("template has no TDR_DATA markers")
    html = template[:i + len(start)] + blob + template[j:]
    html = re.sub(r"<title>.*?</title>", "<title>" + title.replace("&", "&amp;").replace("<", "&lt;") + "</title>", html, count=1, flags=re.S)
    html = re.sub(r'(<div class="hdr-meta" id="hdrMeta">)As of [^<]*', r"\g<1>As of " + as_of_long, html, count=1)
    return html


def node_check(html):
    if not shutil.which("node"):
        return "node not available; syntax check skipped"
    js = html.split("<script>")[1].split("</script>")[0]
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as fh:
        fh.write(js)
    r = subprocess.run(["node", "--check", fh.name], capture_output=True, text=True)
    pathlib.Path(fh.name).unlink(missing_ok=True)
    return "script syntax OK" if r.returncode == 0 else "SCRIPT SYNTAX ERROR: " + r.stderr.strip()[:400]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--s1", required=True); ap.add_argument("--s2", required=True); ap.add_argument("--syn", required=True)
    ap.add_argument("--template", required=True); ap.add_argument("--out")
    ap.add_argument("--as-of"); ap.add_argument("--audit-only", action="store_true")
    a = ap.parse_args()
    load = lambda p: json.load(open(p, encoding="utf-8"))
    s1, s2, syn = load(a.s1), load(a.s2), load(a.syn)
    as_of = d(a.as_of or syn.get("as_of") or s2.get("as_of") or dt.date.today().isoformat())
    data = build_data(s1, s2, syn, as_of)
    text = json.dumps(data, ensure_ascii=False)
    if "\u2014" in text:
        fail(f"{text.count(chr(0x2014))} em dash(es) in the inputs; replace them")
    print(audit(data))
    for w in warnings:
        print("WARN ", w)
    for e in errors:
        print("ERROR", e)
    if errors:
        print("\nBuild stopped: fix the inputs above and run again.")
        sys.exit(1)
    if a.audit_only:
        return
    if not a.out:
        sys.exit("--out is required unless --audit-only")
    html = inject(open(a.template, encoding="utf-8").read(), data, data["meta"]["asOfLong"], data["meta"]["pageTitle"])
    open(a.out, "w", encoding="utf-8").write(html)
    print(f"\nwrote {a.out} ({len(html):,} chars); {node_check(html)}")


if __name__ == "__main__":
    main()
