# TDR Capital demo kit, workflow 2: UK supermarkets on Moody's data (7 Oct 2026)

The same three skills, eval and build script as the QSR kit (v3), run on a second sector: the eleven UK grocers, including Asda, a current TDR Capital portfolio company. Saul asked for this one to test whether Stage 3 works on a sector he knows well.

## What is different from the QSR kit

- **A portfolio view, not a trigger.** No starting question and no KPI cards. The company screen comes first and compares the names on the same four indicators. Below it, a general sector-and-macro panel: the State of the Consumer, the Précis UK country report (December 2025 vintage, labelled as predating the 2026 energy shock), Credit Conditions UK, the grocery in-depth, sector news on sales, prices, regulation and deals, and company statements, each item labelled by type; food inflation is one point among several. Each company page carries the metrics, the Moody's credit opinion, the ownership chain with beneficial owners, and the board and management. Eleven names across every ownership type: Tesco, Sainsbury's, Marks and Spencer and Ocado (listed); Asda and Morrisons (sponsor-owned); Aldi, Lidl and Iceland (family-owned); Co-op and Waitrose (mutual or employee-owned). Seven are rated by Moody's.
- **A fifth ownership type**, "Mutual or employee-owned", with the deal route "Asset or partnership deals" (the business itself is not for sale). It is in the build script, the template (filter button, ownership panel) and the golden file.
- **Margin light bands set for grocery**: green 6% or more, amber 3% to 6%, red below 3%. Grocers' EBITDA margins run from about 2% to 8%, so the QSR bands (15% and 5%) would make every grocer amber or red. Leverage bands are unchanged (3.0x and 5.0x). Both are in `tdr-s3-synthesis.json`; the page states them.
- **A grey margin-change arrow is allowed** when the data holds no comparable prior-year margin. The build shows "n.d." with the reason and the eval warns instead of failing. Morrisons is the case: its filed FY Oct-24 EBITDA includes the gain on the petrol forecourt sale.
- **No exclusions.** The QSR kit excludes the supermarkets; here they are the screen. The eval's list of banned names is empty.
- **Market context from news, labelled as such.** The Moody's documents returned carried no market-wide grocery sales figure, so the context line is BRC-KPMG food sales +2.6% (four weeks to 29 Aug 2026, via Retail Gazette, 10 Sep 2026), kind "News", with the Moody's grocery in-depth's qualitative points next to it.
- **Management and beneficial ownership on each company page**: up to six people with their roles from Orbis director data ("Board and management"), and the Orbis beneficial-owner record where one exists (Asda: six named individuals; Lidl: Dieter Schwarz and three individuals; Waitrose: the Partnership's chairman; none for Morrisons, Aldi, Iceland and Co-op).
- **The eval's question check** passes when `meta.view` is "sector"; in a trigger view it still requires the question and warns on any unexplained abbreviation.
- The long-form prompt pack is not copied here; it lives in the QSR kit's `reference/` folder and describes the same steps.

## Which accounts each figure comes from

Orbis holds accounts per legal company, and for several grocers the trading company is not where the debt sits. The page says which entity on each company page and in the Sources tab:

| Name | Summary figures | Basis | Why |
|---|---|---|---|
| Tesco, Sainsbury's, Marks and Spencer, Ocado | The listed parent's group accounts | As reported (Moody's Ratings Format) | Group accounts; debt includes IFRS 16 leases |
| Asda | Moody's credit opinion on Bellis Finco PLC, FY Dec-25 | Moody's-adjusted | Asda Group Limited's Orbis columns for 2024 and 2025 are unusable and Asda Stores Limited alone shows a negative EBITDA; the filed Bellis Finco EBITDA (£405.9m) is after one-off charges |
| Morrisons | Filed accounts of Market Bidco Limited, FY Oct-25 | As reported (filed) | Newer than the opinion (LTM Jul-25); Wm Morrison Supermarkets Limited's Standard Format is unreliable. Moody's-adjusted series from the opinion on Market Holdco 3 |
| Aldi | Aldi Stores Limited (UK and Ireland), FY Dec-25 | As reported | Single operating company |
| Lidl | Lidl Great Britain Limited, FY Feb-25 (19 months old) | As reported (filed) | FY Feb-26 not yet in Moody's |
| Iceland | Moody's credit opinion on Iceland VLNCo Limited, FY Mar-26 | Moody's-adjusted | The filed Iceland Foods accounts stop at FY Mar-25 and take EBITDA after rent |
| Co-op | Co-operative Group Limited, FY Jan-26 | As reported | Group accounts include funeral care, insurance and legal services |
| Waitrose | Waitrose Limited, FY Jan-26 | As reported (filed) | The parent, John Lewis Partnership plc, is noted (revenue £11,723m, 3.27x) |

## Asda's leverage: read before the demo

The page shows **5.7x**, labelled as Moody's forecast for 2026 made in April 2025, which is the figure Saul quotes; beneath it the actual 8.3x at end-2025 (Moody's-adjusted; 8.6x at March 2026) and Moody's April 2026 forecast of 7.9x. Alvaro's call on 8 Oct: the headline must be the number the client recognises, with the later Moody's figures labelled next to it. The light stays red on either figure (above 5.0x).

| Measure | 2024 | 2025 | 2026 | Source |
|---|---|---|---|---|
| Moody's-adjusted gross debt/EBITDA, April 2025 opinion | 5.9x | 6.8x forecast | 5.7x forecast | Moody's credit opinion, 10 Apr 2025 |
| Moody's-adjusted gross debt/EBITDA, April 2026 opinion | 5.9x | 8.3x actual (8.6x Mar 2026, the peak per Moody's) | 7.9x forecast | Moody's credit opinion 17 Apr 2026; issuer comment 29 May 2026 |
| Company's own measure: net debt to after-rent EBITDA (EBITDAR) | 5.7x | 6.9x | | FT, as quoted by Saul; not in Moody's data |
| Filed accounts: total debt / EBITDA after one-off charges | 7.6x | about 23x | | Orbis Standard Format, Bellis Finco PLC |

Moody's adds nearly £400m a year of lease and ground rent back to EBITDA and counts lease liabilities as debt, so its ratio sits above the company's on both sides. The direction is the same on every basis. The Asda leverage card on the page carries the forecast history with its sources; the FT figure stays in `PRESENTER-NOTES.md` because the page is Moody's data only.

## Folder layout

| Path | What it is |
|---|---|
| `skills/tdr-s1-trigger/` | `SKILL.md` + `files/tdr-s1-output.example.json` |
| `skills/tdr-s2-names-evidence/` | `SKILL.md` + `files/` with `tdr_eval.py`, `tdr-golden.json`, `tdr-s2-output.example.json` |
| `skills/tdr-s3-dashboard/` | `SKILL.md` + `files/` with `build_dashboard.py`, `tdr-dashboard-template.html`, `tdr_eval.py`, `tdr-golden.json` and the three example JSON files |
| `dist/` | One zip per skill, ready to upload |
| `shared/` | The single source for files used by more than one skill. Edit here, then run `make_dist.sh` |
| `run-2026-10-07/` | The 7 Oct grocery inputs (S1, S2, synthesis) and the page built from them |
| `PRESENTER-NOTES.md` | Talking points for the grocery page, including the Asda reconciliation |

The skills have the same names as the QSR kit's (`tdr-s1-trigger`, `tdr-s2-names-evidence`, `tdr-s3-dashboard`). Install one kit at a time in Cowork, or rename the folders inside the zips (and the `name` line in each `SKILL.md`) to `tdr-grocery-s1` and so on before uploading if both are needed at once.

## Running order

Same as the QSR kit. Thursday, in Cowork with the Moody's Credit MCP connector on (switch off the older "Moody's" connector if both show):

1. `/tdr-s1 UK supermarkets`. It pulls the sector research, macro research, Précis and sector news, proposes the eleven names and stops. Confirm.
2. `/tdr-s2 names`, `/tdr-s2 numbers`, `/tdr-s2 news`, confirming after each eval.
3. `/tdr-s3`. Confirm the data audit, then it builds, checks and publishes.

Friday: show `/tdr-s1` live if wanted, then open the page built on Thursday.

## How this run was made (7 Oct 2026)

The data was pulled in this session with the Moody's Credit MCP tools (findEntity, getEntityProfile, getEntityUltimateOwners, getEntityShareholders, getEntityBeneficiaryOwners, getEntityManagersDirectors_v2, getEntityFinancials_v2, getCreditOpinion, searchAllDocuments, searchPrecisReports, searchCompanyFilings for the M&S annual report, searchNews; the Précis, directors and beneficial-owner pulls on 8 Oct, the rest on 7 Oct) and written into the three JSON files; the page was built with `build_dashboard.py`. Data eval 298 passed, 1 warning (Morrisons' margin change not available), 0 failed. Page eval 297 passed, 0 warnings, 0 failed. Browser check: every tab and all eleven company pages render to the end, no console errors, no sideways scroll at phone width.

The three skills have not yet been run end to end as written on the grocery names from inside Cowork. The grocery-specific passages in the skills (entities per name, which accounts, traps) come from this session's pulls; a Thursday run is the first test.

## Open items

- **Asda** on the page is Moody's-adjusted (see above). If Saul prefers Asda out, delete its entry in `tdr-s2-output.json` and `tdr-s3-synthesis.json` (key `asda`), the `portfolio_read_across` line and the Asda ticker line, remove it from `tdr-golden.json`, and rebuild; the page and counts adjust.
- **Asda news**: nothing usable in the 90-day window on 7 Oct (its Q1 update and the Ocado partnership are from late May and June). Its half-year results were not found in NewsEdge. Rerun the news pull on Thursday.
- **Aldi news pull** failed twice on the Moody's server on 7 Oct; the kept items came from topic searches. Retry Thursday.
- **Lidl's accounts** are 19 months old (FY Feb-25). The page shows the age badge.
- **Filings** were tested only for M&S (annual report). Tesco's half-year results are on 8 Oct; the interim may not be in the filings tool by Thursday.
- **No newer Moody's documents** on M&S (since 21 Nov 2025) or Morrisons (since 17 Oct 2025); the opinions are shown with their dates.
- **Co-op** has no shareholder or director data in Orbis (registered society); CEO shown as n.d.
- **Market share** is not on the page: Moody's data does not hold it for all names.
