---
name: tdr-s1-trigger
description: Stage 1 of the TDR Capital portfolio-view demo on Moody's data (UK supermarkets). Builds the sector and macro view for a sector: Moody's sector research, macro research, the Précis country report and sector news, a market context figure, and the seed list of names for the screen. No trigger validation and no transmission chain. Also has a warm-up mode that pre-loads company filings. Use on /tdr-s1, /tdr-s1 warmup, or when Alvaro starts the sector-to-dashboard workflow.
---

# TDR S1: sector and macro view, names

Two modes, from the first word of the arguments:

- `/tdr-s1 warmup`: pre-load company filings only (Step 0), report "loaded" or "still loading" per company, stop. Do not summarise the filing text. Run it about 8 to 10 minutes before a live run. Tested 7 Oct 2026: loading takes about 5 to 8 minutes, and a load lasts somewhere between about 13 and 21 minutes before it has to load again.
- `/tdr-s1 [sector]`: the full run. If no sector is given, use "UK supermarkets (grocery retail)".

Output of the full run: `tdr-s1-output.md` (tables for reading) and `tdr-s1-output.json` (what S3 reads to build the top panel). Copy the field names in `files/tdr-s1-output.example.json`, next to this SKILL.md, exactly. Send both files to Alvaro.

This is a portfolio view, not a trigger. There is no starting question, no verdict and no transmission chain: the page shows the names side by side first, then, below the screen, what Moody's macro research, the Précis report, sector research and the news say about the economy and the sector. It is a general view: food inflation is one point among several unless it is the only macro topic the research covers. Run all steps in one go. Stop only at the end, for the seed list. About 10 tool calls.

## Rules for every answer in this run

1. Moody's data only, through the Moody's Credit MCP tools (research, credit opinions, Précis, Orbis company data, filings, NewsEdge news). No web search. News is third-party: give publisher and date every time. If a Moody's macroeconomic connector is present, find its tool names at runtime; if not, say "Macro connector not connected" once and carry on.
2. The lens is a private equity buyout fund (TDR Capital) looking at a sector it knows: it owns Asda. The page compares published figures; it does not rank the names.
3. Exclusions: none in this workflow.
4. Source and date on every figure. Mark calculations "calculated" and reasoning "inference". Write "n.d." for missing data. Never estimate or invent a figure. Use only documents and figures that this run's tool calls returned: if a news item's returned text has no number, do not add one, and do not list research you know of but did not get back.
5. Separate what Moody's forecasts from what current data shows, and give the vintage of every forecast.
6. Compact tables, plain English, no em dashes. Today's date drives all ages and windows.
7. Label every research source by type, so the room knows what it is looking at: "Macro research" (economy-wide, e.g. State of the Consumer), "Sector research" (a sector in-depth, outlook or comment), "Credit opinion (rated issuer)" (a Moody's opinion on one rated company, even when you cite it for a sector figure), "Précis (macro)" (the Moody's Analytics country report), "Company filing", "Company statement" (a trading update reported in the news), "News". Give the document title as well as the date.
8. Describe, never judge. The audience are experts on these companies. State what the sources say; no verdicts about companies and no dramatic wording.

## Entity IDs used in this skill

| Name | Entity ID |
|---|---|
| Tesco Plc | b3JnSWQ6MjcxNCNvcmJpc0lkOjAwMzkyOTYxNCNidmRJZDpHQjAwNDQ1NzkwI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| J Sainsbury plc | b3JnSWQ6MjQwMSNvcmJpc0lkOjAwMzkwNzQxMyNidmRJZDpHQjAwMTg1NjQ3I2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |
| Marks and Spencer Group P.L.C. | b3JnSWQ6bzAwNzI0MzUxMCNvcmJpc0lkOjAwNzI0MzUxMCNidmRJZDpHQjA0MjU2ODg2I2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs |

For a different sector, resolve the two or three largest listed names with one `findEntity` call instead.

## Step 0. Start the filings loading (first calls of every run)

One `searchCompanyFilings` call per listed company (never several companies in one call: three companies returned 279,000 characters on 7 Oct), each with `filingTypes` ["interim"] (accepted values are only annual, interim and earnings_call_transcript), `reportYears` ["2026"] and `query` "food inflation price investment volumes like-for-like cost savings energy outlook". Even one filing returns about 50,000 characters, so keep only the lines you need. If a company says "ingesting", do not wait: carry on and come back in Step 4. Tested 7 Oct 2026 on the grocery names: only the Marks and Spencer annual report (FY Mar-26) was pulled, after about 5 minutes of loading; the Tesco and Sainsbury's interims were not tested, and Tesco's half-year results come out on 8 Oct 2026, so the newest interim may not be in the tool before the demo. In warmup mode, report per company "loaded", "still loading" or "not in the filings tool" and stop.

## Step 1. Sector research

`searchAllDocuments`. Parameter names: `keywords` and `filter` with `publishDate` as "YYYY-MM-DD to YYYY-MM-DD", `regions` and `sectors` as plain names. An unresolved sector name is dropped silently and the call returns nothing, which is not the same as no research; no grocery sector name was tested on 7 Oct 2026, so run on keywords with the region filter only. Pass `chunks` 3 to keep responses short.

1. Keywords "UK grocery supermarkets price competition margins volumes consumer", last 12 months, regions ["United Kingdom"]. Tested 7 Oct 2026 (with "food inflation" in the keywords): this returned the UK grocery sector in-depth ("Grocery Retail – UK: UK supermarkets will cope with renewed inflation risks", 6 Aug 2026), the State of the Consumer (29 Sep 2026) and Credit Conditions – UK (2 Sep 2026). Keep the cross-sector document as well as the grocery one.
2. Market context (a line above the company screen, not a light): keywords "UK grocery market sales growth Worldpanel BRC food sales", last 120 days, no sector filter, `chunks` 3. Take the newest figure for the whole UK grocery market, with its period and the document that cites it. If no Moody's document returned in this run carries one, take the newest market-wide figure from the Step 3 news pull and label its kind "News". 7 Oct 2026: the Moody's documents returned carried no market-wide sales figure, so the context line is BRC-KPMG food sales +2.6% year on year in the four weeks to 29 Aug 2026 (Retail Gazette, 10 Sep 2026), with the in-depth's qualitative context next to it (volumes broadly stable; scale protects margins).

Keep from each document: the figures with their period, what Moody's expects for the sector and for named grocers, and the date. These become `panel.points` (kind "Sector research") and `panel.evidence.research`.

## Step 2. Macro: Moody's research, the Précis report, the macro connector

1. `searchAllDocuments` with keywords "UK consumer spending inflation outlook energy costs", last 90 days, regions ["United Kingdom"], `chunks` 3. 7 Oct 2026: the State of the Consumer, Europe (29 Sep 2026): UK inflation 3.1%; real consumer spending growth about 1.0% in 2026 and 0.7% in 2027; Strait of Hormuz closure and crude spike. Kind "Macro research".
2. `searchPrecisReports` with keywords "United Kingdom economic outlook GDP growth inflation unemployment consumer spending forecast". There is no sort; keep only rows titled "United Kingdom" and take the newest by date. Give its vintage and publish date, and the figures: real GDP growth, private consumption, unemployment, CPI, policy rate, for the current and next year, from the "Near-Term Outlook" and "Long-Term Forecast Summary" tables in the returned text. If the vintage predates a shock that the sector research describes, say so next to the figures rather than dropping them: the room wants the Moody's macro numbers, with their date. Tested 8 Oct 2026: newest is the December 2025 vintage, published 16 Jan 2026: real GDP growth to slow from 1.5% in 2025 to about 1% in 2026 (0.9% in the long-term table); private consumption +0.5% in 2026; unemployment 5.1%; CPI 2.4% in 2026 (quarterly 2.9%, 2.4%, 2.0%, 2.1%); policy rate 3.3% by end-2026. It predates the 2026 energy shock. Kind "Précis (macro)".
3. Macro connector, if present: UK food CPI, headline CPI, retail sales volumes, household consumption, average weekly earnings, consumer confidence, monthly, last 24 months. If not, "Macro connector not connected".

## Step 3. Sector news

`searchNews` without entities: `query` "UK grocery inflation shop price index food prices supermarkets sales", `searchType` "hybrid", `rerankResults` true, `timeRange` "past30days", `maxResultsPerEntity` 30. Keep stories about the UK, whatever the publisher's country (a US paper carrying a UK story counts). Count two reports of the same release once. Report kept out of fetched; expect about 5 of 30. Do not use keyword search with sortBy recency for topic news: it returned nothing from the UK. Drop share-price pieces and the publishers Stockpulse, Ad Hoc News, MarketBeat, Watchlist News and The Markets Daily. 7 Oct 2026: shop price inflation 1.4% in September (BRC via MarketLine, 4 Oct); UK retail sales +0.7% in August with food +2.6% and non-food −0.8% (BRC-KPMG via Retail Gazette, 10 Sep); grocery price inflation picked up in September while sales growth slowed (Worldpanel via Alliance News on Morningstar, 15 Sep); industry expects food inflation above 6% next year (The Sacramento Bee, 9 Sep). Results vary between runs; that is fine.

Company trading statements that speak to the sector go in `panel.evidence.filings` with kind "Company statement" (7 Oct: Tesco said shopper sentiment had been affected by the Middle East situation with no conflict-linked price inflation seen yet, Western Daily Press, 5 Oct 2026; Morrisons' cumulative cost savings near £1bn fund sharper pricing, Retail Times citing GlobalData, 17 Sep 2026).

## Step 4. Filings (if loaded)

If the Step 0 filings are loaded, take from each listed grocer's filing the lines on price investment, volumes, cost inflation and energy hedging, with the document and date (kind "Company filing"). If a company said "ingesting", call it again now with the same inputs, then every 30 seconds up to six times; if it is still loading, say "filings still loading" and finish without them.

## Finish

1. Write `tdr-s1-output.md`: the sector, the sector research table (claim, figure, period, source, type, date), the macro table (the same, with the vintage of every forecast), the news table, the market context figure, and a seed list of 8 to 12 UK grocers across listed, sponsor-owned, credit-fund-owned, family-owned and mutual or employee-owned (for UK supermarkets: Tesco, Sainsbury's, Marks and Spencer, Ocado, Asda, Morrisons, Aldi, Lidl, Iceland, Co-op, Waitrose). Give the seed list as a table: name, format (Big Four, discounter, premium, online, frozen, convenience), ownership type, why it is in (which ownership type it covers) and what Moody's holds on it (credit opinion if rated; Orbis accounts; filings if listed). This answers "how were these names chosen?" in the meeting.
2. Write `tdr-s1-output.json` with the example's fields: `as_of`, `view` ("sector"), `segment`, `glossary` (one line defining the Big Four, the discounters and mutual or employee-owned), `selection` (two sentences on how the names were chosen; the page shows it under the header), `macro_connector`, `seed_list`, `market` {`benchmark` {label, value, period, period_end, source, kind} (the page shows it as a market context line, not a light), `context` [up to three {text, src, kind}]}, `panel` (`title`, `badge`, `headline` with the key figures in `**bold**`, `verdict` "" and `current` "" and `steps` [] (a sector view has none), `points` (five to seven sourced lines, each {kind, text, src}: macro research and the Précis first, then sector research, news on sales and prices, news on regulation and deals, company statements; a general view of the economy and the sector, not one theme), and up to three `evidence` items each for `research`, `macro`, `news`, `filings`, each with `kind` (rule 7), `title` for research, `text` and `src`), `news_kept` {kept, fetched, note}, and `feed` (the kept sector news and research items, each with `date`, `publisher`, `headline` written as a plain statement of fact, `tag` Costs, Demand or Other, `metric`, `number` only if the source gives one; no `direction`). No `question`, `trigger` or `verdict` fields.
3. Send both files. Ask Alvaro to confirm or change the seed list, then run `/tdr-s2`. Do not start S2 yourself.

## Reference: what the 7 and 8 Oct 2026 grocery run found (sanity check, not data)

- Moody's UK grocery sector in-depth, 6 Aug 2026: food inflation to around 5% by early 2027 from 1.7% in the 12 months to June; grocers cut prices in 2025 to hold volumes at the expense of thin margins; scale protects the largest grocers' profitability; Tesco's and Sainsbury's profits broadly stable, Morrisons' margins slightly weaker, some improvement for Asda after a weak 2025; grocery volumes broadly stable.
- Moody's State of the Consumer Europe, 29 Sep 2026: UK inflation 3.1%; real private consumption about 1.0% in 2026 and 0.7% in 2027; Strait of Hormuz closure and crude spike.
- Moody's Credit Conditions UK, 2 Sep 2026: consumer-facing sectors broadly fine with pockets of weakness.
- Précis United Kingdom, December 2025 vintage (16 Jan 2026): GDP about 1% in 2026 from 1.5%; private consumption +0.5%; unemployment 5.1%; CPI 2.4%; policy rate 3.3%; predates the 2026 energy shock. The September 2025 vintage (6 Oct 2025) also comes back; use the newest.
- News: shop price inflation 1.4% in September (BRC via MarketLine, 4 Oct); food retail sales +2.6% in August (BRC-KPMG via Retail Gazette, 10 Sep); grocery inflation picked up in September (Worldpanel via Alliance News, 15 Sep); industry expects food inflation above 6% next year (The Sacramento Bee, 9 Sep).
- Market context: BRC-KPMG food sales +2.6%, four weeks to 29 Aug 2026 (Retail Gazette, 10 Sep 2026), kind News. No Moody's document returned carried a market-wide grocery sales figure.
- Filings: the Marks and Spencer annual report FY Mar-26 was pulled (Ocado Retail consolidated from 6 Apr 2025, sales £3,193.4m; group sales +1.9% excluding it; food +7.0%). The other listed names' filings were not tested.
