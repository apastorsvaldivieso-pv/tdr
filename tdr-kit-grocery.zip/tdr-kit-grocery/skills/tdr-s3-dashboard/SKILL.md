---
name: tdr-s3-dashboard
description: Stage 3 of the TDR Capital origination demo on Moody's data. Turns the S1 and S2 outputs into a published dashboard (Overview with a traffic-light company screen, Company, News and events, Sources) by writing a short synthesis file of sourced facts and running the bundled build script on the approved template, then checks it. Use on /tdr-s3 or when Alvaro asks to build or refresh the dashboard from the evidence.
---

# TDR S3: synthesis, dashboard, check

Inputs: `tdr-s1-output.json` and `tdr-s2-output.json` (with their `.md` twins), from the working folder, the conversation, or pasted. If either JSON is missing, ask for it before doing anything else. Do not pull data yourself except to fill a gap Alvaro names.
Output: a published HTML dashboard (artifact) plus a short check log.

Setup: copy everything in `files/`, next to this SKILL.md, into the working folder: `build_dashboard.py`, `tdr-dashboard-template.html` (the approved page as a template), `tdr_eval.py`, `tdr-golden.json`, and the three examples `tdr-s1-output.example.json`, `tdr-s2-output.example.json`, `tdr-s3-synthesis.example.json` (the 7 Oct 2026 grocery run).

How the page is made: the template holds the approved layout, styles and chart code, and one data block. `build_dashboard.py` fills that block from the three JSON files and nothing else. It also works out the arrows and lights: each applies a fixed rule from the synthesis file to one published figure in S2, so nobody sets a direction or a colour by hand. Never edit the HTML by hand. If something on the page is wrong, fix the input file and rebuild.

Run Steps 11 to 14 in one go, with one stop after the data audit (Step 12), because what gets shown is Alvaro's call.

## Why the page looks the way it does (client feedback, 7 Oct 2026)

The audience are experts on these companies. The page demonstrates Moody's data; it does not offer a view the room can disagree with. So:
- No verdict on any company: no Winner, Neutral, Pressured, "best placed", "losing out" or "our read". The build and the eval fail on that wording.
- Instead, four indicators per company on published metrics that every name has. Two are arrows with no colour, because direction is a fact: revenue growth (two full years) and margin change on the prior year. Two are traffic lights with a stated threshold, because a level needs one: EBITDA margin and leverage (debt/EBITDA). Each shows its figure, period, basis, rule and source. Market share and like-for-like sales were considered and dropped: Moody's data holds them for a few names only, and a light that is grey for most of the screen says nothing. A market-wide figure (for grocery, BRC-KPMG food sales growth, via news) sits above the table as context.
- Every figure carries its basis ("As reported" or "Moody's-adjusted") and its period ("FY Dec-25", "LTM Mar-26").
- News is a plain statement of fact, two-sided where the source is. No positive or negative tags.
- This kit builds a portfolio view (`meta.view` "sector"): no starting question, no trigger verdict, no transmission chain and no KPI cards (the template hides the row). A line under the header says which names are in the screen and why; the company screen comes first; below it sits the sector-and-macro panel (the template moves it there): sourced points from Moody's macro research, the Précis country report, sector research, news and company statements (`panel.points`), a general view of the economy and the sector rather than one theme, with the evidence lists beside them. Every research source is labelled as macro research, sector research, Précis or a credit opinion on a rated issuer. (The food service kit is the trigger view: a starting question at the top and a four-link chain with SOURCED or INFERRED statuses.)
- No bubble chart and no illustrative sensitivity: a calculated number that no source states invites the question "where is that from?".

## Rules

1. Only figures that appear in the S1 and S2 outputs go on the page. No new research, no estimates, no memory.
2. Source and date on every figure and every synthesis line. Mark "calculated" and "inference" where they apply.
3. No ratings column. Ratings, outlooks and thresholds appear only inside the credit opinion section and financing text.
4. Projections only where a source states them (Moody's forecasts, company guidance).
5. Plain English, no em dashes, no verdict wording, no dramatic verbs.

## Step 11. Synthesis: write `tdr-s3-synthesis.json`

Copy the field names of `tdr-s3-synthesis.example.json` exactly. From the S1 and S2 outputs only:

1. `companies`: one entry per S2 company, keyed by its `id`: `deal` (the live deal signal with source and date, or "None found"; a share suspension or a results date is not a deal signal), `changed` (up to three facts from the last 90 days, each with source and date, written as statements, with both sides where an announcement has both) and `latest` {text, src} (the latest development in one factual sentence, both sides where the source has both; it is the last column of the screen). No `read` and no `why`: the build stops if they are there.
2. `deal_signals`: live sale processes, stake sales and disposals reported in the sources, each {company, short (a few words for the KPI card), text, source}.
3. `refinancing`: refinancings or maturities inside 12 months, same fields.
4. `upcoming`: dated events (maturities, refinancings, site openings, cost programmes, results dates) sorted by date, each {when, what, src}. Do not source anything to an excluded publisher.
5. `month`: five items for the "This month" panel, each {co, t, s}; source in `s`.
6. `ticker`: five to seven one-line facts with source and short date.
7. `lights`: the rules, copied from the example unless Alvaro changes them. Arrows: revenue growth up if revenue rose 1% or more, flat within 1% either way, down if it fell 1% or more; margin change up if the margin rose 0.5 pts or more, flat within 0.5 pts, down if it fell 0.5 pts or more. Lights: the EBITDA margin bands depend on the sector: for grocery, green 6% or more, amber 3% to 6%, red below 3% (grocers' margins run from about 2% to 8%); the food service kit uses 15% and 5%. Leverage green below 3.0x, amber 3.0x to 5.0x, red above 5.0x or EBITDA negative. Keep the `note` saying the thresholds are set for the demonstration, not by Moody's.
8. `portfolio_read_across`: one sourced line per link to a current or former TDR portfolio company, or an empty list. This goes in the check log, not on the page.
9. `meta`: `title` (spell out abbreviations), `page_title`, `view` ("sector" for this portfolio view; "trigger" when S1 produced a starting question), `subtitle` (who it is for, how many names, "Moody's data only; news is third-party via Moody's NewsEdge. A demonstration, not an investment view."), `pulled` (the dates S1 and S2 were run), `tools`.
10. `as_of`: today's date.
11. `feed_extra` (optional): sector items that S2 found but could not file under a company, each with `date`, `publisher`, `headline`, `tag`, `metric`, `number`. They join the feed as "Macro and sector".

## Step 12. Data audit (STOP after this step)

Run:
`python3 build_dashboard.py --s1 tdr-s1-output.json --s2 tdr-s2-output.json --syn tdr-s3-synthesis.json --template tdr-dashboard-template.html --audit-only`

It prints the market context line, then per company the period and basis, the four indicators (arrows as up, down or flat; lights as G, A, R or - for grey; each with the figure), revenue years, cash flow, Moody's view, news kept, what changed and the latest development. Then every grey light and why, accounts older than 12 months, and listed names without cash flow. It stops with ERROR lines if an input is broken (a verdict word, a headline that is not neutral, a growth figure that compares an LTM with a calendar year, a research item without a type, a tool name in a source, a series of the wrong length, EBITDA equal to EBITA, an item without a source, an em dash); fix the input and run again. Show the audit and the WARN lines, ask Alvaro to confirm (AskUserQuestion if available, otherwise in text), and wait. Point out any company whose two lights are both one colour and both arrows point the same way, and the news that gives the other side, so he is ready for the question. Also list which names use group accounts and which use a single trading company (from `entities` and `series.note`).

## Step 13. Build

`python3 build_dashboard.py --s1 tdr-s1-output.json --s2 tdr-s2-output.json --syn tdr-s3-synthesis.json --template tdr-dashboard-template.html --out tdr-dashboard-YYYY-MM-DD.html --as-of YYYY-MM-DD`

It writes the page and runs a JavaScript syntax check when Node is available.

## Step 14. Check and publish

1. `python3 tdr_eval.py html tdr-dashboard-YYYY-MM-DD.html tdr-golden.json --s2 tdr-s2-output.json --as-of YYYY-MM-DD`. It checks excluded names, em dashes, verdict wording, literal undefined or NaN, network calls, that the As of date is today, that no old dates are left in the page code, every name in the golden file, every company's figures against `tdr-s2-output.json`, that every arrow and light follows its rule and figure, that each has a period, basis and source, the market context line (a warning if missing), the starting question (or that `meta.view` is "sector"), and research types. Fix any FAIL in the inputs and rebuild.
2. If a headless browser is available, open the page, click each tab and open each company from the screen: the company page must scroll to the end, with no console errors and no sideways scroll at phone width. If not, say the visual check was skipped.
3. Read the synthesis lines once more against rules 2 to 6.
4. Publish the page as an artifact (the page carries Moody's branding; if the publishing tool declines, give Alvaro the HTML file instead). Send a short check log: eval result, the grey lights and why, any WARN lines, the portfolio read-across, and what changed since the last run (lights that changed colour, deal signals, counts).

## Reference: 7 Oct 2026 grocery run (sanity check only)

Market context: UK food retail sales +2.6% year on year, four weeks to 29 Aug 2026 (BRC-KPMG, via Retail Gazette, 10 Sep 2026; kind News).
Indicators (growth arrow, margin light, margin change arrow, leverage light), margin bands 6% and 3%: Tesco up +5.4%, G 7.0%, flat −0.3 pts, G 2.94x; Sainsbury's up +2.7%, G 6.6%, flat −0.1 pts, G 2.97x; Marks and Spencer up +25.0% (Ocado Retail consolidated; +1.9% excluding it), G 7.5%, down −0.9 pts, G 2.63x; Ocado up +13.8%, G 13.4%, down −1.0 pts, R 9.66x; Asda (Moody's-adjusted) down −3.6%, A 4.2%, down −1.3 pts, R 5.7x (Moody's Apr 2025 forecast for 2026, the figure the client uses; actual 8.3x at Dec-25 and the Apr 2026 forecast 7.9x shown beneath); Morrisons (filed, Market Bidco) down −7.3% (forecourts sold Apr 2024), A 4.4%, grey (no comparable prior-year margin), R 8.56x; Aldi up +5.0%, A 3.7%, flat −0.2 pts, G 0.76x; Lidl (FY Feb-25) up +7.9%, A 4.5%, up +0.7 pts, R 5.92x; Iceland (Moody's-adjusted) up +3.9%, G 6.8%, flat −0.2 pts, A 4.8x; Co-op down −2.3%, A 3.9%, down −1.6 pts, A 3.75x; Waitrose up +6.9%, A 5.4%, down −0.9 pts, A 4.10x.
Asda is a current TDR Capital portfolio company (Orbis ultimate owner, Sep 2026): it is in the portfolio read-across, and the room will know its numbers. Its leverage on the page is Moody's-adjusted and includes lease liabilities; the presenter notes reconcile it with the company's own EBITDAR-based measure.
Deal signals: Sainsbury's Argos sale for at least £120m (SeeNews Deals, 31 Jul 2026); Morrisons' owner CD&R open to a merger with a major competitor (FoodManufacture.co.uk citing Sky News, 7 Oct 2026). Refinancing: Iceland's €600m notes due 2033 (Moody's, 27 Jul 2026).
Building the three example files reproduces the 7 Oct grocery page.
